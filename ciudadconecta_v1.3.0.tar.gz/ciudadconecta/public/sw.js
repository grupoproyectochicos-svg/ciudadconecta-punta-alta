/**
 * sw.js — Service Worker de CiudadConecta Punta Alta
 * =====================================================
 * Estrategia:
 *  - Cache First  → assets estáticos (HTML, CSS, JS, imágenes)
 *  - Network First → llamadas a Firebase / APIs externas
 *
 * Versión: 1.0.0
 */

const CACHE_NAME = 'ciudadconecta-v1';
const STATIC_CACHE = 'ciudadconecta-static-v1';
const DYNAMIC_CACHE = 'ciudadconecta-dynamic-v1';

/** Assets que se pre-cachean durante el install */
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/app.js',
  '/styles/main.css',
  // Leaflet (CDN - no se pre-cachea aquí; se captura en runtime)
  // Fonts también se capturan en runtime
];

/** Patrones de URLs que usan Network First */
const NETWORK_FIRST_PATTERNS = [
  /firestore\.googleapis\.com/,
  /firebase\.googleapis\.com/,
  /identitytoolkit\.googleapis\.com/,
  /securetoken\.googleapis\.com/,
  /firebasestorage\.googleapis\.com/,
  /googleapis\.com\/v1/,
];

/** Patrones de URLs que se cachean en runtime (Cache First) */
const CACHE_FIRST_PATTERNS = [
  /fonts\.googleapis\.com/,
  /fonts\.gstatic\.com/,
  /unpkg\.com\/leaflet/,
  /cdn\.tailwindcss\.com/,
  /www\.gstatic\.com\/firebasejs/,
];

// ─────────────────────────────────────────────────────────────
//  INSTALL — pre-cachear assets estáticos
// ─────────────────────────────────────────────────────────────
self.addEventListener('install', (event) => {
  console.log('[SW] Instalando CiudadConecta v1…');

  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) => {
      console.log('[SW] Pre-cacheando assets estáticos');
      return cache.addAll(PRECACHE_ASSETS);
    }).then(() => {
      // Forzar activación inmediata sin esperar a que cierren tabs abiertas
      return self.skipWaiting();
    }).catch((err) => {
      console.warn('[SW] Error en pre-cache (puede ser offline):', err);
    })
  );
});

// ─────────────────────────────────────────────────────────────
//  ACTIVATE — limpiar caches viejas
// ─────────────────────────────────────────────────────────────
self.addEventListener('activate', (event) => {
  console.log('[SW] Activando…');

  const validCaches = [STATIC_CACHE, DYNAMIC_CACHE];

  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => !validCaches.includes(name))
          .map((name) => {
            console.log('[SW] Eliminando cache obsoleta:', name);
            return caches.delete(name);
          })
      );
    }).then(() => {
      // Tomar control de todos los clientes abiertos
      return self.clients.claim();
    })
  );
});

// ─────────────────────────────────────────────────────────────
//  FETCH — estrategias de caché
// ─────────────────────────────────────────────────────────────
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = request.url;

  // Solo manejar GET
  if (request.method !== 'GET') return;

  // Solo manejar HTTP/HTTPS
  if (!url.startsWith('http')) return;

  // ── Network First: Firebase y APIs ──────────────────────────
  if (NETWORK_FIRST_PATTERNS.some((pattern) => pattern.test(url))) {
    event.respondWith(networkFirst(request));
    return;
  }

  // ── Cache First: CDN assets (Leaflet, Firebase SDK, Tailwind, Fonts) ──
  if (CACHE_FIRST_PATTERNS.some((pattern) => pattern.test(url))) {
    event.respondWith(cacheFirst(request, DYNAMIC_CACHE));
    return;
  }

  // ── Cache First: assets locales (mismo origen) ───────────────
  if (url.startsWith(self.location.origin)) {
    event.respondWith(cacheFirst(request, STATIC_CACHE));
    return;
  }
});

/**
 * Estrategia Cache First:
 * Intenta desde cache; si no existe, va a red y guarda en cache.
 */
async function cacheFirst(request, cacheName) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);

  if (cached) {
    return cached;
  }

  try {
    const networkResponse = await fetch(request);
    if (networkResponse && networkResponse.status === 200) {
      cache.put(request, networkResponse.clone());
    }
    return networkResponse;
  } catch (err) {
    console.warn('[SW] Cache First — sin red y sin cache para:', request.url);
    // Fallback: devolver index.html para navegación
    if (request.headers.get('Accept')?.includes('text/html')) {
      return cache.match('/index.html');
    }
    return new Response('Offline', { status: 503, statusText: 'Service Unavailable' });
  }
}

/**
 * Estrategia Network First:
 * Intenta red primero; si falla, devuelve desde cache.
 */
async function networkFirst(request) {
  const cache = await caches.open(DYNAMIC_CACHE);

  try {
    const networkResponse = await fetch(request);
    if (networkResponse && networkResponse.status === 200) {
      cache.put(request, networkResponse.clone());
    }
    return networkResponse;
  } catch (err) {
    console.warn('[SW] Network First — sin red, usando cache para:', request.url);
    const cached = await cache.match(request);
    if (cached) return cached;
    return new Response(JSON.stringify({ error: 'offline' }), {
      status: 503,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}

// ─────────────────────────────────────────────────────────────
//  PUSH NOTIFICATIONS
// ─────────────────────────────────────────────────────────────
self.addEventListener('push', (event) => {
  console.log('[SW] Push recibido');

  let data = {
    title: 'CiudadConecta',
    body: 'Tenés una nueva notificación',
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-192.png',
    tag: 'ciudadconecta-notif',
    data: { url: '/' }
  };

  // Intentar parsear el payload push
  if (event.data) {
    try {
      const payload = event.data.json();
      data = {
        ...data,
        title: payload.title || data.title,
        body: payload.body || data.body,
        icon: payload.icon || data.icon,
        tag: payload.tag || data.tag,
        data: payload.data || data.data,
      };
    } catch (_) {
      // Si no es JSON, usar el texto plano como body
      data.body = event.data.text() || data.body;
    }
  }

  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: data.icon,
      badge: data.badge,
      tag: data.tag,
      data: data.data,
      actions: [
        { action: 'ver', title: 'Ver reporte', icon: '/icons/icon-192.png' },
        { action: 'cerrar', title: 'Cerrar' }
      ],
      vibrate: [200, 100, 200],
      requireInteraction: false,
    })
  );
});

// ─────────────────────────────────────────────────────────────
//  NOTIFICATION CLICK
// ─────────────────────────────────────────────────────────────
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const targetUrl = event.notification.data?.url || '/';

  if (event.action === 'cerrar') return;

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // Si hay una ventana abierta, enfocarla
      for (const client of clientList) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          client.navigate(targetUrl);
          return client.focus();
        }
      }
      // Si no hay ventana, abrir una nueva
      return clients.openWindow(targetUrl);
    })
  );
});

// ─────────────────────────────────────────────────────────────
//  BACKGROUND SYNC (opcional, para reportes offline)
// ─────────────────────────────────────────────────────────────
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-reportes') {
    console.log('[SW] Sincronizando reportes pendientes…');
    event.waitUntil(syncPendingReportes());
  }
});

async function syncPendingReportes() {
  // Los reportes pendientes se guardan en IndexedDB desde app.js
  // Este handler intenta subirlos cuando recupera conexión
  const allClients = await clients.matchAll();
  allClients.forEach((client) => {
    client.postMessage({ type: 'SYNC_REPORTES' });
  });
}

// ─────────────────────────────────────────────────────────────
//  MENSAJES desde la app principal
// ─────────────────────────────────────────────────────────────
self.addEventListener('message', (event) => {
  if (event.data?.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }

  if (event.data?.type === 'CLEAR_CACHE') {
    caches.keys().then((keys) => keys.forEach((k) => caches.delete(k)));
  }
});
