/**
 * login.js — CiudadConecta Módulo de Autenticación
 * Autenticación anónima con hash SHA-256 del DNI. Nunca se guarda el DNI real.
 */

// ─── Firebase Config ──────────────────────────────────────────────────────────
const FIREBASE_CONFIG = {
  apiKey: "AIzaSyCWWX8oCxNbSMXn9oUEXd8SCOQ1FFQ4tpw",
  authDomain: "grupochicos.firebaseapp.com",
  projectId: "grupochicos",
  storageBucket: "grupochicos.firebasestorage.app",
  messagingSenderId: "98905266348",
  appId: "1:98905266348:web:09cca26c6733b4a8cda709"
};

const SESSION_KEY    = 'cc_user_session';
const ONBOARDING_KEY = 'cc_onboarding_done';

// ─── Clase AuthModule ─────────────────────────────────────────────────────────
class AuthModule {
  constructor() {
    this.auth      = null;
    this.db        = null;
    this._firebase = null;
    this.usuario   = null;
    this._slide    = 0;
  }

  // ── Init ────────────────────────────────────────────────────────────────────
  async init() {
    try {
      const { initializeApp }       = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js');
      const { getAuth, onAuthStateChanged, signInAnonymously, signOut }
        = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js');
      const { getFirestore, doc, setDoc, getDoc }
        = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');

      const app   = initializeApp(FIREBASE_CONFIG);
      this.auth   = getAuth(app);
      this.db     = getFirestore(app);
      this._fs    = { doc, setDoc, getDoc };
      this._auth  = { signInAnonymously, signOut };

      // Escuchar cambios de auth
      onAuthStateChanged(this.auth, async user => {
        if (user) {
          const datos = await this._cargarUsuarioFirestore(user.uid);
          this.usuario = { uid: user.uid, ...datos };
          this._guardarSesionLocal(this.usuario);
          this._onLogin(this.usuario);
        }
      });

    } catch (err) {
      console.warn('Firebase no disponible, usando modo local:', err.message);
      this._modoOffline();
    }

    // Verificar si ya hay sesión
    const sesionLocal = this._cargarSesionLocal();
    if (sesionLocal) {
      this._onLogin(sesionLocal);
      return;
    }

    // Mostrar onboarding o login
    const onboardingHecho = localStorage.getItem(ONBOARDING_KEY);
    if (!onboardingHecho) {
      this.renderizarOnboarding();
    } else {
      this.renderizarLogin();
    }
  }

  // ── Hash DNI con SubtleCrypto ────────────────────────────────────────────────
  async hashDNI(dni) {
    const encoder = new TextEncoder();
    const data    = encoder.encode(dni.trim() + '_ciudadconecta_salt');
    const buffer  = await crypto.subtle.digest('SHA-256', data);
    const bytes   = Array.from(new Uint8Array(buffer));
    return bytes.map(b => b.toString(16).padStart(2, '0')).join('');
  }

  // ── Registrar con DNI ────────────────────────────────────────────────────────
  async registrarConDNI(dni, nombre = '') {
    this._setLoading(true);
    this._setError('');
    try {
      const hash = await this.hashDNI(dni);

      // Sign in anónimo en Firebase
      const credencial = await this._auth.signInAnonymously(this.auth);
      const uid        = credencial.user.uid;

      // Guardar en Firestore (solo hash, nunca el DNI real)
      const { doc, setDoc } = this._fs;
      await setDoc(doc(this.db, 'usuarios', uid), {
        dniHash:   hash,
        nombre:    nombre || 'Vecino',
        createdAt: Date.now(),
        activo:    true,
        cupones:   0,
        reportes:  0
      }, { merge: true });

      const userData = { uid, dniHash: hash, nombre: nombre || 'Vecino' };
      this.usuario = userData;
      this._guardarSesionLocal(userData);
      this._onLogin(userData);

    } catch (err) {
      console.error('Error de registro:', err);
      this._setError('No se pudo conectar. Verificá tu conexión a internet.');
    } finally {
      this._setLoading(false);
    }
  }

  // ── Cerrar sesión ────────────────────────────────────────────────────────────
  async cerrarSesion() {
    try {
      if (this.auth && this._auth) {
        await this._auth.signOut(this.auth);
      }
    } catch (e) { /* ignorar */ }
    localStorage.removeItem(SESSION_KEY);
    this.usuario = null;
    this._onLogout();
  }

  // ── Obtener usuario actual ────────────────────────────────────────────────────
  async obtenerUsuarioActual() {
    if (!this.usuario) return null;
    if (!this.db || !this._fs) return this.usuario;
    try {
      const { doc, getDoc } = this._fs;
      const snap = await getDoc(doc(this.db, 'usuarios', this.usuario.uid));
      if (snap.exists()) {
        this.usuario = { uid: this.usuario.uid, ...snap.data() };
        return this.usuario;
      }
    } catch (e) { /* */ }
    return this.usuario;
  }

  // ── Cargar usuario desde Firestore ──────────────────────────────────────────
  async _cargarUsuarioFirestore(uid) {
    try {
      const { doc, getDoc } = this._fs;
      const snap = await getDoc(doc(this.db, 'usuarios', uid));
      return snap.exists() ? snap.data() : {};
    } catch (e) {
      return {};
    }
  }

  // ── Sesión local ─────────────────────────────────────────────────────────────
  _guardarSesionLocal(usuario) {
    localStorage.setItem(SESSION_KEY, JSON.stringify({ ...usuario, ts: Date.now() }));
  }

  _cargarSesionLocal() {
    try {
      const s = JSON.parse(localStorage.getItem(SESSION_KEY) || 'null');
      // Sesión válida por 30 días
      if (s && s.ts && (Date.now() - s.ts < 30 * 86400 * 1000)) return s;
    } catch { /* */ }
    return null;
  }

  // ── Callbacks (override desde afuera) ────────────────────────────────────────
  _onLogin(usuario) {
    if (typeof window.onAuthLogin === 'function') window.onAuthLogin(usuario);
  }

  _onLogout() {
    if (typeof window.onAuthLogout === 'function') window.onAuthLogout();
    this.renderizarLogin();
  }

  _modoOffline() {
    const sesion = this._cargarSesionLocal();
    if (sesion) this._onLogin(sesion);
  }

  // ── UI: Onboarding ───────────────────────────────────────────────────────────
  renderizarOnboarding() {
    const contenedor = this._contenedor();
    if (!contenedor) return;
    this._slide = 0;

    const slides = [
      {
        emoji: '🏙️',
        titulo: 'Mejorá tu ciudad',
        texto: 'CiudadConecta te permite reportar problemas urbanos como baches, desagües tapados o residuos, directamente desde tu celular.'
      },
      {
        emoji: '📸',
        titulo: '¿Cómo funciona?',
        texto: 'Sacás una foto del problema → la IA lo clasifica automáticamente → el municipio lo recibe y gestiona la solución. Ganás cupones por cada reporte verificado.'
      },
      {
        emoji: '🔒',
        titulo: 'Tu privacidad, primero',
        texto: 'Solo pedimos tu DNI para evitar reportes duplicados. Lo convertimos en un código irreversible (hash SHA-256) y nunca guardamos tu número real.'
      }
    ];

    const renderSlide = () => {
      const s = slides[this._slide];
      contenedor.innerHTML = `
        <div class="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-600 to-indigo-700 p-6">
          <div class="bg-white rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden">
            <!-- Slide content -->
            <div class="p-8 text-center">
              <div class="text-7xl mb-6">${s.emoji}</div>
              <h2 class="text-2xl font-bold text-gray-800 mb-4">${s.titulo}</h2>
              <p class="text-gray-500 text-sm leading-relaxed">${s.texto}</p>
            </div>
            <!-- Indicators -->
            <div class="flex justify-center gap-2 pb-4">
              ${slides.map((_,i) => `
                <div class="w-2 h-2 rounded-full ${i===this._slide?'bg-blue-600':'bg-gray-200'} transition-all"></div>
              `).join('')}
            </div>
            <!-- Buttons -->
            <div class="px-8 pb-8 flex gap-3">
              ${this._slide > 0 ? `
                <button id="btn-prev" class="flex-1 py-3 border border-gray-300 text-gray-600 rounded-xl font-medium text-sm hover:bg-gray-50 transition">
                  Anterior
                </button>` : ''}
              <button id="btn-next" class="flex-1 py-3 bg-blue-600 text-white rounded-xl font-medium text-sm hover:bg-blue-700 transition">
                ${this._slide === slides.length - 1 ? '¡Comenzar!' : 'Siguiente'}
              </button>
            </div>
            ${this._slide < slides.length - 1 ? `
              <div class="px-8 pb-6 text-center">
                <button id="btn-skip" class="text-xs text-gray-400 hover:text-gray-600">Saltar →</button>
              </div>` : ''}
          </div>
        </div>`;

      document.getElementById('btn-next')?.addEventListener('click', () => {
        if (this._slide < slides.length - 1) {
          this._slide++;
          renderSlide();
        } else {
          this._terminarOnboarding();
        }
      });
      document.getElementById('btn-prev')?.addEventListener('click', () => {
        if (this._slide > 0) { this._slide--; renderSlide(); }
      });
      document.getElementById('btn-skip')?.addEventListener('click', () => {
        this._terminarOnboarding();
      });
    };

    renderSlide();
  }

  _terminarOnboarding() {
    localStorage.setItem(ONBOARDING_KEY, '1');
    this.renderizarLogin();
  }

  // ── UI: Login ────────────────────────────────────────────────────────────────
  renderizarLogin() {
    const contenedor = this._contenedor();
    if (!contenedor) return;

    contenedor.innerHTML = `
      <div class="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-blue-600 to-indigo-700 p-4">
        <div class="w-full max-w-sm">
          <!-- Logo -->
          <div class="text-center mb-8">
            <div class="inline-flex items-center justify-center w-20 h-20 bg-white rounded-3xl shadow-xl mb-4">
              <span class="text-4xl">🏙️</span>
            </div>
            <h1 class="text-3xl font-bold text-white">CiudadConecta</h1>
            <p class="text-blue-200 text-sm mt-1">Punta Alta, Buenos Aires</p>
          </div>

          <!-- Card -->
          <div class="bg-white rounded-3xl shadow-2xl p-8">
            <h2 class="text-xl font-bold text-gray-800 mb-1">Ingresá al sistema</h2>
            <p class="text-sm text-gray-500 mb-6">Usamos tu DNI solo para identificarte de forma anónima</p>

            <!-- Error -->
            <div id="auth-error" class="hidden bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl px-4 py-3 mb-4"></div>

            <!-- Form -->
            <form id="form-auth" class="space-y-4">
              <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">
                  DNI <span class="text-red-500">*</span>
                </label>
                <input id="input-dni" type="number" placeholder="Ej: 12345678"
                  inputmode="numeric" min="1000000" max="99999999"
                  class="w-full border border-gray-300 rounded-xl px-4 py-3 text-base
                    focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent
                    transition placeholder-gray-400 [appearance:textfield]
                    [-webkit-appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none
                    [&::-webkit-inner-spin-button]:appearance-none"
                  required />
                <p class="text-xs text-gray-400 mt-1">7 u 8 dígitos. No guardamos tu número real.</p>
              </div>
              <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Nombre (opcional)</label>
                <input id="input-nombre" type="text" placeholder="Tu nombre o apodo"
                  class="w-full border border-gray-300 rounded-xl px-4 py-3 text-base
                    focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent
                    transition placeholder-gray-400" />
              </div>

              <!-- ¿Para qué se usa? -->
              <button type="button" id="btn-modal-privacidad"
                class="text-sm text-blue-600 hover:underline flex items-center gap-1">
                🔒 ¿Para qué se usa mi DNI?
              </button>

              <!-- Submit -->
              <button type="submit" id="btn-auth"
                class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-xl
                  transition flex items-center justify-center gap-2 text-base shadow-lg shadow-blue-200">
                <span id="btn-auth-text">Ingresar →</span>
                <span id="btn-auth-spin" class="hidden">
                  <svg class="animate-spin h-5 w-5" viewBox="0 0 24 24" fill="none">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"/>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
                  </svg>
                </span>
              </button>
            </form>

            <p class="text-xs text-gray-400 text-center mt-6 leading-relaxed">
              Al ingresar aceptás que tu DNI se transforme en un código anónimo para identificar reportes únicos.
              Nunca compartimos datos personales.
            </p>
          </div>

          <!-- Footer -->
          <p class="text-center text-blue-300 text-xs mt-5">
            Concurso UiiA — chicos.net × Google.org
          </p>
        </div>
      </div>

      <!-- Modal privacidad -->
      <div id="modal-privacidad" class="hidden fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div class="bg-white rounded-2xl shadow-2xl max-w-sm w-full p-6">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-lg font-bold text-gray-800">🔒 Privacidad de tu DNI</h3>
            <button id="btn-cerrar-modal" class="text-gray-400 hover:text-gray-700 text-2xl leading-none">&times;</button>
          </div>
          <div class="space-y-3 text-sm text-gray-600">
            <div class="flex gap-3 items-start">
              <span class="text-xl">1️⃣</span>
              <p><strong>Ingresás tu DNI</strong> en el formulario (solo en tu dispositivo).</p>
            </div>
            <div class="flex gap-3 items-start">
              <span class="text-xl">2️⃣</span>
              <p><strong>Se convierte a un código</strong> único usando SHA-256. Este proceso es irreversible: nadie puede saber tu DNI a partir del código.</p>
            </div>
            <div class="flex gap-3 items-start">
              <span class="text-xl">3️⃣</span>
              <p><strong>Guardamos solo el código</strong>, nunca tu número real. Sirve para que cada vecino tenga un ID único.</p>
            </div>
            <div class="flex gap-3 items-start">
              <span class="text-xl">✅</span>
              <p>Cumplimos con la <strong>Ley 25.326 de Protección de Datos Personales</strong> de Argentina.</p>
            </div>
          </div>
          <button id="btn-entendido"
            class="w-full mt-5 bg-blue-600 text-white py-3 rounded-xl font-medium text-sm hover:bg-blue-700 transition">
            Entendido
          </button>
        </div>
      </div>`;

    // Eventos
    document.getElementById('form-auth').addEventListener('submit', async (e) => {
      e.preventDefault();
      const dni    = document.getElementById('input-dni').value.trim();
      const nombre = document.getElementById('input-nombre').value.trim();

      if (!this._validarDNI(dni)) {
        this._setError('El DNI debe tener 7 u 8 dígitos numéricos');
        return;
      }
      await this.registrarConDNI(dni, nombre);
    });

    document.getElementById('btn-modal-privacidad').addEventListener('click', () => {
      document.getElementById('modal-privacidad').classList.remove('hidden');
    });
    document.getElementById('btn-cerrar-modal').addEventListener('click', () => {
      document.getElementById('modal-privacidad').classList.add('hidden');
    });
    document.getElementById('btn-entendido').addEventListener('click', () => {
      document.getElementById('modal-privacidad').classList.add('hidden');
    });
    document.getElementById('modal-privacidad').addEventListener('click', (e) => {
      if (e.target === e.currentTarget) e.currentTarget.classList.add('hidden');
    });
  }

  // ── Validar DNI ───────────────────────────────────────────────────────────────
  _validarDNI(dni) {
    return /^\d{7,8}$/.test(dni.replace(/\./g, '').replace(/\s/g, ''));
  }

  // ── Helpers UI ────────────────────────────────────────────────────────────────
  _setLoading(loading) {
    const txt  = document.getElementById('btn-auth-text');
    const spin = document.getElementById('btn-auth-spin');
    const btn  = document.getElementById('btn-auth');
    if (!txt) return;
    if (loading) {
      txt.textContent = 'Ingresando...';
      spin?.classList.remove('hidden');
      btn?.setAttribute('disabled', '');
    } else {
      txt.textContent = 'Ingresar →';
      spin?.classList.add('hidden');
      btn?.removeAttribute('disabled');
    }
  }

  _setError(msg) {
    const el = document.getElementById('auth-error');
    if (!el) return;
    if (msg) {
      el.textContent = msg;
      el.classList.remove('hidden');
    } else {
      el.classList.add('hidden');
    }
  }

  _contenedor() {
    return document.getElementById('auth-root') || document.body;
  }
}

// ─── Exports ───────────────────────────────────────────────────────────────────
export { AuthModule };

// ─── Auto-init si hay un #auth-root ────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('auth-root')) {
    const auth = new AuthModule();
    window.authModule = auth;
    auth.init();
  }
});
