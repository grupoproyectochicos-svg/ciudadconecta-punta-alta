/**
 * mis-reportes.js — Pantalla "Mis Reportes" con stepper de estado en tiempo real
 * CiudadConecta Punta Alta v1.0
 */
import {
  db, auth, collection, query, where, orderBy, onSnapshot
} from '../firebase-init.js';

const ESTADOS = {
  recibido:  { label: 'Recibido',  color: '#6B7280', icon: '📥', step: 0 },
  en_agenda: { label: 'En agenda', color: '#F59E0B', icon: '📋', step: 1 },
  en_obra:   { label: 'En obra',   color: '#3B82F6', icon: '🔧', step: 2 },
  resuelto:  { label: 'Resuelto',  color: '#10B981', icon: '✅', step: 3 },
};

const TIPOS = {
  bache:     { label: 'Bache',     icon: '🕳️', color: '#EF4444' },
  desague:   { label: 'Desagüe',   icon: '🌊', color: '#F59E0B' },
  reciclaje: { label: 'Reciclaje', icon: '♻️', color: '#10B981' },
};

export class MisReportesModule {
  constructor() {
    this._unsub  = null;
    this._reportes = [];
    this._filtro = 'todos';
  }

  init() {
    this._renderShell();
    this._suscribirReportes();
  }

  destroy() {
    if (this._unsub) { this._unsub(); this._unsub = null; }
  }

  // ─── Shell ───────────────────────────────────────────────────────
  _renderShell() {
    const screen = document.getElementById('screen-mis-reportes');
    if (!screen) return;
    screen.innerHTML = `
      <div class="flex flex-col h-full bg-gray-50">
        <div class="bg-primary text-white px-4 pt-12 pb-4">
          <h1 class="text-xl font-bold">📋 Mis Reportes</h1>
          <p class="text-sm opacity-80 mt-1">Seguí el estado de tus reportes</p>
          <div class="mt-3 bg-white/20 rounded-xl px-3 py-2 flex items-center gap-3">
            <span id="rep-emoji" class="text-2xl">🌱</span>
            <div>
              <div class="text-xs opacity-80">Tu nivel</div>
              <div id="rep-nivel" class="font-semibold text-sm">Nuevo</div>
            </div>
            <div class="ml-auto text-right">
              <div class="text-xs opacity-80">Puntos</div>
              <div id="rep-puntos" class="font-bold">0</div>
            </div>
          </div>
        </div>
        <div class="flex gap-2 px-4 py-3 overflow-x-auto bg-white border-b">
          <button onclick="window.misReportes?.setFiltro('todos')"
            class="filtro-btn px-3 py-1.5 rounded-full text-sm font-medium whitespace-nowrap bg-primary text-white" data-f="todos">Todos</button>
          <button onclick="window.misReportes?.setFiltro('activos')"
            class="filtro-btn px-3 py-1.5 rounded-full text-sm font-medium whitespace-nowrap bg-gray-100 text-gray-600" data-f="activos">Activos</button>
          <button onclick="window.misReportes?.setFiltro('resuelto')"
            class="filtro-btn px-3 py-1.5 rounded-full text-sm font-medium whitespace-nowrap bg-gray-100 text-gray-600" data-f="resuelto">Resueltos</button>
        </div>
        <div id="reportes-lista" class="flex-1 overflow-y-auto px-4 py-3 space-y-3 pb-24">
          <div class="flex items-center justify-center py-12 text-gray-400 text-center">
            <div><div class="text-4xl mb-3">⏳</div><p>Cargando tus reportes...</p></div>
          </div>
        </div>
      </div>
    `;
  }

  // ─── Firestore realtime ──────────────────────────────────────────
  _suscribirReportes() {
    const uid = auth.currentUser?.uid;
    if (!uid) { this._reportes = []; this._renderReportes(); return; }

    const userHash = this._hashSimple(uid);
    const q = query(
      collection(db, 'reportes'),
      where('userId', '==', userHash),
      orderBy('timestamp', 'desc')
    );

    this._unsub = onSnapshot(q, (snap) => {
      this._reportes = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      this._renderReportes();
      this._actualizarReputacion();
    }, (err) => {
      console.warn('[MisReportes]', err);
      const local = JSON.parse(localStorage.getItem('cc_mis_reportes') || '[]');
      this._reportes = local;
      this._renderReportes();
    });
  }

  setFiltro(filtro) {
    this._filtro = filtro;
    document.querySelectorAll('.filtro-btn').forEach(btn => {
      btn.className = `filtro-btn px-3 py-1.5 rounded-full text-sm font-medium whitespace-nowrap ${
        btn.dataset.f === filtro ? 'bg-primary text-white' : 'bg-gray-100 text-gray-600'
      }`;
    });
    this._renderReportes();
  }

  // ─── Render lista ─────────────────────────────────────────────────
  _renderReportes() {
    const lista = document.getElementById('reportes-lista');
    if (!lista) return;

    let lista_ = this._reportes;
    if (this._filtro === 'activos')  lista_ = this._reportes.filter(r => r.estado !== 'resuelto');
    if (this._filtro === 'resuelto') lista_ = this._reportes.filter(r => r.estado === 'resuelto');

    lista.innerHTML = lista_.length === 0
      ? this._renderVacioHTML()
      : lista_.map(r => this._renderCard(r)).join('');
  }

  _renderCard(r) {
    const tipo   = TIPOS[r.tipo]     || TIPOS.bache;
    const estado = ESTADOS[r.estado] || ESTADOS.recibido;
    const fecha  = this._fechaRelativa(r.timestamp?.seconds * 1000 || Date.now());

    return `
      <div class="bg-white rounded-2xl shadow-sm overflow-hidden" style="border-left:4px solid ${tipo.color}">
        <div class="flex gap-3 p-4">
          <div class="w-16 h-16 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0 flex items-center justify-center text-3xl">
            ${r.foto_url ? `<img src="${r.foto_url}" class="w-full h-full object-cover" loading="lazy"/>` : tipo.icon}
          </div>
          <div class="flex-1 min-w-0">
            <div class="flex items-center gap-2">
              <span class="font-semibold text-gray-800">${tipo.icon} ${tipo.label}</span>
              <span class="ml-auto text-xs text-gray-400">${fecha}</span>
            </div>
            <div class="text-sm text-gray-500 mt-0.5 truncate">${r.descripcion || 'Sin descripción'}</div>
            <div class="flex items-center gap-2 mt-1.5">
              <span class="text-xs px-2 py-0.5 rounded-full text-white font-medium" style="background:${estado.color}">
                ${estado.icon} ${estado.label}
              </span>
              ${r.confianza_ia ? `<span class="text-xs text-gray-400">IA: ${r.confianza_ia}%</span>` : ''}
            </div>
          </div>
        </div>
        <div class="px-4 pb-4">${this._renderStepper(r.estado)}</div>
        ${r.agrupado_con?.length > 0
          ? `<div class="px-4 pb-3 text-xs text-gray-400">👥 ${r.agrupado_con.length + 1} vecinos reportaron este incidente</div>`
          : ''}
      </div>
    `;
  }

  _renderStepper(estadoActual) {
    const pasos = ['recibido', 'en_agenda', 'en_obra', 'resuelto'];
    const stepActual = ESTADOS[estadoActual]?.step ?? 0;

    return `<div class="flex items-start">${pasos.map((paso, i) => {
      const e = ESTADOS[paso];
      const done = i < stepActual, current = i === stepActual;
      const cls = done ? 'bg-green-500 text-white'
        : current ? 'bg-primary text-white ring-4 ring-blue-200'
        : 'bg-gray-200 text-gray-400';
      return `
        <div class="flex flex-col items-center flex-1 relative">
          ${i < pasos.length - 1
            ? `<div class="absolute top-3.5 left-1/2 w-full h-0.5 z-0 ${done ? 'bg-green-500' : 'bg-gray-200'}"></div>`
            : ''}
          <div class="w-7 h-7 rounded-full flex items-center justify-center text-xs z-10 ${cls}">
            ${done ? '✓' : current ? e.icon : String(i + 1)}
          </div>
          <div class="text-xs mt-1 text-center leading-tight ${i > stepActual ? 'text-gray-300' : 'text-gray-600'}">
            ${e.label.split(' ')[0]}
          </div>
        </div>`;
    }).join('')}</div>`;
  }

  _renderVacioHTML() {
    return `
      <div class="flex flex-col items-center justify-center py-16 text-center px-6">
        <div class="text-7xl mb-4">🏙️</div>
        <h3 class="text-lg font-semibold text-gray-700 mb-2">Aún no hiciste reportes</h3>
        <p class="text-gray-400 text-sm mb-6">¡Ayudá a mejorar Punta Alta! Reportá baches, desagüe o puntos de reciclaje.</p>
        <button onclick="window.router?.navigate('screen-reportar')"
          class="bg-primary text-white px-6 py-3 rounded-xl font-semibold text-sm shadow-md">
          📸 Hacer mi primer reporte
        </button>
      </div>
    `;
  }

  _actualizarReputacion() {
    const puntos = parseInt(localStorage.getItem('cc_user_points') || '0');
    const nivel  = this._calcularNivel(puntos);
    const el = (id) => document.getElementById(id);
    if (el('rep-emoji'))  el('rep-emoji').textContent  = nivel.emoji;
    if (el('rep-nivel'))  el('rep-nivel').textContent  = nivel.label;
    if (el('rep-puntos')) el('rep-puntos').textContent = puntos;
  }

  _calcularNivel(pts) {
    if (pts >= 61) return { label: 'Embajador', emoji: '🏆' };
    if (pts >= 31) return { label: 'Confiable',  emoji: '⭐' };
    if (pts >= 11) return { label: 'Activo',     emoji: '🌟' };
    return              { label: 'Nuevo',       emoji: '🌱' };
  }

  _fechaRelativa(ms) {
    if (!ms) return '';
    const diff = Date.now() - ms;
    const min  = Math.floor(diff / 60000);
    const hs   = Math.floor(diff / 3600000);
    const dias = Math.floor(diff / 86400000);
    if (min < 2)   return 'Ahora mismo';
    if (min < 60)  return `Hace ${min} min`;
    if (hs  < 24)  return `Hace ${hs} hs`;
    if (dias < 7)  return `Hace ${dias} días`;
    return new Date(ms).toLocaleDateString('es-AR', { day: '2-digit', month: 'short' });
  }

  _hashSimple(str) {
    let h = 0;
    for (let i = 0; i < str.length; i++) h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
    return Math.abs(h).toString(36);
  }
}

export default MisReportesModule;
