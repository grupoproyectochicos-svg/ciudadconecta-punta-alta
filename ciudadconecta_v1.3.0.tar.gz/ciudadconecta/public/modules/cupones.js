/**
 * cupones.js — Módulo de Sistema de Cupones para CiudadConecta Punta Alta
 * RN-10 a RN-17, RN-24, RN-41
 * Stack: Vanilla JS ES modules + Firebase Firestore v10 CDN + QRCode.js CDN
 */

import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  query,
  where,
  serverTimestamp,
  Timestamp
} from '../firebase-init.js';

// ──────────────────────────────────────────────
// Utilidades
// ──────────────────────────────────────────────

/**
 * Genera un UUID v4 usando la Web Crypto API con fallback manual.
 * RN-14: código único e irrepetible.
 * @returns {string} UUID v4
 */
export function generarUUID() {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  // Fallback manual RFC-4122 v4
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * Devuelve el último día del mes actual a las 23:59:59 como Date.
 * RN-13: vencen último día del mes.
 */
function ultimoDiaMes() {
  const ahora = new Date();
  const ultimo = new Date(ahora.getFullYear(), ahora.getMonth() + 1, 0, 23, 59, 59);
  return ultimo;
}

/**
 * Formatea una fecha como "DD/MM/YYYY".
 */
function formatFecha(date) {
  if (!date) return '—';
  const d = date instanceof Date ? date : date.toDate?.() ?? new Date(date);
  return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
}

/**
 * Cuenta regresiva en formato legible (días / horas / minutos).
 */
function countdown(vencimiento) {
  const fin = vencimiento instanceof Date ? vencimiento : vencimiento.toDate?.() ?? new Date(vencimiento);
  const diff = fin - Date.now();
  if (diff <= 0) return 'Vencido';
  const days = Math.floor(diff / 86400000);
  const hrs = Math.floor((diff % 86400000) / 3600000);
  const mins = Math.floor((diff % 3600000) / 60000);
  if (days > 0) return `${days}d ${hrs}h`;
  if (hrs > 0) return `${hrs}h ${mins}m`;
  return `${mins}m`;
}

// ──────────────────────────────────────────────
// CuponesModule
// ──────────────────────────────────────────────

export class CuponesModule {
  /**
   * @param {object} app - instancia Firebase App
   * @param {string} userId - uid del usuario autenticado (hash)
   * @param {string} contenedorId - id del elemento DOM raíz donde renderizar
   */
  constructor(app, userId, contenedorId = 'app-root') {
    this.db = getFirestore(app);
    this.userId = userId;
    this.contenedorId = contenedorId;
    this.cupones = [];
    this.comercios = [];
    this.usuario = null;
    this._qrInstance = null;
    this._overlayEl = null;
    this._brightnessOriginal = null;
  }

  // ─── init ────────────────────────────────────

  /**
   * Punto de entrada del módulo.
   * Carga nivel/puntos del usuario, sus cupones del mes y los comercios adheridos.
   * Si el usuario no tiene cupones del mes → genera automáticamente.
   */
  async init() {
    try {
      this._mostrarSkeleton();
      await this._cargarUsuario();
      await this._cargarComerciosAdheridos();
      await this._cargarCuponesMes();

      if (this.cupones.length === 0) {
        await this.generarCuponesMes(this.userId);
        await this._cargarCuponesMes(); // recargar tras generar
      }

      this.renderizarCupones();
    } catch (err) {
      console.error('[CuponesModule] Error en init():', err);
      this._mostrarError('No se pudieron cargar los cupones. Verifica tu conexión.');
    }
  }

  // ─── _cargarUsuario ──────────────────────────

  async _cargarUsuario() {
    const ref = doc(this.db, 'usuarios', this.userId);
    const snap = await getDoc(ref);
    this.usuario = snap.exists() ? snap.data() : { nivel: 'nuevo', puntos: 0 };
  }

  // ─── _cargarComerciosAdheridos ───────────────

  async _cargarComerciosAdheridos() {
    try {
      const q = query(collection(this.db, 'comercios'), where('adherido', '==', true));
      const snap = await getDocs(q);
      this.comercios = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    } catch {
      this.comercios = [];
    }
    // Fallback: si Firestore devuelve vacío, usar lista hardcoded (manejada por ComerciosModule)
    if (this.comercios.length === 0) {
      this.comercios = this._comerciosHardcoded();
    }
  }

  _comerciosHardcoded() {
    return [
      { id: 'com-1', nombre: 'La Ferretería del Centro', logo_emoji: '🔧', direccion: 'Av. Colón 450', categoria: 'Ferretería', adherido: true },
      { id: 'com-2', nombre: 'Farmacia San Martín', logo_emoji: '💊', direccion: 'San Martín 123', categoria: 'Farmacia', adherido: true },
      { id: 'com-3', nombre: 'Panadería El Trigo', logo_emoji: '🥖', direccion: 'Belgrano 78', categoria: 'Panadería', adherido: true },
      { id: 'com-4', nombre: 'Librería Saber', logo_emoji: '📚', direccion: 'Brown 234', categoria: 'Librería', adherido: true },
      { id: 'com-5', nombre: 'Bar Los Amigos', logo_emoji: '☕', direccion: 'Rivadavia 567', categoria: 'Gastronomía', adherido: true },
      { id: 'com-6', nombre: 'Verdulería La Huerta', logo_emoji: '🥬', direccion: 'Moreno 89', categoria: 'Verdulería', adherido: true },
      { id: 'com-7', nombre: 'Indumentaria Moda BA', logo_emoji: '👕', direccion: 'Av. Independencia 345', categoria: 'Indumentaria', adherido: true },
      { id: 'com-8', nombre: 'Rotisería Don Pedro', logo_emoji: '🍗', direccion: 'España 12', categoria: 'Gastronomía', adherido: true },
    ];
  }

  // ─── _cargarCuponesMes ───────────────────────

  async _cargarCuponesMes() {
    const ahora = new Date();
    const inicioMes = new Date(ahora.getFullYear(), ahora.getMonth(), 1);
    const q = query(
      collection(this.db, 'cupones'),
      where('userId', '==', this.userId),
      where('vencimiento', '>=', Timestamp.fromDate(inicioMes))
    );
    const snap = await getDocs(q);
    this.cupones = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  }

  // ─── generarCuponesMes ───────────────────────

  /**
   * Genera cupones del mes para el userId indicado.
   * RN-10: todos los vecinos activos reciben cupones.
   * RN-17: iguales para todos los usuarios activos.
   * RN-24: Embajador recibe 5 cupones, resto 3.
   * @param {string} userId
   */
  async generarCuponesMes(userId) {
    const nivel = this.usuario?.nivel ?? 'nuevo';
    const cantidad = nivel === 'embajador' ? 5 : 3; // RN-24
    const vencimiento = ultimoDiaMes(); // RN-13
    const batch = [];

    for (let i = 0; i < cantidad; i++) {
      const cupon = {
        userId,                           // RN-11: personal e intransferible
        codigo_qr: generarUUID(),          // RN-14: UUID único e irrepetible
        descuento_pct: 25,                 // RN-10: 25% OFF
        vencimiento: Timestamp.fromDate(vencimiento),
        usado: false,                      // RN-15: un solo uso
        comercio_uso: null,
        fecha_uso: null,
        activo: true,
        acumulable: false,                 // RN-12: no acumulable
        creado_en: serverTimestamp(),
        mes: `${vencimiento.getFullYear()}-${String(vencimiento.getMonth() + 1).padStart(2, '0')}`,
      };
      batch.push(addDoc(collection(this.db, 'cupones'), cupon));
    }

    try {
      await Promise.all(batch);
      console.log(`[CuponesModule] ${cantidad} cupones generados para usuario ${userId}`);
    } catch (err) {
      console.error('[CuponesModule] Error al generar cupones:', err);
      throw err;
    }
  }

  // ─── renderizarCupones ───────────────────────

  /**
   * Renderiza la pantalla principal de cupones: header, grid de cards, barra de progreso,
   * lista de comercios adheridos.
   */
  renderizarCupones() {
    const contenedor = document.getElementById(this.contenedorId);
    if (!contenedor) return;

    const { nivel = 'nuevo', puntos = 0 } = this.usuario ?? {};
    const nivelInfo = this._infoNivel(nivel);

    const usados = this.cupones.filter(c => c.usado).length;
    const total = this.cupones.length;
    const progresoPct = total > 0 ? Math.round((usados / total) * 100) : 0;

    contenedor.innerHTML = `
      <div class="cupones-screen" style="${estilosBase}">

        <!-- ── Header ── -->
        <div class="cupones-header" style="
          background: linear-gradient(135deg, #1a237e 0%, #283593 100%);
          color: white; padding: 20px 16px 16px; border-radius: 0 0 24px 24px;
          box-shadow: 0 4px 16px rgba(26,35,126,0.3);
        ">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
            <div>
              <div style="font-size:22px; font-weight:700; letter-spacing:-0.5px;">🎟️ Mis Cupones</div>
              <div style="font-size:13px; opacity:0.85;">Mes actual · ${this._mesActualLabel()}</div>
            </div>
            <div style="text-align:right;">
              <div style="
                background: ${nivelInfo.color}; color:white; border-radius:20px;
                padding: 4px 12px; font-size:13px; font-weight:700;
                display:flex; align-items:center; gap:6px;
              ">
                ${nivelInfo.emoji} ${this._capitalize(nivel)}
              </div>
              <div style="font-size:12px; opacity:0.8; margin-top:4px;">⭐ ${puntos} pts</div>
            </div>
          </div>

          <!-- Barra de progreso del mes -->
          <div style="background: rgba(255,255,255,0.15); border-radius:8px; overflow:hidden; height:8px;">
            <div style="
              height:100%; width:${progresoPct}%;
              background: linear-gradient(90deg,#4fc3f7,#81d4fa);
              border-radius:8px; transition: width 0.6s ease;
            "></div>
          </div>
          <div style="font-size:12px; opacity:0.85; margin-top:6px; text-align:center;">
            Usaste <strong>${usados}</strong> de <strong>${total}</strong> cupones este mes
          </div>
        </div>

        <!-- ── Grid de cupones ── -->
        <div style="padding:16px;">
          <h3 style="margin:0 0 12px; font-size:16px; color:#1a237e; font-weight:700;">Tus cupones</h3>
          <div class="cupones-grid" style="
            display:grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap:14px;
          ">
            ${this.cupones.map(c => this._cardCupon(c)).join('')}
          </div>
        </div>

        <!-- ── Comercios adheridos ── -->
        <div style="padding:0 16px 24px;">
          <h3 style="margin:0 0 12px; font-size:16px; color:#1a237e; font-weight:700;">
            🏪 Comercios adheridos
          </h3>
          <div style="display:grid; grid-template-columns: repeat(auto-fill, minmax(160px, 1fr)); gap:10px;">
            ${this.comercios.map(c => this._cardComercioSimple(c)).join('')}
          </div>
        </div>

      </div>
    `;

    // Vincular eventos de botones
    this._bindEventos();
  }

  // ─── _cardCupon ──────────────────────────────

  _cardCupon(cupon) {
    const venc = cupon.vencimiento?.toDate?.() ?? new Date(cupon.vencimiento);
    const ahora = new Date();
    const vencido = venc < ahora;
    const estado = cupon.usado ? 'usado' : vencido ? 'vencido' : 'activo';

    const badges = {
      activo:  { label: 'ACTIVO',  bg: '#2e7d32', color: '#fff' },
      usado:   { label: 'USADO',   bg: '#757575', color: '#fff' },
      vencido: { label: 'VENCIDO', bg: '#c62828', color: '#fff' },
    };
    const badge = badges[estado];

    const comercio = this.comercios.find(c => c.id === cupon.comercio_uso);
    const comercioNombre = comercio ? `${comercio.logo_emoji} ${comercio.nombre}` : '';

    const btnStyle = estado === 'activo'
      ? 'background:linear-gradient(135deg,#1a237e,#3949ab);color:white;cursor:pointer;'
      : 'background:#e0e0e0;color:#9e9e9e;cursor:not-allowed;';

    return `
      <div class="cupon-card" style="
        background:white; border-radius:16px; overflow:hidden;
        box-shadow:0 2px 12px rgba(0,0,0,0.1);
        border-left:5px solid ${badge.bg};
        opacity:${estado !== 'activo' ? '0.72' : '1'};
        position:relative;
      ">
        <!-- Badge de estado -->
        <span style="
          position:absolute; top:12px; right:12px;
          background:${badge.bg}; color:${badge.color};
          font-size:10px; font-weight:700; padding:3px 8px; border-radius:10px;
        ">${badge.label}</span>

        <div style="padding:18px 16px 14px;">
          <!-- Descuento grande -->
          <div style="
            font-size:48px; font-weight:900; line-height:1;
            color:#1a237e; letter-spacing:-2px;
          ">25<span style="font-size:28px;">%</span></div>
          <div style="font-size:13px; color:#555; margin-top:2px;">DE DESCUENTO</div>

          ${comercioNombre ? `<div style="font-size:13px; margin-top:8px; color:#333;">${comercioNombre}</div>` : ''}

          <!-- Vencimiento -->
          <div style="
            display:flex; align-items:center; gap:6px;
            margin-top:10px; font-size:12px; color:#888;
          ">
            📅 Vence: <strong style="color:#555;">${formatFecha(venc)}</strong>
            ${estado === 'activo' ? `<span style="color:#e65100;font-weight:600;">(${countdown(venc)})</span>` : ''}
          </div>

          <!-- No acumulable -->
          <div style="font-size:11px; color:#aaa; margin-top:4px;">⚠️ No acumulable con otras promos</div>

          <!-- Botón usar -->
          <button
            class="btn-usar-cupon"
            data-cupon-id="${cupon.id}"
            data-codigo="${cupon.codigo_qr}"
            ${estado !== 'activo' ? 'disabled' : ''}
            style="
              width:100%; margin-top:14px; padding:10px;
              border:none; border-radius:10px; font-size:14px; font-weight:700;
              ${btnStyle}
              transition: transform 0.1s;
            "
          >
            ${estado === 'activo' ? '📲 Usar cupón' : estado === 'usado' ? '✅ Ya usado' : '🚫 Vencido'}
          </button>
        </div>
      </div>
    `;
  }

  // ─── _cardComercioSimple ─────────────────────

  _cardComercioSimple(comercio) {
    return `
      <div style="
        background:white; border-radius:12px; padding:12px;
        box-shadow:0 2px 8px rgba(0,0,0,0.07);
        display:flex; flex-direction:column; align-items:center; text-align:center;
        position:relative; gap:4px;
      ">
        <span style="
          position:absolute; top:6px; right:6px; background:#1a237e; color:white;
          font-size:9px; font-weight:700; padding:2px 6px; border-radius:6px;
        ">25% OFF</span>
        <div style="font-size:30px;">${comercio.logo_emoji}</div>
        <div style="font-size:12px; font-weight:700; color:#1a237e; line-height:1.2;">${comercio.nombre}</div>
        <div style="font-size:11px; color:#888;">${comercio.direccion}</div>
        <div style="
          font-size:10px; color:#555; background:#f5f5f5;
          padding:2px 8px; border-radius:8px; margin-top:2px;
        ">${comercio.categoria}</div>
      </div>
    `;
  }

  // ─── mostrarQR ───────────────────────────────

  /**
   * Abre overlay full-screen con el QR del cupón.
   * @param {string} cuponId - id del documento Firestore
   */
  async mostrarQR(cuponId) {
    const cupon = this.cupones.find(c => c.id === cuponId);
    if (!cupon) return;

    const venc = cupon.vencimiento?.toDate?.() ?? new Date(cupon.vencimiento);
    const comercio = this.comercios.find(c => c.id === cupon.comercio_uso) ?? null;
    const qrData = `ciudadconecta://cupon/${cupon.codigo_qr}/${this.userId}`;

    // Activar máximo brillo (si Screen Wake Lock API está disponible)
    await this._activarBrillo();

    // Crear overlay
    const overlay = document.createElement('div');
    overlay.id = 'cupon-qr-overlay';
    overlay.style.cssText = `
      position:fixed; inset:0; z-index:9999;
      background:rgba(0,0,0,0.92); display:flex; align-items:center; justify-content:center;
      flex-direction:column; animation: fadeIn 0.25s ease;
    `;

    // Código alfanumérico corto (primeros 8 chars del UUID en mayúsculas)
    const codigoCorto = cupon.codigo_qr.replace(/-/g, '').substring(0, 8).toUpperCase();

    overlay.innerHTML = `
      <style>
        @keyframes fadeIn { from { opacity:0; transform:scale(0.96); } to { opacity:1; transform:scale(1); } }
        @keyframes pulseQR { 0%,100%{box-shadow:0 0 0 0 rgba(255,255,255,0.4)} 50%{box-shadow:0 0 0 12px rgba(255,255,255,0)} }
      </style>

      <!-- Botón cerrar -->
      <button id="btn-cerrar-qr" style="
        position:fixed; top:16px; right:16px;
        background:rgba(255,255,255,0.15); border:none; color:white;
        width:44px; height:44px; border-radius:50%; font-size:20px; cursor:pointer;
        display:flex; align-items:center; justify-content:center;
        backdrop-filter:blur(4px);
      ">✕</button>

      <!-- Descuento -->
      <div style="color:white; font-size:42px; font-weight:900; letter-spacing:-1px; margin-bottom:4px;">
        25% OFF
      </div>
      <div style="color:rgba(255,255,255,0.7); font-size:14px; margin-bottom:20px;">
        🏪 ${comercio ? `${comercio.logo_emoji} ${comercio.nombre}` : 'Cualquier comercio adherido'}
      </div>

      <!-- Contenedor QR -->
      <div style="
        background:white; border-radius:20px; padding:20px;
        animation: pulseQR 2.5s infinite;
      ">
        <div id="qr-canvas-contenedor"></div>
      </div>

      <!-- Código alfanumérico -->
      <div style="
        color:white; font-family:monospace; font-size:22px; font-weight:700;
        letter-spacing:4px; margin-top:20px; opacity:0.9;
      ">${codigoCorto}</div>

      <!-- Info adicional -->
      <div style="
        margin-top:16px; text-align:center; color:rgba(255,255,255,0.65); font-size:13px;
        line-height:1.6;
      ">
        📅 Vence: ${formatFecha(venc)}&nbsp;&nbsp;⏳ ${countdown(venc)}<br>
        <span style="font-size:11px; opacity:0.7;">Personal e intransferible · Un solo uso · No acumulable</span>
      </div>

      <!-- Selector de comercio (si no hay uno asignado) -->
      ${!cupon.comercio_uso ? `
        <div style="margin-top:20px; width:90%; max-width:320px;">
          <select id="select-comercio-qr" style="
            width:100%; padding:10px; border-radius:10px; border:none;
            font-size:14px; background:rgba(255,255,255,0.12); color:white;
            outline:none;
          ">
            <option value="" style="color:#333;">Seleccioná el comercio...</option>
            ${this.comercios.map(c => `<option value="${c.id}" style="color:#333;">${c.logo_emoji} ${c.nombre}</option>`).join('')}
          </select>
          <button id="btn-confirmar-uso" style="
            width:100%; margin-top:10px; padding:12px; border:none; border-radius:10px;
            background:linear-gradient(135deg,#2e7d32,#43a047); color:white;
            font-size:15px; font-weight:700; cursor:pointer;
          ">✅ Confirmar uso</button>
        </div>
      ` : `
        <button id="btn-confirmar-uso" data-comercio="${cupon.comercio_uso}" style="
          margin-top:20px; padding:12px 32px; border:none; border-radius:10px;
          background:linear-gradient(135deg,#2e7d32,#43a047); color:white;
          font-size:15px; font-weight:700; cursor:pointer;
        ">✅ Marcar como usado</button>
      `}
    `;

    document.body.appendChild(overlay);
    this._overlayEl = overlay;

    // Generar QR con QRCode.js
    await this._generarQR('qr-canvas-contenedor', qrData);

    // Eventos del overlay
    document.getElementById('btn-cerrar-qr')?.addEventListener('click', () => this._cerrarQR());

    const btnConfirmar = document.getElementById('btn-confirmar-uso');
    btnConfirmar?.addEventListener('click', async () => {
      const comercioId = document.getElementById('select-comercio-qr')?.value
        || btnConfirmar.dataset.comercio
        || null;
      if (!comercioId) {
        btnConfirmar.style.animation = 'shake 0.3s';
        btnConfirmar.textContent = '⚠️ Seleccioná un comercio';
        setTimeout(() => { btnConfirmar.textContent = '✅ Confirmar uso'; }, 2000);
        return;
      }
      await this.marcarComoUsado(cuponId, comercioId);
      this._cerrarQR();
    });

    // Cerrar con Escape
    this._escHandler = (e) => { if (e.key === 'Escape') this._cerrarQR(); };
    document.addEventListener('keydown', this._escHandler);
  }

  // ─── _generarQR ──────────────────────────────

  async _generarQR(contenedorId, data) {
    // Cargar QRCode.js dinámicamente si no está disponible
    if (typeof QRCode === 'undefined') {
      await new Promise((resolve, reject) => {
        const s = document.createElement('script');
        s.src = 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';
        s.onload = resolve;
        s.onerror = reject;
        document.head.appendChild(s);
      });
    }
    const el = document.getElementById(contenedorId);
    if (!el) return;

    this._qrInstance = new QRCode(el, {
      text: data,
      width: 220,
      height: 220,
      colorDark: '#000000',
      colorLight: '#ffffff',
      correctLevel: QRCode.CorrectLevel.H,
    });
  }

  // ─── _cerrarQR ───────────────────────────────

  _cerrarQR() {
    if (this._overlayEl) {
      this._overlayEl.remove();
      this._overlayEl = null;
    }
    this._qrInstance = null;
    this._desactivarBrillo();
    if (this._escHandler) {
      document.removeEventListener('keydown', this._escHandler);
      this._escHandler = null;
    }
  }

  // ─── Brillo pantalla ─────────────────────────

  async _activarBrillo() {
    try {
      if ('wakeLock' in navigator) {
        this._wakeLock = await navigator.wakeLock.request('screen');
      }
    } catch { /* silencioso */ }
  }

  _desactivarBrillo() {
    try { this._wakeLock?.release?.(); } catch { /* silencioso */ }
    this._wakeLock = null;
  }

  // ─── marcarComoUsado ─────────────────────────

  /**
   * Marca el cupón como usado en Firestore y registra el crédito fiscal.
   * RN-15: un solo uso.
   * RN-41: crédito fiscal.
   * @param {string} cuponId
   * @param {string} comercioId
   */
  async marcarComoUsado(cuponId, comercioId) {
    try {
      const ref = doc(this.db, 'cupones', cuponId);
      await updateDoc(ref, {
        usado: true,
        activo: false,
        comercio_uso: comercioId,
        fecha_uso: serverTimestamp(),
      });

      // RN-41: registrar crédito fiscal
      const cupon = this.cupones.find(c => c.id === cuponId);
      await addDoc(collection(this.db, 'creditos_fiscales'), {
        cupon_id: cuponId,
        comercio_id: comercioId,
        userId: this.userId,
        descuento_pct: cupon?.descuento_pct ?? 25,
        fecha: serverTimestamp(),
        tipo: 'cupon_ciudadconecta',
        mes: cupon?.mes ?? this._mesKey(),
      });

      // Actualizar estado local
      const idx = this.cupones.findIndex(c => c.id === cuponId);
      if (idx !== -1) {
        this.cupones[idx] = { ...this.cupones[idx], usado: true, activo: false, comercio_uso: comercioId };
      }

      this._mostrarExito('¡Cupón canjeado exitosamente! 🎉');
      // Re-renderizar para reflejar el nuevo estado
      setTimeout(() => this.renderizarCupones(), 1800);
    } catch (err) {
      console.error('[CuponesModule] Error al marcar como usado:', err);
      this._mostrarError('No se pudo registrar el uso. Intentá de nuevo.');
    }
  }

  // ─── Helpers de UI ───────────────────────────

  _mostrarSkeleton() {
    const contenedor = document.getElementById(this.contenedorId);
    if (!contenedor) return;
    contenedor.innerHTML = `
      <div style="padding:20px; display:flex; flex-direction:column; gap:14px; ${estilosBase}">
        ${[...Array(3)].map(() => `
          <div style="height:180px; background:#e8eaf6; border-radius:16px;
            animation:skeletonPulse 1.4s infinite;">
          </div>
        `).join('')}
        <style>
          @keyframes skeletonPulse {
            0%,100%{opacity:1} 50%{opacity:0.5}
          }
        </style>
      </div>
    `;
  }

  _mostrarError(msg) {
    const contenedor = document.getElementById(this.contenedorId);
    if (!contenedor) return;
    contenedor.innerHTML = `
      <div style="padding:40px 20px; text-align:center; ${estilosBase}">
        <div style="font-size:48px;">😕</div>
        <div style="margin-top:12px; color:#c62828; font-weight:600;">${msg}</div>
        <button onclick="window.location.reload()" style="
          margin-top:20px; padding:10px 24px; background:#1a237e; color:white;
          border:none; border-radius:10px; cursor:pointer; font-size:14px;
        ">Reintentar</button>
      </div>
    `;
  }

  _mostrarExito(msg) {
    const toast = document.createElement('div');
    toast.style.cssText = `
      position:fixed; bottom:32px; left:50%; transform:translateX(-50%);
      background:linear-gradient(135deg,#2e7d32,#43a047); color:white;
      padding:14px 28px; border-radius:50px; font-size:16px; font-weight:700;
      box-shadow:0 8px 24px rgba(46,125,50,0.4); z-index:10000;
      animation:toastIn 0.3s ease, toastOut 0.3s ease 1.5s forwards;
      white-space:nowrap;
    `;
    toast.textContent = msg;
    const style = document.createElement('style');
    style.textContent = `
      @keyframes toastIn { from{opacity:0;transform:translateX(-50%) translateY(20px)} to{opacity:1;transform:translateX(-50%) translateY(0)} }
      @keyframes toastOut { from{opacity:1} to{opacity:0} }
    `;
    document.head.appendChild(style);
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 2000);
  }

  _bindEventos() {
    document.querySelectorAll('.btn-usar-cupon').forEach(btn => {
      btn.addEventListener('click', () => {
        const cuponId = btn.dataset.cuponId;
        this.mostrarQR(cuponId);
      });
      // Efecto press
      btn.addEventListener('mousedown', () => { btn.style.transform = 'scale(0.97)'; });
      btn.addEventListener('mouseup', () => { btn.style.transform = 'scale(1)'; });
    });
  }

  _infoNivel(nivel) {
    const niveles = {
      nuevo:     { color: '#78909c', emoji: '🌱' },
      activo:    { color: '#1565c0', emoji: '⚡' },
      confiable: { color: '#6a1b9a', emoji: '🛡️' },
      embajador: { color: '#e65100', emoji: '🏆' },
    };
    return niveles[nivel?.toLowerCase()] ?? niveles.nuevo;
  }

  _capitalize(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }

  _mesActualLabel() {
    const meses = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
    const d = new Date();
    return `${meses[d.getMonth()]} ${d.getFullYear()}`;
  }

  _mesKey() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  }
}

// ── Estilos base globales del módulo ──────────
const estilosBase = `
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  max-width: 600px; margin: 0 auto; min-height: 100vh; background: #f3f4f9;
`;

export default CuponesModule;
