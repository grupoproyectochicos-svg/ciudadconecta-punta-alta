/**
 * ai-engine.js — Motor de IA Simulado · CiudadConecta Punta Alta
 * ---------------------------------------------------------------
 * Simula clasificación de imágenes, verificación de autenticidad,
 * detección de duplicados y cálculo de reputación.
 *
 * Todas las funciones son puras (sin side-effects de red) excepto
 * las que leen de Firestore (detectarDuplicado ya recibe los datos).
 */

// ── Constantes ────────────────────────────────────────────────────────────────

/** Bounding box de Punta Alta, Buenos Aires */
const BBOX_PUNTA_ALTA = {
  latMin: -38.9200,
  latMax: -38.8400,
  lngMin: -62.1200,
  lngMax: -61.9800,
};

/** Radio máximo para considerar duplicado (metros) */
const RADIO_DUPLICADO_M = 50;

/** Delay simulado de procesamiento IA (ms) */
const AI_DELAY_MS = 2000;

// ── Helpers internos ──────────────────────────────────────────────────────────

/**
 * Genera un entero aleatorio entre min y max (inclusive).
 * @param {number} min
 * @param {number} max
 * @returns {number}
 */
function randInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Calcula la distancia haversine entre dos coordenadas geográficas.
 * @param {number} lat1
 * @param {number} lng1
 * @param {number} lat2
 * @param {number} lng2
 * @returns {number} Distancia en metros
 */
export function distanciaHaversine(lat1, lng1, lat2, lng2) {
  const R = 6371000; // Radio de la Tierra en metros
  const toRad = (deg) => (deg * Math.PI) / 180;

  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// ── Función principal: clasificarImagen ───────────────────────────────────────

/**
 * Simula la clasificación de una imagen de incidente urbano.
 *
 * @param {string} imageDataURL  - DataURL (base64) de la imagen capturada
 * @param {'bache'|'desague'|'reciclaje'} tipoHint - Tipo indicado por el usuario
 * @returns {Promise<{tipo: string, confianza: number, descripcion: string, severidad: string}>}
 */
export async function clasificarImagen(imageDataURL, tipoHint) {
  // Simular tiempo de procesamiento del modelo
  await new Promise((resolve) => setTimeout(resolve, AI_DELAY_MS));

  // Confianza realista (72–98 %) — levemente mayor si el hint coincide
  const confianza = randInt(72, 98);

  // Dimensión aleatoria para descripciones más realistas
  const diametroCm = randInt(15, 60);
  const profundidadCm = randInt(5, 25);
  const areaCm2 = randInt(200, 3000);

  // Severidad según confianza y tipo
  let severidad;
  if (tipoHint === 'bache') {
    if (profundidadCm > 18 || areaCm2 > 2000) severidad = 'severo';
    else if (profundidadCm > 10) severidad = 'moderado';
    else severidad = 'leve';
  } else if (tipoHint === 'desague') {
    if (confianza >= 90) severidad = 'severo';
    else if (confianza >= 80) severidad = 'moderado';
    else severidad = 'leve';
  } else {
    severidad = 'leve';
  }

  // Descripciones según tipo
  const descripciones = {
    bache: `Bache de aproximadamente ${diametroCm} cm de diámetro y ${profundidadCm} cm de profundidad detectado en calzada. Área afectada estimada: ${areaCm2} cm². Requiere intervención ${severidad === 'severo' ? 'urgente' : 'prioritaria'}.`,
    desague: `Obstrucción en sumidero detectada, posible acumulación de residuos sólidos y sedimentos. Nivel de obstrucción estimado: ${confianza >= 85 ? 'total' : 'parcial'}. ${severidad === 'severo' ? 'Riesgo de inundación en lluvias.' : 'Monitoreo recomendado.'}`,
    reciclaje: `Punto de reciclaje detectado. Estado: ${confianza >= 85 ? 'contenedor lleno' : 'capacidad disponible'}. Material predominante: ${['plástico', 'papel', 'vidrio', 'metales'][randInt(0, 3)]}.`,
  };

  const tipo = tipoHint || 'bache';
  const descripcion = descripciones[tipo] || descripciones['bache'];

  return {
    tipo,
    confianza,
    descripcion,
    severidad,
  };
}

// ── verificarAutenticidad ─────────────────────────────────────────────────────

/**
 * Verifica que un reporte sea auténtico (GPS válido, timestamp reciente).
 *
 * @param {string|null} foto        - DataURL de la foto (puede omitirse)
 * @param {{lat: number, lng: number}|null} gps - Coordenadas del dispositivo
 * @param {Date|number|null} timestamp           - Momento de la captura
 * @returns {{autentico: boolean, razon: string}}
 */
export function verificarAutenticidad(foto, gps, timestamp) {
  // 1. Verificar presencia de GPS
  if (!gps || gps.lat == null || gps.lng == null) {
    return {
      autentico: false,
      razon: 'No se pudo obtener la ubicación GPS del dispositivo.',
    };
  }

  // 2. Verificar que GPS esté dentro del bounding box de Punta Alta
  const { latMin, latMax, lngMin, lngMax } = BBOX_PUNTA_ALTA;
  if (
    gps.lat < latMin ||
    gps.lat > latMax ||
    gps.lng < lngMin ||
    gps.lng > lngMax
  ) {
    return {
      autentico: false,
      razon: `Ubicación fuera del área de Punta Alta (lat: ${gps.lat.toFixed(5)}, lng: ${gps.lng.toFixed(5)}). Solo se aceptan reportes dentro del municipio.`,
    };
  }

  // 3. Verificar que el timestamp sea reciente (< 5 minutos)
  if (!timestamp) {
    return {
      autentico: false,
      razon: 'No se registró el timestamp del reporte.',
    };
  }

  const ahora = Date.now();
  const ts = timestamp instanceof Date ? timestamp.getTime() : Number(timestamp);
  const diffMs = ahora - ts;
  const CINCO_MINUTOS_MS = 5 * 60 * 1000;

  if (diffMs > CINCO_MINUTOS_MS) {
    const diffMin = Math.floor(diffMs / 60000);
    return {
      autentico: false,
      razon: `El reporte fue capturado hace ${diffMin} minuto(s). Por seguridad, solo se aceptan reportes de menos de 5 minutos.`,
    };
  }

  if (diffMs < 0) {
    return {
      autentico: false,
      razon: 'El timestamp del reporte es inválido (fecha futura).',
    };
  }

  // 4. Verificar que haya foto
  if (!foto) {
    return {
      autentico: false,
      razon: 'No se adjuntó foto al reporte.',
    };
  }

  return {
    autentico: true,
    razon: 'Reporte verificado correctamente.',
  };
}

// ── detectarDuplicado ─────────────────────────────────────────────────────────

/**
 * Detecta si existe un reporte duplicado cercano.
 * Recibe la lista de reportes ya cargados (evita llamada extra a Firestore).
 *
 * @param {number} lat
 * @param {number} lng
 * @param {Array<{id: string, lat: number, lng: number, tipo: string, activo: boolean}>} reportesExistentes
 * @param {string} [tipoFiltro] - Si se provee, solo compara contra reportes del mismo tipo
 * @returns {{duplicado: Object|null, distancia: number|null}}
 */
export function detectarDuplicado(lat, lng, reportesExistentes, tipoFiltro = null) {
  let masCoercano = null;
  let distanciaMin = Infinity;

  for (const reporte of reportesExistentes) {
    // Solo comparar activos
    if (!reporte.activo) continue;

    // Filtro opcional por tipo
    if (tipoFiltro && reporte.tipo !== tipoFiltro) continue;

    // Asegurar que las coordenadas existen
    const rLat = reporte.lat ?? reporte.geopoint?.latitude;
    const rLng = reporte.lng ?? reporte.geopoint?.longitude;
    if (rLat == null || rLng == null) continue;

    const dist = distanciaHaversine(lat, lng, rLat, rLng);

    if (dist < distanciaMin) {
      distanciaMin = dist;
      masCoercano = reporte;
    }
  }

  if (distanciaMin <= RADIO_DUPLICADO_M) {
    return {
      duplicado: masCoercano,
      distancia: Math.round(distanciaMin),
    };
  }

  return { duplicado: null, distancia: null };
}

// ── calcularReputacion ────────────────────────────────────────────────────────

/**
 * Calcula los puntos y nivel de reputación del usuario.
 * Aplica reglas RN-20 a RN-24.
 *
 * Reglas de puntuación:
 *  RN-20: +10 pts por reporte nuevo aceptado
 *  RN-21: +5  pts por reporte agrupado (apoyo a existente)
 *  RN-22: +20 pts cuando un reporte pasa a "resuelto"
 *  RN-23: -5  pts si el reporte es rechazado por baja confianza IA
 *  RN-24: Bonus +15 pts al completar 5 reportes en el mes
 *
 * Niveles:
 *  0–49   → Vecino Nuevo    (nivel 1)
 *  50–149 → Vecino Activo   (nivel 2)
 *  150–299 → Guardián Urbano (nivel 3)
 *  300+    → Héroe Ciudadano (nivel 4)
 *
 * @param {Array<{tipo: string, estado: string, agrupado: boolean, rechazado: boolean, fecha: Date}>} historialReportes
 * @returns {{puntos: number, nivel: number, nombreNivel: string, proximoNivel: string|null, progreso_pct: number}}
 */
export function calcularReputacion(historialReportes) {
  if (!Array.isArray(historialReportes) || historialReportes.length === 0) {
    return {
      puntos: 0,
      nivel: 1,
      nombreNivel: 'Vecino Nuevo',
      proximoNivel: 'Vecino Activo',
      progreso_pct: 0,
    };
  }

  let puntos = 0;
  const ahora = new Date();
  const inicioMes = new Date(ahora.getFullYear(), ahora.getMonth(), 1);

  // Contar reportes nuevos en el mes actual (para RN-24)
  let reportesMes = 0;

  for (const r of historialReportes) {
    if (r.rechazado) {
      // RN-23: penalización
      puntos -= 5;
      continue;
    }

    if (r.agrupado) {
      // RN-21: apoyo a reporte existente
      puntos += 5;
    } else {
      // RN-20: reporte nuevo aceptado
      puntos += 10;
    }

    // RN-22: reporte resuelto
    if (r.estado === 'resuelto') {
      puntos += 20;
    }

    // Conteo para RN-24
    const fecha = r.fecha instanceof Date ? r.fecha : new Date(r.fecha);
    if (!isNaN(fecha) && fecha >= inicioMes) {
      reportesMes++;
    }
  }

  // RN-24: bonus mensual cada 5 reportes
  const bonusMensual = Math.floor(reportesMes / 5) * 15;
  puntos += bonusMensual;

  // Asegurar puntos no negativos
  puntos = Math.max(0, puntos);

  // Tabla de niveles
  const niveles = [
    { min: 0,   max: 49,  nivel: 1, nombre: 'Vecino Nuevo',    proximo: 'Vecino Activo' },
    { min: 50,  max: 149, nivel: 2, nombre: 'Vecino Activo',   proximo: 'Guardián Urbano' },
    { min: 150, max: 299, nivel: 3, nombre: 'Guardián Urbano', proximo: 'Héroe Ciudadano' },
    { min: 300, max: Infinity, nivel: 4, nombre: 'Héroe Ciudadano', proximo: null },
  ];

  const nivelActual = niveles.find((n) => puntos >= n.min && puntos <= n.max);

  let progreso_pct = 0;
  if (nivelActual.nivel < 4) {
    const rango = nivelActual.max - nivelActual.min + 1;
    progreso_pct = Math.round(((puntos - nivelActual.min) / rango) * 100);
  } else {
    progreso_pct = 100;
  }

  return {
    puntos,
    nivel: nivelActual.nivel,
    nombreNivel: nivelActual.nombre,
    proximoNivel: nivelActual.proximo,
    progreso_pct,
  };
}

// ── Exportación agrupada (para imports nombrados) ─────────────────────────────
export default {
  clasificarImagen,
  verificarAutenticidad,
  detectarDuplicado,
  calcularReputacion,
  distanciaHaversine,
};
