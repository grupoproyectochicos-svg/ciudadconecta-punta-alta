/**
 * transporte.js — Módulo Transporte Público
 * CiudadConecta Punta Alta
 *
 * Clase TransporteModule
 * Predictor de demoras basado en baches reportados (Etapa 2)
 * Stack: Vanilla JS ES Modules + Firebase Firestore v10 CDN
 */

import {
  getFirestore,
  collection,
  getDocs,
  query,
  where,
} from '../firebase-init.js';

// ─── Datos hardcodeados de líneas de Punta Alta ──────────────────────────────
const lineas = [
  {
    id: 'L1',
    nombre: 'Línea 1 — Centro ↔ Base Naval',
    color: '#1a56db',
    colorLight: '#dbeafe',
    paradas: ['Terminal', 'Plaza Moreno', 'Av. Colón', 'Hospital', 'Base Naval'],
    descripcion: 'Recorrido principal de norte a sur',
  },
  {
    id: 'L2',
    nombre: 'Línea 2 — Circular Norte',
    color: '#057a55',
    colorLight: '#d1fae5',
    paradas: ['Terminal', 'Barrio Norte', 'Escuela Técnica', 'Parque', 'Terminal'],
    descripcion: 'Circuito barrios norte',
  },
  {
    id: 'L3',
    nombre: 'Línea 3 — Sur ↔ Estación',
    color: '#c27803',
    colorLight: '#fef3c7',
    paradas: ['Estación', 'Barrio Sur', 'Av. Independencia', 'Centro', 'Terminal'],
    descripcion: 'Conexión zona sur con terminal',
  },
];

// ─── Clase principal ──────────────────────────────────────────────────────────
export class TransporteModule {
  /**
   * @param {import('firebase/app').FirebaseApp} app - Instancia Firebase inicializada
   * @param {HTMLElement} container - Contenedor DOM donde se renderiza el módulo
   */
  constructor(app, container) {
    this.app = app;
    this.db = getFirestore(app);
    this.container = container;

    // Estado interno
    this.lineaSeleccionada = null;
    this.paradaOrigen = null;
    this.prediccionActual = null;
    this.notificaciones = this._cargarNotificaciones();
  }

  // ─── INIT ─────────────────────────────────────────────────────────────────

  async init() {
    this.render();
    this.renderizarLineas();
  }

  // ─── RENDER PRINCIPAL ─────────────────────────────────────────────────────

  render() {
    this.container.innerHTML = `
      <div class="transporte-module" id="transporte-root">
        <!-- HEADER -->
        <div class="transporte-header">
          <h2 class="transporte-title">🚌 Transporte Público</h2>
          <p class="transporte-subtitle">Punta Alta · Colectivos locales</p>
          <div class="banner-desarrollo">
            🚧 <strong>Predictor en desarrollo — Etapa 2</strong>
            · Datos simulados con reportes de baches
          </div>
        </div>

        <!-- SELECTOR DE LÍNEA -->
        <div class="lineas-section" id="lineas-section">
          <h3 class="section-title">Seleccioná una línea</h3>
          <div id="lineas-grid" class="lineas-grid">
            <!-- generado dinámicamente -->
          </div>
        </div>

        <!-- MAPA SVG + PARADAS -->
        <div id="mapa-section" class="mapa-section hidden">
          <div class="mapa-header">
            <h3 id="mapa-linea-nombre">—</h3>
            <button class="btn-back" id="btn-back-lineas">← Cambiar línea</button>
          </div>
          <div id="mapa-svg-container" class="mapa-svg-container">
            <!-- SVG generado dinámicamente -->
          </div>
          <div class="parada-selector">
            <label class="parada-label">¿Desde dónde tomás el colectivo?</label>
            <div id="paradas-list" class="paradas-list">
              <!-- generado dinámicamente -->
            </div>
          </div>
        </div>

        <!-- PREDICCIÓN -->
        <div id="prediccion-section" class="prediccion-section hidden">
          <!-- generado dinámicamente -->
        </div>

        <!-- HORARIOS DEL DÍA -->
        <div id="horarios-section" class="horarios-section hidden">
          <h3 class="section-title">📅 Horarios de hoy</h3>
          <div id="horarios-lista" class="horarios-lista">
            <!-- generado dinámicamente -->
          </div>
        </div>
      </div>

      <style>${this._estilos()}</style>
    `;

    this._bindEventos();
  }

  // ─── RENDERIZAR LÍNEAS ────────────────────────────────────────────────────

  renderizarLineas() {
    const grid = document.getElementById('lineas-grid');
    if (!grid) return;

    grid.innerHTML = lineas
      .map(
        (l) => `
        <div class="linea-card" data-id="${l.id}" tabindex="0" role="button"
             style="border-left:4px solid ${l.color}; background: ${l.colorLight}20;">
          <div class="linea-indicator" style="background:${l.color};">${l.id}</div>
          <div class="linea-info">
            <div class="linea-nombre" style="color:${l.color};">${l.nombre}</div>
            <div class="linea-desc">${l.descripcion}</div>
            <div class="linea-paradas-preview">
              ${l.paradas.slice(0, 3).join(' → ')}${l.paradas.length > 3 ? ' → …' : ''}
            </div>
          </div>
          <span class="linea-arrow">›</span>
        </div>
      `
      )
      .join('');

    // Bind clicks
    grid.querySelectorAll('.linea-card').forEach((card) => {
      card.addEventListener('click', () => this._seleccionarLinea(card.dataset.id));
    });
  }

  // ─── SELECCIONAR LÍNEA ────────────────────────────────────────────────────

  _seleccionarLinea(lineaId) {
    this.lineaSeleccionada = lineas.find((l) => l.id === lineaId);
    if (!this.lineaSeleccionada) return;

    // Mostrar sección mapa, ocultar selector
    document.getElementById('lineas-section')?.classList.add('hidden');
    document.getElementById('mapa-section')?.classList.remove('hidden');
    document.getElementById('horarios-section')?.classList.remove('hidden');
    document.getElementById('prediccion-section')?.classList.add('hidden');

    // Actualizar nombre
    const nombreEl = document.getElementById('mapa-linea-nombre');
    if (nombreEl) nombreEl.textContent = this.lineaSeleccionada.nombre;

    // Renderizar mapa SVG
    this._renderizarMapaSVG(this.lineaSeleccionada);

    // Renderizar paradas para selección
    this._renderizarParadas(this.lineaSeleccionada);

    // Renderizar horarios
    const horariosLista = document.getElementById('horarios-lista');
    if (horariosLista) {
      horariosLista.innerHTML = this.horariosDia(lineaId);
    }
  }

  // ─── MAPA SVG ESQUEMÁTICO ─────────────────────────────────────────────────

  _renderizarMapaSVG(linea) {
    const container = document.getElementById('mapa-svg-container');
    if (!container) return;

    const paradas = linea.paradas;
    const n = paradas.length;
    const svgW = Math.max(320, n * 70);
    const svgH = 100;
    const startX = 40;
    const stepX = (svgW - 80) / (n - 1);
    const cy = 50;

    // Línea de fondo y círculos
    let svgContent = `
      <svg viewBox="0 0 ${svgW} ${svgH}" xmlns="http://www.w3.org/2000/svg"
           style="width:100%;overflow:visible;">
        <!-- Línea del recorrido -->
        <line x1="${startX}" y1="${cy}" x2="${startX + stepX * (n - 1)}" y2="${cy}"
              stroke="${linea.color}" stroke-width="4" stroke-linecap="round"/>
    `;

    // Puntos de parada + etiquetas
    paradas.forEach((parada, i) => {
      const x = startX + stepX * i;
      const esTerminal = i === 0 || i === n - 1;
      svgContent += `
        <circle cx="${x}" cy="${cy}" r="${esTerminal ? 10 : 7}"
                fill="${linea.color}" stroke="#fff" stroke-width="2.5"/>
        <text x="${x}" y="${cy + 22}" text-anchor="middle"
              font-size="${i === 0 || i === n - 1 ? 10 : 9}"
              fill="#374151" font-family="sans-serif"
              font-weight="${esTerminal ? '700' : '400'}">
          ${parada.length > 9 ? parada.slice(0, 8) + '…' : parada}
        </text>
      `;
      if (esTerminal) {
        svgContent += `
          <text x="${x}" y="${cy + 4}" text-anchor="middle"
                font-size="7" fill="#fff" font-family="sans-serif">●</text>
        `;
      }
    });

    svgContent += '</svg>';
    container.innerHTML = svgContent;
  }

  // ─── PARADAS (SELECTOR) ───────────────────────────────────────────────────

  _renderizarParadas(linea) {
    const lista = document.getElementById('paradas-list');
    if (!lista) return;

    lista.innerHTML = linea.paradas
      .map(
        (parada, i) => `
        <button class="parada-btn" data-parada="${parada}" data-idx="${i}">
          <span class="parada-dot" style="background:${linea.color};"></span>
          ${parada}
        </button>
      `
      )
      .join('');

    lista.querySelectorAll('.parada-btn').forEach((btn) => {
      btn.addEventListener('click', async () => {
        lista.querySelectorAll('.parada-btn').forEach((b) => b.classList.remove('parada-selected'));
        btn.classList.add('parada-selected');
        this.paradaOrigen = btn.dataset.parada;
        await this._ejecutarPredictor();
      });
    });
  }

  // ─── SIMULADOR DE PREDICTOR ───────────────────────────────────────────────

  async simularPredictor(lineaId, paradaOrigen) {
    let bachesSeveros = 0;
    let bachesModerdos = 0;
    let motivoParts = [];

    // Consultar Firestore por reportes activos de baches/desagüe
    try {
      const q = query(
        collection(this.db, 'reportes'),
        where('activo', '==', true),
        where('tipo', 'in', ['bache', 'desague', 'bache_severo'])
      );
      const snap = await getDocs(q);
      snap.forEach((d) => {
        const data = d.data();
        if (data.severidad === 'alta' || data.tipo === 'bache_severo') bachesSeveros++;
        else bachesModerdos++;
      });
    } catch (err) {
      // Sin Firestore: usar valores simulados aleatorios
      bachesSeveros = Math.floor(Math.random() * 2);
      bachesModerdos = Math.floor(Math.random() * 3);
      console.warn('[TransporteModule] No se pudo consultar Firestore, usando datos simulados:', err);
    }

    // Calcular demora
    const demora_min = bachesSeveros * 2 + bachesModerdos * 1;

    if (bachesSeveros > 0)
      motivoParts.push(`${bachesSeveros} bache${bachesSeveros > 1 ? 's' : ''} severo${bachesSeveros > 1 ? 's' : ''}`);
    if (bachesModerdos > 0)
      motivoParts.push(`${bachesModerdos} bache${bachesModerdos > 1 ? 's' : ''} moderado${bachesModerdos > 1 ? 's' : ''}`);

    const motivo =
      motivoParts.length > 0
        ? `${motivoParts.join(' y ')} en la ruta`
        : 'Sin inconvenientes reportados';

    // Próximo colectivo simulado
    const ahora = new Date();
    const minutosBase = 8 + Math.floor(Math.random() * 12); // entre 8 y 20 min
    const proximo_en_min = minutosBase + demora_min;
    const proximoColectivo = new Date(ahora.getTime() + proximo_en_min * 60000);
    const hh = String(proximoColectivo.getHours()).padStart(2, '0');
    const mm = String(proximoColectivo.getMinutes()).padStart(2, '0');

    // Confianza del predictor
    const total = bachesSeveros + bachesModerdos;
    const confianza_pct = total === 0 ? 92 : Math.max(55, 92 - total * 8);

    return {
      demora_min,
      motivo,
      confianza_pct,
      proximo_colectivo_estimado: `${hh}:${mm}`,
      proximo_en_min,
      baches: { severos: bachesSeveros, moderados: bachesModerdos },
    };
  }

  // ─── EJECUTAR PREDICTOR ───────────────────────────────────────────────────

  async _ejecutarPredictor() {
    if (!this.lineaSeleccionada || !this.paradaOrigen) return;

    const seccion = document.getElementById('prediccion-section');
    if (seccion) {
      seccion.classList.remove('hidden');
      seccion.innerHTML = `
        <div class="prediccion-loading">
          <div class="loading-spinner"></div>
          <p>Consultando reportes de baches en la ruta…</p>
        </div>
      `;
    }

    const prediccion = await this.simularPredictor(this.lineaSeleccionada.id, this.paradaOrigen);
    this.prediccionActual = prediccion;
    this.renderizarPrediccion(prediccion);
  }

  // ─── RENDERIZAR PREDICCIÓN ────────────────────────────────────────────────

  renderizarPrediccion(prediccion) {
    const seccion = document.getElementById('prediccion-section');
    if (!seccion) return;

    const { demora_min, motivo, confianza_pct, proximo_colectivo_estimado, proximo_en_min, baches } = prediccion;
    const lineaColor = this.lineaSeleccionada?.color || '#1a56db';
    const hayDemora = demora_min > 0;

    // Badge de demora
    const demoraHtml = hayDemora
      ? `<div class="demora-badge">⚠️ Demora estimada: +${demora_min} min por ${motivo}</div>`
      : `<div class="sin-demora-badge">✅ Sin demoras reportadas en la ruta</div>`;

    // Baches en mapa mini (simulación textual)
    const bachesMapaHtml =
      baches.severos + baches.moderados > 0
        ? `
        <div class="baches-mapa">
          <h4>📍 Baches que afectan la ruta</h4>
          <div class="baches-list">
            ${Array.from({ length: baches.severos }, (_, i) =>
              `<div class="bache-pin bache-severo">🔴 Bache severo — Zona ${i + 1}</div>`
            ).join('')}
            ${Array.from({ length: baches.moderados }, (_, i) =>
              `<div class="bache-pin bache-moderado">🟡 Bache moderado — Zona ${baches.severos + i + 1}</div>`
            ).join('')}
          </div>
        </div>
      `
        : `<div class="sin-baches">🟢 No hay baches reportados afectando esta ruta</div>`;

    // Notificación activa
    const keyNotif = `${this.lineaSeleccionada?.id}_${this.paradaOrigen}`;
    const notifActiva = this.notificaciones.has(keyNotif);
    const btnNotifLabel = notifActiva
      ? '🔕 Cancelar notificación'
      : '🔔 Notificarme cuando salga';

    seccion.innerHTML = `
      <div class="prediccion-card" style="border-top:4px solid ${lineaColor};">
        <!-- Encabezado -->
        <div class="prediccion-header">
          <div>
            <p class="prediccion-desde">Desde <strong>${this.paradaOrigen}</strong></p>
            <p class="prediccion-linea" style="color:${lineaColor};">${this.lineaSeleccionada?.nombre}</p>
          </div>
          <div class="prediccion-tiempo-badge" style="background:${lineaColor};">
            <span class="prediccion-min">${proximo_en_min}</span>
            <span class="prediccion-min-label">min</span>
          </div>
        </div>

        <!-- Próximo colectivo -->
        <div class="proximo-colectivo-box">
          <span class="proximo-label">🚌 Próximo colectivo</span>
          <span class="proximo-hora">${proximo_colectivo_estimado}</span>
          <span class="proximo-sub">en aproximadamente ${proximo_en_min} minutos</span>
        </div>

        <!-- Demora -->
        ${demoraHtml}

        <!-- Barra de confianza -->
        <div class="confianza-section">
          <div class="confianza-header">
            <span class="confianza-label">Confianza del predictor</span>
            <span class="confianza-pct">${confianza_pct}%</span>
          </div>
          <div class="confianza-bar-bg">
            <div class="confianza-bar-fill"
                 style="width:${confianza_pct}%; background:${confianza_pct >= 80 ? '#057a55' : confianza_pct >= 60 ? '#c27803' : '#e02424'};">
            </div>
          </div>
          <p class="confianza-nota">Basado en reportes activos de la comunidad</p>
        </div>

        <!-- Mapa mini de baches -->
        ${bachesMapaHtml}

        <!-- Botón notificación -->
        <button class="btn-notificar ${notifActiva ? 'notif-activa' : ''}"
                id="btn-notificar" data-key="${keyNotif}">
          ${btnNotifLabel}
        </button>
      </div>
    `;

    // Bind notificación
    document.getElementById('btn-notificar')?.addEventListener('click', (e) => {
      this._toggleNotificacion(e.target.dataset.key, proximo_colectivo_estimado);
    });
  }

  // ─── HORARIOS DEL DÍA ─────────────────────────────────────────────────────

  horariosDia(lineaId) {
    const ahora = new Date();
    const horaActual = ahora.getHours() * 60 + ahora.getMinutes();
    const horarios = [];

    // Cada 30 min de 6:00 a 22:00
    for (let min = 6 * 60; min <= 22 * 60; min += 30) {
      const hh = String(Math.floor(min / 60)).padStart(2, '0');
      const mm = String(min % 60).padStart(2, '0');
      const diffMin = min - horaActual;
      const esPasado = diffMin < 0;
      const esProximo = !esPasado && horarios.filter((h) => !h.pasado).length === 0;

      horarios.push({ hora: `${hh}:${mm}`, esPasado, esProximo, diffMin });
    }

    const html = horarios
      .map((h) => {
        let cls = 'horario-item';
        if (h.esPasado) cls += ' horario-pasado';
        if (h.esProximo) cls += ' horario-proximo';
        const badge = h.esProximo
          ? `<span class="proximo-badge"><span class="proximo-dot"></span> PRÓXIMO</span>`
          : '';
        const diffLabel =
          !h.esPasado && h.diffMin > 0
            ? `<span class="horario-diff">en ${h.diffMin} min</span>`
            : '';
        return `
          <div class="${cls}">
            <span class="horario-hora">${h.hora}</span>
            ${badge}
            ${diffLabel}
          </div>
        `;
      })
      .join('');

    return `<div class="horarios-scroll">${html}</div>`;
  }

  // ─── NOTIFICACIONES (localStorage) ───────────────────────────────────────

  _cargarNotificaciones() {
    try {
      const data = localStorage.getItem('cc_transporte_notif');
      return data ? new Set(JSON.parse(data)) : new Set();
    } catch {
      return new Set();
    }
  }

  _guardarNotificaciones() {
    try {
      localStorage.setItem('cc_transporte_notif', JSON.stringify([...this.notificaciones]));
    } catch {}
  }

  _toggleNotificacion(key, hora) {
    const btn = document.getElementById('btn-notificar');
    if (this.notificaciones.has(key)) {
      this.notificaciones.delete(key);
      if (btn) {
        btn.textContent = '🔔 Notificarme cuando salga';
        btn.classList.remove('notif-activa');
      }
      this._mostrarToast('🔕 Notificación cancelada', 'info');
    } else {
      this.notificaciones.add(key);
      if (btn) {
        btn.textContent = '🔕 Cancelar notificación';
        btn.classList.add('notif-activa');
      }
      this._mostrarToast(`🔔 Te avisamos antes de las ${hora}`, 'success');
    }
    this._guardarNotificaciones();
  }

  // ─── EVENTOS ──────────────────────────────────────────────────────────────

  _bindEventos() {
    // Botón volver a líneas
    document.getElementById('btn-back-lineas')?.addEventListener('click', () => {
      document.getElementById('lineas-section')?.classList.remove('hidden');
      document.getElementById('mapa-section')?.classList.add('hidden');
      document.getElementById('prediccion-section')?.classList.add('hidden');
      document.getElementById('horarios-section')?.classList.add('hidden');
      this.lineaSeleccionada = null;
      this.paradaOrigen = null;
    });
  }

  // ─── UTILIDADES ───────────────────────────────────────────────────────────

  _mostrarToast(mensaje, tipo = 'info') {
    const colores = {
      success: '#057a55',
      error: '#c81e1e',
      info: '#1a56db',
    };
    const toast = document.createElement('div');
    toast.style.cssText = `
      position:fixed; bottom:80px; left:50%; transform:translateX(-50%);
      background:${colores[tipo]}; color:#fff; padding:12px 20px;
      border-radius:12px; font-size:14px; z-index:9999;
      box-shadow:0 4px 12px rgba(0,0,0,0.3); max-width:90vw; text-align:center;
      animation: fadeInUp 0.3s ease;
    `;
    toast.textContent = mensaje;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
  }

  // ─── ESTILOS ──────────────────────────────────────────────────────────────

  _estilos() {
    return `
      @keyframes fadeInUp {
        from { opacity:0; transform:translateX(-50%) translateY(10px); }
        to   { opacity:1; transform:translateX(-50%) translateY(0); }
      }
      @keyframes spin { to { transform:rotate(360deg); } }
      @keyframes pulse-proximo {
        0%,100% { opacity:1; box-shadow:0 0 0 0 rgba(5,122,85,0.4); }
        50%      { opacity:0.8; box-shadow:0 0 0 6px rgba(5,122,85,0); }
      }
      @keyframes blink {
        0%,100% { opacity:1; } 50% { opacity:0.4; }
      }

      .transporte-module { font-family:inherit; padding-bottom:80px; }

      /* HEADER */
      .transporte-header { padding:16px; background:#fff; border-bottom:1px solid #e5e7eb; }
      .transporte-title { font-size:20px; font-weight:700; margin:0 0 2px; }
      .transporte-subtitle { font-size:13px; color:#6b7280; margin:0 0 10px; }
      .banner-desarrollo {
        background:#fef3c7; border:1px solid #fde68a; border-radius:8px;
        padding:8px 12px; font-size:12px; color:#92400e;
      }

      /* LÍNEAS */
      .lineas-section { padding:16px; }
      .section-title { font-size:15px; font-weight:700; color:#111; margin:0 0 12px; }
      .lineas-grid { display:flex; flex-direction:column; gap:10px; }
      .linea-card {
        display:flex; align-items:center; gap:12px;
        background:#fff; border:1.5px solid #e5e7eb; border-radius:12px;
        padding:14px 12px; cursor:pointer; transition:all 0.2s;
        box-shadow:0 1px 3px rgba(0,0,0,0.05);
      }
      .linea-card:hover { box-shadow:0 4px 12px rgba(0,0,0,0.1); transform:translateY(-1px); }
      .linea-indicator {
        width:40px; height:40px; border-radius:10px; display:flex;
        align-items:center; justify-content:center; font-size:13px;
        font-weight:800; color:#fff; flex-shrink:0;
      }
      .linea-info { flex:1; }
      .linea-nombre { font-size:14px; font-weight:700; margin-bottom:2px; }
      .linea-desc { font-size:11px; color:#6b7280; margin-bottom:3px; }
      .linea-paradas-preview { font-size:11px; color:#9ca3af; }
      .linea-arrow { font-size:22px; color:#9ca3af; }

      /* MAPA */
      .mapa-section { padding:16px; }
      .mapa-header {
        display:flex; justify-content:space-between; align-items:center;
        margin-bottom:12px;
      }
      .mapa-header h3 { font-size:14px; font-weight:700; margin:0; flex:1; padding-right:8px; }
      .btn-back {
        background:#f3f4f6; border:1px solid #d1d5db; border-radius:8px;
        padding:6px 12px; font-size:12px; cursor:pointer; white-space:nowrap;
      }
      .mapa-svg-container {
        background:#f9fafb; border:1px solid #e5e7eb; border-radius:12px;
        padding:16px 8px 24px; overflow-x:auto; margin-bottom:16px;
      }

      /* PARADAS */
      .parada-label { font-size:13px; font-weight:600; color:#374151; display:block; margin-bottom:8px; }
      .paradas-list { display:flex; flex-wrap:wrap; gap:8px; }
      .parada-btn {
        display:flex; align-items:center; gap:6px;
        background:#fff; border:1.5px solid #d1d5db; border-radius:20px;
        padding:7px 14px; font-size:13px; cursor:pointer; transition:all 0.2s;
      }
      .parada-btn:hover { border-color:#1a56db; }
      .parada-btn.parada-selected { background:#1a56db; color:#fff; border-color:#1a56db; }
      .parada-dot {
        width:8px; height:8px; border-radius:50%; flex-shrink:0;
      }

      /* PREDICCIÓN */
      .prediccion-section { padding:0 16px 16px; }
      .prediccion-loading {
        display:flex; align-items:center; gap:12px;
        padding:20px; background:#f9fafb; border-radius:12px;
        font-size:13px; color:#6b7280;
      }
      .loading-spinner {
        width:24px; height:24px; border:3px solid #e5e7eb;
        border-top-color:#1a56db; border-radius:50%;
        animation:spin 0.8s linear infinite; flex-shrink:0;
      }

      .prediccion-card {
        background:#fff; border:1.5px solid #e5e7eb; border-radius:14px;
        overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.07);
      }

      /* Header de predicción */
      .prediccion-header {
        display:flex; justify-content:space-between; align-items:center;
        padding:14px 16px; border-bottom:1px solid #e5e7eb;
      }
      .prediccion-desde { font-size:12px; color:#6b7280; margin:0 0 2px; }
      .prediccion-linea { font-size:13px; font-weight:700; margin:0; }
      .prediccion-tiempo-badge {
        width:60px; height:60px; border-radius:50%;
        display:flex; flex-direction:column; align-items:center;
        justify-content:center; flex-shrink:0;
      }
      .prediccion-min { font-size:22px; font-weight:900; color:#fff; line-height:1; }
      .prediccion-min-label { font-size:10px; color:rgba(255,255,255,0.8); }

      /* Próximo colectivo */
      .proximo-colectivo-box {
        display:flex; flex-direction:column; align-items:center;
        padding:16px; background:#f0fdf4; border-bottom:1px solid #bbf7d0;
      }
      .proximo-label { font-size:12px; color:#374151; margin-bottom:4px; }
      .proximo-hora {
        font-size:36px; font-weight:900; color:#057a55;
        animation:pulse-proximo 2s infinite;
      }
      .proximo-sub { font-size:12px; color:#6b7280; margin-top:2px; }

      /* Demora */
      .demora-badge {
        background:#fef3c7; border-left:4px solid #f59e0b;
        padding:10px 16px; font-size:13px; font-weight:600; color:#92400e;
      }
      .sin-demora-badge {
        background:#f0fdf4; border-left:4px solid #34d399;
        padding:10px 16px; font-size:13px; font-weight:600; color:#065f46;
      }

      /* Confianza */
      .confianza-section { padding:12px 16px; border-top:1px solid #e5e7eb; }
      .confianza-header { display:flex; justify-content:space-between; margin-bottom:6px; }
      .confianza-label { font-size:12px; color:#6b7280; }
      .confianza-pct { font-size:12px; font-weight:700; color:#374151; }
      .confianza-bar-bg {
        height:6px; background:#e5e7eb; border-radius:3px; overflow:hidden;
        margin-bottom:4px;
      }
      .confianza-bar-fill {
        height:100%; border-radius:3px; transition:width 0.5s ease;
      }
      .confianza-nota { font-size:11px; color:#9ca3af; margin:0; }

      /* Baches mapa mini */
      .baches-mapa { padding:12px 16px; border-top:1px solid #e5e7eb; }
      .baches-mapa h4 { font-size:12px; font-weight:700; margin:0 0 8px; color:#374151; }
      .baches-list { display:flex; flex-direction:column; gap:4px; }
      .bache-pin {
        font-size:12px; padding:5px 10px; border-radius:6px;
      }
      .bache-severo { background:#fee2e2; color:#991b1b; }
      .bache-moderado { background:#fef3c7; color:#92400e; }
      .sin-baches {
        padding:10px 16px; background:#f0fdf4;
        font-size:12px; color:#065f46; border-top:1px solid #e5e7eb;
      }

      /* Botón notificar */
      .btn-notificar {
        width:100%; padding:14px; background:#f3f4f6;
        border:none; font-size:14px; font-weight:600;
        color:#374151; cursor:pointer; border-top:1px solid #e5e7eb;
        transition:all 0.2s;
      }
      .btn-notificar:hover { background:#e5e7eb; }
      .notif-activa { background:#fef3c7 !important; color:#92400e !important; }

      /* HORARIOS */
      .horarios-section { padding:0 16px 16px; }
      .horarios-scroll {
        display:flex; flex-wrap:wrap; gap:6px;
        max-height:180px; overflow-y:auto;
        padding:4px 0;
      }
      .horario-item {
        display:flex; align-items:center; gap:6px;
        padding:7px 12px; border-radius:20px;
        border:1.5px solid #e5e7eb; background:#fff;
        font-size:13px; color:#374151;
        transition:all 0.2s;
      }
      .horario-pasado { opacity:0.35; }
      .horario-proximo {
        background:#f0fdf4; border-color:#34d399;
        font-weight:700; color:#057a55;
      }
      .horario-hora { font-weight:600; }
      .horario-diff { font-size:10px; color:#6b7280; }
      .proximo-badge {
        display:flex; align-items:center; gap:4px;
        background:#057a55; color:#fff; border-radius:10px;
        padding:2px 7px; font-size:10px; font-weight:700;
      }
      .proximo-dot {
        width:6px; height:6px; border-radius:50%; background:#fff;
        animation:blink 1s infinite;
      }

      /* HIDDEN */
      .hidden { display:none !important; }
    `;
  }
}
