/**
 * empleo.js — Módulo Empleo Local
 * CiudadConecta Punta Alta
 *
 * Clase EmpleoModule
 * Reglas de negocio: RN-30 a RN-34
 * Stack: Vanilla JS ES Modules + Firebase Firestore v10 CDN
 */

import {
  getFirestore,
  collection,
  getDocs,
  addDoc,
  doc,
  getDoc,
  updateDoc,
  increment,
  query,
  where,
  orderBy,
  Timestamp,
} from '../firebase-init.js';

// ─── Datos demo hardcodeados ────────────────────────────────────────────────
const empleosDemo = [
  {
    id: 'demo-1',
    titulo: 'Repositor/a',
    comercio: 'Supermercado Central',
    comercio_emoji: '🛒',
    turno: 'mañana',
    contrato: 'part-time',
    salario: '$450.000/mes',
    descripcion:
      'Buscamos persona activa para reposición de mercadería en góndolas. ' +
      'Turno mañana de lunes a sábado. Buen ambiente de trabajo.',
    requisitos: ['Mayor de 18 años', 'Disponibilidad horaria', 'Responsabilidad'],
    sugerencias_capacitacion: ['Curso de manipulación de alimentos (INTI)', 'Logística básica'],
    fecha_publicacion: new Date(Date.now() - 2 * 86400000),
    estado: 'publicado',
    postulaciones_count: 4,
    audio_url: null,
    ia_generado: false,
  },
  {
    id: 'demo-2',
    titulo: 'Asistente de panadería',
    comercio: 'Panadería El Trigo',
    comercio_emoji: '🥖',
    turno: 'mañana',
    contrato: 'full-time',
    salario: '$520.000/mes',
    descripcion:
      'Necesitamos asistente para producción de pan artesanal. ' +
      'Experiencia deseable pero no excluyente. Capacitación en el puesto.',
    requisitos: ['Puntualidad', 'Trabajo en equipo', 'Resistencia física'],
    sugerencias_capacitacion: ['Curso de panadería artesanal (UOCRA)', 'Buenas Prácticas de Manufactura'],
    fecha_publicacion: new Date(Date.now() - 5 * 86400000),
    estado: 'publicado',
    postulaciones_count: 7,
    audio_url: null,
    ia_generado: true,
  },
  {
    id: 'demo-3',
    titulo: 'Mozo/Moza',
    comercio: 'Bar Los Amigos',
    comercio_emoji: '☕',
    turno: 'tarde',
    contrato: 'part-time',
    salario: '$400.000/mes + propinas',
    descripcion:
      'Bar céntrico busca mozo/moza con ganas de trabajar. ' +
      'Horario de 17:00 a 23:00 de jueves a domingo. Propinas incluidas.',
    requisitos: ['Buena presencia', 'Trato amable', 'Experiencia deseable'],
    sugerencias_capacitacion: ['Barismo básico', 'Atención al cliente'],
    fecha_publicacion: new Date(Date.now() - 1 * 86400000),
    estado: 'publicado',
    postulaciones_count: 12,
    audio_url: null,
    ia_generado: false,
  },
  {
    id: 'demo-4',
    titulo: 'Cajero/a',
    comercio: 'Farmacia San Martín',
    comercio_emoji: '💊',
    turno: 'rotativo',
    contrato: 'full-time',
    salario: '$580.000/mes',
    descripcion:
      'Farmacia busca cajero/a para atención al público. ' +
      'Turnos rotativos mañana y tarde. Obra social incluida desde el primer día.',
    requisitos: ['Secundario completo', 'Manejo de caja', 'Discreción'],
    sugerencias_capacitacion: ['Farmacología básica para no profesionales', 'Gestión de stock'],
    fecha_publicacion: new Date(Date.now() - 8 * 86400000),
    estado: 'publicado',
    postulaciones_count: 3,
    audio_url: null,
    ia_generado: true,
  },
  {
    id: 'demo-5',
    titulo: 'Asistente de librería',
    comercio: 'Librería Saber',
    comercio_emoji: '📚',
    turno: 'tarde',
    contrato: 'temporal',
    salario: '$380.000/mes',
    descripcion:
      'Librería busca asistente para la temporada escolar. ' +
      'Atención al cliente, manejo de caja y organización del local.',
    requisitos: ['Secundario completo', 'Dinamismo', 'Conocimiento de productos escolares'],
    sugerencias_capacitacion: ['Gestión comercial básica', 'Atención al cliente'],
    fecha_publicacion: new Date(Date.now() - 3 * 86400000),
    estado: 'publicado',
    postulaciones_count: 9,
    audio_url: null,
    ia_generado: false,
  },
];

// ─── Iconos de turno ────────────────────────────────────────────────────────
const TURNO_ICONS = {
  mañana: '🌅',
  tarde: '🌆',
  noche: '🌙',
  rotativo: '🔄',
};

// ─── Simulaciones de textos IA ───────────────────────────────────────────────
const TRANSCRIPCIONES_DEMO = [
  'Hola, somos del almacén La Esquina, acá en Punta Alta. Estamos buscando una persona para atender el mostrador, ' +
    'de lunes a viernes por las mañanas, de ocho a doce. Que tenga ganas de trabajar, que sea puntual. ' +
    'Pagamos mensual, en mano. Si te interesa podés venir directamente al local.',
  'Busco mecánico o mecánica para el taller. Que sepa de autos, preferentemente que tenga experiencia. ' +
    'Trabajamos de lunes a sábado. Hay buen ambiente, somos un equipo chico. ' +
    'El sueldo lo arreglamos según experiencia.',
];

// ─── Clase principal ─────────────────────────────────────────────────────────
export class EmpleoModule {
  /**
   * @param {import('firebase/app').FirebaseApp} app - Instancia Firebase inicializada
   * @param {HTMLElement} container - Contenedor DOM donde se renderiza el módulo
   */
  constructor(app, container) {
    this.app = app;
    this.db = getFirestore(app);
    this.container = container;

    // Estado interno
    this.modoComerciantActive = false;
    this.empleos = [...empleosDemo]; // lista de trabajo (demo + Firestore)
    this.empleosFiltrados = [...empleosDemo];
    this.empleoDetalleActivo = null;
    this.filtroContrato = 'todos';
    this.filtroTurno = 'todos';
    this.busquedaTexto = '';

    // Estado de grabación
    this.mediaRecorder = null;
    this.audioChunks = [];
    this.audioBlob = null;
    this.timerInterval = null;
    this.grabacionSegundos = 0;

    // Estado comerciante
    this.comercianteCuit = '';
    this.comercianteNombre = '';
    this.comercianteVerificado = false;
    this.aviso = null; // borrador IA
  }

  // ─── INIT ────────────────────────────────────────────────────────────────

  async init() {
    this.render();
    await this._cargarEmpleosFirestore();
    this._aplicarFiltros();
    this._renderizarListaEmpleos();
  }

  // ─── RENDER PRINCIPAL ────────────────────────────────────────────────────

  render() {
    this.container.innerHTML = `
      <div class="empleo-module" id="empleo-root">
        <!-- HEADER -->
        <div class="empleo-header">
          <div class="empleo-header-top">
            <div>
              <h2 class="empleo-title">💼 Empleo Local</h2>
              <p class="empleo-subtitle">Ofertas de trabajo en Punta Alta</p>
            </div>
            <button class="btn-comerciante" id="btn-toggle-comerciante">
              Soy comerciante 🏪
            </button>
          </div>

          <!-- MODO VECINO: Buscador y filtros -->
          <div id="seccion-busqueda" class="seccion-busqueda">
            <div class="search-box">
              <span class="search-icon">🔍</span>
              <input
                type="text"
                id="empleo-search"
                class="search-input"
                placeholder="Buscar empleo por título o descripción..."
              />
            </div>

            <!-- Filtros por contrato -->
            <div class="filtros-row">
              <button class="filtro-btn active" data-contrato="todos">Todos</button>
              <button class="filtro-btn" data-contrato="full-time">Tiempo completo</button>
              <button class="filtro-btn" data-contrato="part-time">Medio tiempo</button>
              <button class="filtro-btn" data-contrato="temporal">Temporal</button>
            </div>

            <!-- Filtro por turno -->
            <div class="filtros-row filtros-turno">
              <span class="filtro-label">Turno:</span>
              <button class="filtro-turno-btn active" data-turno="todos">Todos</button>
              <button class="filtro-turno-btn" data-turno="mañana">🌅 Mañana</button>
              <button class="filtro-turno-btn" data-turno="tarde">🌆 Tarde</button>
              <button class="filtro-turno-btn" data-turno="noche">🌙 Noche</button>
              <button class="filtro-turno-btn" data-turno="rotativo">🔄 Rotativo</button>
            </div>
          </div>

          <!-- MODO COMERCIANTE: Panel de verificación -->
          <div id="seccion-comerciante" class="seccion-comerciante hidden">
            <div id="panel-verificacion">
              <h3>🔐 Verificación de comerciante</h3>
              <p class="verificacion-info">Para publicar empleos necesitás verificar tu CUIT. (RN-30)</p>
              <div class="form-group">
                <label>CUIT del comercio</label>
                <input type="text" id="input-cuit" placeholder="XX-XXXXXXXX-X" maxlength="13" class="form-input" />
                <span class="form-hint">Formato: 30-12345678-9</span>
              </div>
              <div class="form-group">
                <label>Nombre del comercio</label>
                <input type="text" id="input-nombre-comercio" placeholder="Ej: Almacén La Esquina" class="form-input" />
              </div>
              <button class="btn-primary" id="btn-verificar-cuit">Verificar y continuar →</button>
            </div>

            <div id="panel-publicar" class="hidden">
              <div class="comerciante-badge">
                <span>✅ Comercio verificado:</span>
                <strong id="label-nombre-comercio">—</strong>
              </div>

              <!-- Grabación de audio -->
              <div class="audio-section">
                <h3>🎙️ Describí el empleo con tu voz</h3>
                <p class="audio-info">Grabá entre 30 segundos y 3 minutos. La IA va a generar el aviso. (RN-31 / RN-32)</p>
                <div class="audio-controls">
                  <button class="btn-grabar" id="btn-grabar">⏺ Iniciar grabación</button>
                  <div class="timer-display hidden" id="timer-display">
                    <span class="timer-dot"></span>
                    <span id="timer-text">0:00</span>
                    <span id="timer-status">Grabando...</span>
                  </div>
                </div>
                <div id="audio-preview" class="hidden">
                  <p class="audio-preview-label">🔊 Tu grabación:</p>
                  <audio id="audio-player" controls class="audio-player"></audio>
                  <button class="btn-secondary" id="btn-transcribir">✨ Generar aviso con IA</button>
                </div>
              </div>

              <!-- Vista previa editable -->
              <div id="vista-previa-ia" class="hidden">
                <div class="ia-badge">✨ Generado con IA — Revisá y confirmá antes de publicar</div>
                <div class="form-group">
                  <label>Título del aviso</label>
                  <input type="text" id="preview-titulo" class="form-input" />
                </div>
                <div class="form-group">
                  <label>Descripción</label>
                  <textarea id="preview-descripcion" class="form-textarea" rows="4"></textarea>
                </div>
                <div class="form-group">
                  <label>Turno</label>
                  <select id="preview-turno" class="form-input">
                    <option value="mañana">🌅 Mañana</option>
                    <option value="tarde">🌆 Tarde</option>
                    <option value="noche">🌙 Noche</option>
                    <option value="rotativo">🔄 Rotativo</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Tipo de contrato</label>
                  <select id="preview-contrato" class="form-input">
                    <option value="part-time">Medio tiempo</option>
                    <option value="full-time">Tiempo completo</option>
                    <option value="temporal">Temporal</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>Salario de referencia</label>
                  <input type="text" id="preview-salario" class="form-input" placeholder="Ej: $500.000/mes" />
                </div>
                <div class="ia-sugerencias" id="preview-sugerencias"></div>
                <button class="btn-primary btn-publicar" id="btn-confirmar-publicar">
                  ✅ Confirmar y Publicar
                </button>
              </div>

              <!-- Mis empleos publicados -->
              <div class="mis-empleos-section">
                <h3>📋 Mis avisos publicados</h3>
                <div id="lista-mis-empleos">
                  <p class="empty-state-small">No publicaste avisos aún.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- CUERPO: lista + detalle -->
        <div class="empleo-body" id="empleo-body">
          <div class="empleo-lista-wrapper">
            <div id="empleo-lista" class="empleo-lista">
              <!-- cards generados dinámicamente -->
            </div>
          </div>

          <!-- Panel lateral de detalle -->
          <div id="empleo-detalle" class="empleo-detalle hidden">
            <button class="btn-cerrar-detalle" id="btn-cerrar-detalle">✕ Cerrar</button>
            <div id="empleo-detalle-content"></div>
          </div>
        </div>
      </div>

      <style>${this._estilos()}</style>
    `;

    this._bindEventos();
  }

  // ─── CARGA DESDE FIRESTORE ───────────────────────────────────────────────

  async _cargarEmpleosFirestore() {
    try {
      const q = query(
        collection(this.db, 'empleos'),
        where('activo', '==', true),
        orderBy('fecha_publicacion', 'desc')
      );
      const snap = await getDocs(q);
      const empleosFS = [];
      snap.forEach((d) => {
        const data = d.data();
        empleosFS.push({
          id: d.id,
          titulo: data.titulo,
          comercio: data.comercio_id || 'Comercio',
          comercio_emoji: '🏪',
          turno: data.turno,
          contrato: data.tipo_contrato,
          salario: data.salario_referencia || 'A convenir',
          descripcion: data.descripcion_texto || '',
          requisitos: data.requisitos || [],
          sugerencias_capacitacion: data.sugerencias_capacitacion || [],
          fecha_publicacion: data.fecha_publicacion?.toDate() || new Date(),
          estado: data.estado,
          postulaciones_count: data.postulaciones_count || 0,
          audio_url: data.audio_url || null,
          ia_generado: data.ia_generado || false,
        });
      });
      // Mezcla: demo primero, luego Firestore (sin duplicados)
      const idsDemo = new Set(this.empleos.map((e) => e.id));
      empleosFS.forEach((e) => {
        if (!idsDemo.has(e.id)) this.empleos.push(e);
      });
    } catch (err) {
      console.warn('[EmpleoModule] No se pudo cargar Firestore, usando datos demo.', err);
    }
  }

  // ─── FILTROS Y BÚSQUEDA ──────────────────────────────────────────────────

  _aplicarFiltros() {
    let lista = [...this.empleos];

    if (this.filtroContrato !== 'todos') {
      lista = lista.filter((e) => e.contrato === this.filtroContrato);
    }
    if (this.filtroTurno !== 'todos') {
      lista = lista.filter((e) => e.turno === this.filtroTurno);
    }
    if (this.busquedaTexto.trim()) {
      const q = this.busquedaTexto.toLowerCase();
      lista = lista.filter(
        (e) =>
          e.titulo.toLowerCase().includes(q) ||
          (e.descripcion && e.descripcion.toLowerCase().includes(q))
      );
    }

    // Ordenar por fecha desc
    lista.sort((a, b) => b.fecha_publicacion - a.fecha_publicacion);
    this.empleosFiltrados = lista;
  }

  // ─── RENDERIZAR LISTA ────────────────────────────────────────────────────

  renderizarListaEmpleos() {
    this._renderizarListaEmpleos();
  }

  _renderizarListaEmpleos() {
    const lista = document.getElementById('empleo-lista');
    if (!lista) return;

    if (this.empleosFiltrados.length === 0) {
      lista.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">💼</div>
          <p>No hay empleos activos en este momento</p>
          <p class="empty-sub">¿Sos comerciante? Publicá tu búsqueda</p>
          <button class="btn-secondary" onclick="document.getElementById('btn-toggle-comerciante').click()">
            Publicar empleo 🏪
          </button>
        </div>
      `;
      return;
    }

    lista.innerHTML = this.empleosFiltrados.map((e) => this._cardEmpleo(e)).join('');

    // Bind botones "Postularme" y click en card
    lista.querySelectorAll('.btn-postular').forEach((btn) => {
      btn.addEventListener('click', (ev) => {
        ev.stopPropagation();
        this.postularAEmpleo(btn.dataset.id);
      });
    });
    lista.querySelectorAll('.empleo-card').forEach((card) => {
      card.addEventListener('click', () => {
        this.mostrarDetalleEmpleo(card.dataset.id);
      });
    });
  }

  _cardEmpleo(e) {
    const diasAtras = Math.floor((Date.now() - e.fecha_publicacion) / 86400000);
    const turnoIcon = TURNO_ICONS[e.turno] || '⏰';
    const contratoBadge = {
      'part-time': { label: 'Medio tiempo', class: 'badge-blue' },
      'full-time': { label: 'Tiempo completo', class: 'badge-green' },
      temporal: { label: 'Temporal', class: 'badge-orange' },
    }[e.contrato] || { label: e.contrato, class: 'badge-gray' };

    return `
      <div class="empleo-card" data-id="${e.id}" tabindex="0" role="button">
        <div class="card-header-row">
          <div>
            <h3 class="card-titulo">${e.titulo}${e.ia_generado ? ' <span class="ia-mini-badge">✨ IA</span>' : ''}</h3>
            <p class="card-comercio">${e.comercio_emoji} ${e.comercio}</p>
          </div>
          <span class="badge ${contratoBadge.class}">${contratoBadge.label}</span>
        </div>
        <div class="card-meta">
          <span class="turno-tag">${turnoIcon} ${e.turno.charAt(0).toUpperCase() + e.turno.slice(1)}</span>
          <span class="salario-tag">💰 ${e.salario}</span>
        </div>
        <div class="card-footer-row">
          <span class="fecha-tag">📅 Publicado hace ${diasAtras === 0 ? 'hoy' : diasAtras + ' día' + (diasAtras > 1 ? 's' : '')}</span>
          <button class="btn-postular" data-id="${e.id}">Postularme →</button>
        </div>
      </div>
    `;
  }

  // ─── DETALLE DE EMPLEO ───────────────────────────────────────────────────

  mostrarDetalleEmpleo(empleoId) {
    const empleo = this.empleos.find((e) => e.id === empleoId);
    if (!empleo) return;

    this.empleoDetalleActivo = empleoId;
    const panel = document.getElementById('empleo-detalle');
    const content = document.getElementById('empleo-detalle-content');
    if (!panel || !content) return;

    const turnoIcon = TURNO_ICONS[empleo.turno] || '⏰';
    const requisitosHtml =
      empleo.requisitos.length
        ? `<ul class="detalle-lista">${empleo.requisitos.map((r) => `<li>✓ ${r}</li>`).join('')}</ul>`
        : '<p>Sin requisitos especificados</p>';

    const sugerenciasHtml =
      empleo.sugerencias_capacitacion.length
        ? `<div class="detalle-sugerencias">
            <h4>📖 Sugerencias de capacitación (RN-34 — informativas)</h4>
            <ul class="detalle-lista sugerencias-lista">
              ${empleo.sugerencias_capacitacion.map((s) => `<li>💡 ${s}</li>`).join('')}
            </ul>
          </div>`
        : '';

    const audioHtml =
      empleo.audio_url
        ? `<div class="detalle-audio">
            <h4>🎙️ Audio del comerciante</h4>
            <audio controls src="${empleo.audio_url}" class="audio-player"></audio>
          </div>`
        : '';

    content.innerHTML = `
      <div class="detalle-header">
        <h2>${empleo.titulo}</h2>
        ${empleo.ia_generado ? '<span class="ia-badge-detalle">✨ Generado con IA</span>' : ''}
      </div>
      <p class="detalle-comercio">${empleo.comercio_emoji} <strong>${empleo.comercio}</strong></p>

      <div class="detalle-meta-grid">
        <div class="detalle-meta-item">
          <span class="meta-label">Turno</span>
          <span class="meta-value">${turnoIcon} ${empleo.turno}</span>
        </div>
        <div class="detalle-meta-item">
          <span class="meta-label">Contrato</span>
          <span class="meta-value">${empleo.contrato}</span>
        </div>
        <div class="detalle-meta-item">
          <span class="meta-label">Salario</span>
          <span class="meta-value">💰 ${empleo.salario}</span>
        </div>
        <div class="detalle-meta-item">
          <span class="meta-label">Postulaciones</span>
          <span class="meta-value">👥 ${empleo.postulaciones_count}</span>
        </div>
      </div>

      <div class="detalle-descripcion">
        <h4>📋 Descripción</h4>
        <p>${empleo.descripcion || 'Sin descripción disponible.'}</p>
      </div>

      <div class="detalle-requisitos">
        <h4>✅ Requisitos</h4>
        ${requisitosHtml}
      </div>

      ${sugerenciasHtml}
      ${audioHtml}

      <button class="btn-primary btn-postular-detalle" data-id="${empleo.id}">
        📩 Postularme a este empleo
      </button>
    `;

    panel.classList.remove('hidden');

    content.querySelector('.btn-postular-detalle').addEventListener('click', (ev) => {
      this.postularAEmpleo(ev.target.dataset.id);
    });
  }

  // ─── POSTULACIÓN ─────────────────────────────────────────────────────────

  async postularAEmpleo(empleoId) {
    const empleo = this.empleos.find((e) => e.id === empleoId);
    if (!empleo) return;

    // Feedback inmediato
    this._mostrarToast(`📩 ¡Te postulaste a "${empleo.titulo}"!`, 'success');
    empleo.postulaciones_count++;

    // Actualizar en Firestore si no es demo
    if (!empleoId.startsWith('demo-')) {
      try {
        await updateDoc(doc(this.db, 'empleos', empleoId), {
          postulaciones_count: increment(1),
        });
        await addDoc(collection(this.db, 'postulaciones'), {
          empleo_id: empleoId,
          fecha: Timestamp.now(),
          estado: 'pendiente',
        });
      } catch (err) {
        console.warn('[EmpleoModule] Error actualizando postulación en Firestore:', err);
      }
    }

    // Actualizar UI
    this._renderizarListaEmpleos();
    if (this.empleoDetalleActivo === empleoId) {
      this.mostrarDetalleEmpleo(empleoId);
    }
  }

  // ─── VERIFICACIÓN CUIT ───────────────────────────────────────────────────

  _validarCuit(cuit) {
    // Formato XX-XXXXXXXX-X
    return /^\d{2}-\d{8}-\d$/.test(cuit);
  }

  _verificarComerciante() {
    const cuitInput = document.getElementById('input-cuit');
    const nombreInput = document.getElementById('input-nombre-comercio');
    const cuit = cuitInput?.value.trim();
    const nombre = nombreInput?.value.trim();

    if (!this._validarCuit(cuit)) {
      this._mostrarToast('⚠️ CUIT inválido. Formato: XX-XXXXXXXX-X', 'error');
      cuitInput?.classList.add('input-error');
      return;
    }
    if (!nombre || nombre.length < 3) {
      this._mostrarToast('⚠️ Ingresá el nombre del comercio', 'error');
      return;
    }

    this.comercianteCuit = cuit;
    this.comercianteNombre = nombre;
    this.comercianteVerificado = true;

    document.getElementById('panel-verificacion')?.classList.add('hidden');
    document.getElementById('panel-publicar')?.classList.remove('hidden');
    const labelNombre = document.getElementById('label-nombre-comercio');
    if (labelNombre) labelNombre.textContent = nombre;

    this._mostrarToast('✅ Comercio verificado. ¡Podés publicar!', 'success');
  }

  // ─── GRABACIÓN DE AUDIO ──────────────────────────────────────────────────

  async grabarAudioEmpleo() {
    const btnGrabar = document.getElementById('btn-grabar');

    if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
      // Detener grabación
      this.mediaRecorder.stop();
      clearInterval(this.timerInterval);
      btnGrabar.textContent = '⏺ Iniciar grabación';
      document.getElementById('timer-display')?.classList.add('hidden');
      return;
    }

    // Verificar duración mínima
    if (this.grabacionSegundos > 0 && this.grabacionSegundos < 30) {
      this._mostrarToast('⚠️ La grabación debe ser de al menos 30 segundos (RN-31)', 'error');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.audioChunks = [];
      this.grabacionSegundos = 0;

      this.mediaRecorder = new MediaRecorder(stream);
      this.mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) this.audioChunks.push(e.data);
      };
      this.mediaRecorder.onstop = () => {
        this.audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
        const url = URL.createObjectURL(this.audioBlob);
        const player = document.getElementById('audio-player');
        if (player) player.src = url;
        document.getElementById('audio-preview')?.classList.remove('hidden');
        stream.getTracks().forEach((t) => t.stop());
      };

      this.mediaRecorder.start();
      btnGrabar.textContent = '⏹ Detener grabación';
      document.getElementById('timer-display')?.classList.remove('hidden');

      // Timer
      this.timerInterval = setInterval(() => {
        this.grabacionSegundos++;
        const min = Math.floor(this.grabacionSegundos / 60);
        const sec = String(this.grabacionSegundos % 60).padStart(2, '0');
        const timerText = document.getElementById('timer-text');
        if (timerText) timerText.textContent = `${min}:${sec}`;

        // Máximo 3 minutos (RN-31)
        if (this.grabacionSegundos >= 180) {
          this.mediaRecorder.stop();
          clearInterval(this.timerInterval);
          btnGrabar.textContent = '⏺ Iniciar grabación';
          document.getElementById('timer-display')?.classList.add('hidden');
          this._mostrarToast('⏱️ Grabación detenida: máximo 3 minutos (RN-31)', 'info');
        }
      }, 1000);
    } catch (err) {
      this._mostrarToast('❌ No se pudo acceder al micrófono', 'error');
      console.error('[EmpleoModule] Error accediendo al micrófono:', err);
    }
  }

  // ─── SIMULACIÓN WHISPER ──────────────────────────────────────────────────

  async simularWhisper(audioBlob) {
    // Simula la transcripción de audio a texto (como si usara OpenAI Whisper)
    await this._delay(2000);
    const idx = Math.floor(Math.random() * TRANSCRIPCIONES_DEMO.length);
    return TRANSCRIPCIONES_DEMO[idx];
  }

  // ─── SIMULACIÓN LLAMA3 ───────────────────────────────────────────────────

  async simularLlama3(texto) {
    // Simula el enriquecimiento del texto con un LLM (Llama 3)
    await this._delay(1500);

    // Detectar palabras clave para generar respuesta apropiada
    const textoLower = texto.toLowerCase();

    let titulo_sugerido = 'Empleado/a de comercio';
    let descripcion_profesional = texto;
    let sugerencias_capacitacion = [];

    if (textoLower.includes('mecánico') || textoLower.includes('taller')) {
      titulo_sugerido = 'Mecánico/a automotriz';
      descripcion_profesional =
        `Taller mecánico de Punta Alta incorpora mecánico/a para reparación y mantenimiento de vehículos. ` +
        `Se requiere experiencia en diagnóstico, reparación de motor y sistemas de frenado. ` +
        `Excelente clima laboral y posibilidades de crecimiento.`;
      sugerencias_capacitacion = [
        'Diagnóstico electrónico automotriz (SENA)',
        'Seguridad e Higiene en talleres',
        'Gestión de repuestos y stock',
      ];
    } else if (textoLower.includes('mostrador') || textoLower.includes('almacén')) {
      titulo_sugerido = 'Atención al cliente — Almacén';
      descripcion_profesional =
        `Almacén céntrico de Punta Alta busca persona para atención al público en mostrador. ` +
        `Turno mañana, de lunes a viernes. Buen trato, responsabilidad y ganas de trabajar. ` +
        `Remuneración mensual según convenio.`;
      sugerencias_capacitacion = [
        'Atención al cliente y ventas',
        'Manejo básico de caja registradora',
        'Gestión de stock — nivel inicial',
      ];
    } else {
      titulo_sugerido = 'Empleado/a de comercio';
      descripcion_profesional =
        `Comercio local de Punta Alta busca persona comprometida y con ganas de trabajar. ` +
        `Buen ambiente laboral, capacitación en el puesto. ` +
        `Requisitos: puntualidad, responsabilidad y predisposición.`;
      sugerencias_capacitacion = [
        'Gestión comercial básica',
        'Atención al cliente',
        'Introducción a las ventas',
      ];
    }

    return { titulo_sugerido, descripcion_profesional, sugerencias_capacitacion };
  }

  // ─── TRANSCRIBIR Y GENERAR AVISO ────────────────────────────────────────

  async _transcribirYGenerar() {
    if (!this.audioBlob) {
      this._mostrarToast('⚠️ Primero grabá el audio', 'error');
      return;
    }

    const btnTranscribir = document.getElementById('btn-transcribir');
    if (btnTranscribir) {
      btnTranscribir.disabled = true;
      btnTranscribir.textContent = '🔄 Transcribiendo audio...';
    }

    try {
      // Paso 1: Whisper
      const transcripcion = await this.simularWhisper(this.audioBlob);

      if (btnTranscribir) btnTranscribir.textContent = '🧠 Generando aviso con IA...';

      // Paso 2: Llama3
      const aviso = await this.simularLlama3(transcripcion);
      this.aviso = aviso;

      // Mostrar vista previa editable
      const vistaPrev = document.getElementById('vista-previa-ia');
      if (vistaPrev) {
        document.getElementById('preview-titulo').value = aviso.titulo_sugerido;
        document.getElementById('preview-descripcion').value = aviso.descripcion_profesional;
        document.getElementById('preview-sugerencias').innerHTML = `
          <h4>💡 Sugerencias de capacitación (informativas)</h4>
          <ul class="sugerencias-lista-ia">
            ${aviso.sugerencias_capacitacion.map((s) => `<li>${s}</li>`).join('')}
          </ul>
        `;
        vistaPrev.classList.remove('hidden');
      }

      this._mostrarToast('✨ Aviso generado. Revisá y confirmá.', 'success');
    } catch (err) {
      this._mostrarToast('❌ Error generando el aviso', 'error');
      console.error('[EmpleoModule] Error en transcripción/generación:', err);
    } finally {
      if (btnTranscribir) {
        btnTranscribir.disabled = false;
        btnTranscribir.textContent = '✨ Generar aviso con IA';
      }
    }
  }

  // ─── PUBLICAR EMPLEO ─────────────────────────────────────────────────────

  async _confirmarPublicar() {
    const titulo = document.getElementById('preview-titulo')?.value.trim();
    const descripcion = document.getElementById('preview-descripcion')?.value.trim();
    const turno = document.getElementById('preview-turno')?.value;
    const contrato = document.getElementById('preview-contrato')?.value;
    const salario = document.getElementById('preview-salario')?.value.trim();
    const sugerencias = this.aviso?.sugerencias_capacitacion || [];

    if (!titulo || !descripcion) {
      this._mostrarToast('⚠️ Completá título y descripción', 'error');
      return;
    }

    const vencimiento = new Date(Date.now() + 30 * 86400000); // RN-33: 30 días

    const nuevoEmpleo = {
      titulo,
      descripcion_texto: descripcion,
      comercio_id: this.comercianteNombre,
      turno,
      tipo_contrato: contrato,
      salario_referencia: salario || 'A convenir',
      requisitos: [],
      sugerencias_capacitacion: sugerencias,
      fecha_publicacion: Timestamp.now(),
      vencimiento: Timestamp.fromDate(vencimiento),
      activo: true,
      postulaciones_count: 0,
      estado: 'publicado',
      audio_url: null,
      ia_generado: true,
    };

    const btnPublicar = document.getElementById('btn-confirmar-publicar');
    if (btnPublicar) {
      btnPublicar.disabled = true;
      btnPublicar.textContent = '⏳ Publicando...';
    }

    try {
      const ref = await addDoc(collection(this.db, 'empleos'), nuevoEmpleo);

      // Agregar a lista local
      this.empleos.unshift({
        id: ref.id,
        titulo,
        comercio: this.comercianteNombre,
        comercio_emoji: '🏪',
        turno,
        contrato,
        salario: salario || 'A convenir',
        descripcion,
        requisitos: [],
        sugerencias_capacitacion: sugerencias,
        fecha_publicacion: new Date(),
        estado: 'publicado',
        postulaciones_count: 0,
        audio_url: null,
        ia_generado: true,
      });

      this._mostrarToast('🎉 ¡Empleo publicado exitosamente!', 'success');
      document.getElementById('vista-previa-ia')?.classList.add('hidden');
      document.getElementById('audio-preview')?.classList.add('hidden');
      this.audioBlob = null;

      // Actualizar mis empleos
      this._renderizarMisEmpleos();

      // Volver a modo vecino y mostrar lista actualizada
      this._aplicarFiltros();
      this._renderizarListaEmpleos();
    } catch (err) {
      this._mostrarToast('❌ Error al publicar. Intentá de nuevo.', 'error');
      console.error('[EmpleoModule] Error publicando empleo:', err);
    } finally {
      if (btnPublicar) {
        btnPublicar.disabled = false;
        btnPublicar.textContent = '✅ Confirmar y Publicar';
      }
    }
  }

  // ─── MIS EMPLEOS (COMERCIANTE) ───────────────────────────────────────────

  _renderizarMisEmpleos() {
    const contenedor = document.getElementById('lista-mis-empleos');
    if (!contenedor) return;

    const misEmpleos = this.empleos.filter(
      (e) => e.comercio === this.comercianteNombre && !e.id.startsWith('demo-')
    );

    if (misEmpleos.length === 0) {
      contenedor.innerHTML = '<p class="empty-state-small">No publicaste avisos aún.</p>';
      return;
    }

    contenedor.innerHTML = misEmpleos
      .map(
        (e) => `
        <div class="mi-empleo-card">
          <div class="mi-empleo-titulo">${e.titulo}${e.ia_generado ? ' <span class="ia-mini-badge">✨ IA</span>' : ''}</div>
          <div class="mi-empleo-meta">
            <span class="badge badge-green">${e.estado}</span>
            <span>👥 ${e.postulaciones_count} postulaciones</span>
          </div>
        </div>
      `
      )
      .join('');
  }

  // ─── EVENTOS ─────────────────────────────────────────────────────────────

  _bindEventos() {
    // Toggle modo comerciante
    document.getElementById('btn-toggle-comerciante')?.addEventListener('click', () => {
      this.modoComerciantActive = !this.modoComerciantActive;
      const secComercio = document.getElementById('seccion-comerciante');
      const secBusqueda = document.getElementById('seccion-busqueda');
      const btn = document.getElementById('btn-toggle-comerciante');

      if (this.modoComerciantActive) {
        secComercio?.classList.remove('hidden');
        secBusqueda?.classList.add('hidden');
        btn.textContent = '🔍 Buscar empleos';
        btn.classList.add('btn-activo');
      } else {
        secComercio?.classList.add('hidden');
        secBusqueda?.classList.remove('hidden');
        btn.textContent = 'Soy comerciante 🏪';
        btn.classList.remove('btn-activo');
      }
    });

    // Verificar CUIT
    document.getElementById('btn-verificar-cuit')?.addEventListener('click', () => this._verificarComerciante());

    // Formatear CUIT
    document.getElementById('input-cuit')?.addEventListener('input', (e) => {
      let val = e.target.value.replace(/\D/g, '');
      if (val.length > 2) val = val.slice(0, 2) + '-' + val.slice(2);
      if (val.length > 11) val = val.slice(0, 11) + '-' + val.slice(11);
      e.target.value = val.slice(0, 13);
      e.target.classList.remove('input-error');
    });

    // Grabación de audio
    document.getElementById('btn-grabar')?.addEventListener('click', () => this.grabarAudioEmpleo());

    // Transcribir y generar
    document.getElementById('btn-transcribir')?.addEventListener('click', () => this._transcribirYGenerar());

    // Confirmar publicar
    document.getElementById('btn-confirmar-publicar')?.addEventListener('click', () => this._confirmarPublicar());

    // Cerrar detalle
    document.getElementById('btn-cerrar-detalle')?.addEventListener('click', () => {
      document.getElementById('empleo-detalle')?.classList.add('hidden');
      this.empleoDetalleActivo = null;
    });

    // Búsqueda en tiempo real
    document.getElementById('empleo-search')?.addEventListener('input', (e) => {
      this.busquedaTexto = e.target.value;
      this._aplicarFiltros();
      this._renderizarListaEmpleos();
    });

    // Filtros de contrato
    document.querySelectorAll('.filtro-btn[data-contrato]').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.filtro-btn[data-contrato]').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        this.filtroContrato = btn.dataset.contrato;
        this._aplicarFiltros();
        this._renderizarListaEmpleos();
      });
    });

    // Filtros de turno
    document.querySelectorAll('.filtro-turno-btn[data-turno]').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.filtro-turno-btn[data-turno]').forEach((b) => b.classList.remove('active'));
        btn.classList.add('active');
        this.filtroTurno = btn.dataset.turno;
        this._aplicarFiltros();
        this._renderizarListaEmpleos();
      });
    });
  }

  // ─── UTILIDADES ──────────────────────────────────────────────────────────

  _delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  _mostrarToast(mensaje, tipo = 'info') {
    const colores = {
      success: '#057a55',
      error: '#c81e1e',
      info: '#1a56db',
    };
    const toast = document.createElement('div');
    toast.className = 'empleo-toast';
    toast.style.cssText = `
      position:fixed; bottom:80px; left:50%; transform:translateX(-50%);
      background:${colores[tipo]}; color:#fff; padding:12px 20px;
      border-radius:12px; font-size:14px; z-index:9999;
      box-shadow:0 4px 12px rgba(0,0,0,0.3); max-width:90vw; text-align:center;
      animation: fadeInUp 0.3s ease;
    `;
    toast.textContent = mensaje;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3500);
  }

  // ─── ESTILOS ─────────────────────────────────────────────────────────────

  _estilos() {
    return `
      @keyframes fadeInUp {
        from { opacity:0; transform:translateX(-50%) translateY(10px); }
        to   { opacity:1; transform:translateX(-50%) translateY(0); }
      }
      @keyframes pulse-dot {
        0%,100% { opacity:1; } 50% { opacity:0.3; }
      }

      .empleo-module { font-family: inherit; }

      /* HEADER */
      .empleo-header { padding: 16px; background: #fff; border-bottom: 1px solid #e5e7eb; }
      .empleo-header-top { display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:12px; }
      .empleo-title { font-size:20px; font-weight:700; color:#111; margin:0; }
      .empleo-subtitle { font-size:13px; color:#6b7280; margin:2px 0 0; }

      /* BOTÓN COMERCIANTE */
      .btn-comerciante {
        background:#f3f4f6; border:1.5px solid #d1d5db; border-radius:20px;
        padding:8px 14px; font-size:13px; font-weight:600; cursor:pointer;
        color:#374151; transition: all 0.2s;
        white-space: nowrap;
      }
      .btn-comerciante:hover, .btn-activo {
        background:#1a56db; color:#fff; border-color:#1a56db;
      }

      /* BUSCADOR */
      .search-box { position:relative; margin-bottom:12px; }
      .search-icon { position:absolute; left:12px; top:50%; transform:translateY(-50%); font-size:16px; }
      .search-input {
        width:100%; padding:10px 12px 10px 38px; border:1.5px solid #d1d5db;
        border-radius:10px; font-size:14px; outline:none; box-sizing:border-box;
        transition: border-color 0.2s;
      }
      .search-input:focus { border-color:#1a56db; }

      /* FILTROS */
      .filtros-row { display:flex; gap:6px; flex-wrap:wrap; margin-bottom:8px; }
      .filtro-label { font-size:12px; color:#6b7280; align-self:center; }
      .filtro-btn, .filtro-turno-btn {
        padding:6px 12px; border-radius:20px; border:1.5px solid #d1d5db;
        background:#fff; font-size:12px; cursor:pointer; color:#374151;
        transition: all 0.2s;
      }
      .filtro-btn.active, .filtro-turno-btn.active {
        background:#1a56db; color:#fff; border-color:#1a56db;
      }

      /* SECCIÓN COMERCIANTE */
      .seccion-comerciante { padding-top:12px; }
      .seccion-comerciante h3 { font-size:15px; font-weight:700; margin:0 0 6px; }
      .verificacion-info { font-size:12px; color:#6b7280; margin:0 0 12px; }
      .form-group { margin-bottom:12px; }
      .form-group label { display:block; font-size:13px; font-weight:600; color:#374151; margin-bottom:4px; }
      .form-input, .form-textarea {
        width:100%; padding:9px 12px; border:1.5px solid #d1d5db;
        border-radius:8px; font-size:14px; outline:none; box-sizing:border-box;
        transition: border-color 0.2s;
      }
      .form-textarea { resize:vertical; }
      .form-input:focus, .form-textarea:focus { border-color:#1a56db; }
      .form-hint { font-size:11px; color:#9ca3af; }
      .input-error { border-color:#ef4444 !important; }

      /* VERIFICADO */
      .comerciante-badge {
        background:#ecfdf5; border:1px solid #6ee7b7; border-radius:8px;
        padding:10px 14px; font-size:13px; margin-bottom:16px;
      }

      /* AUDIO */
      .audio-section { margin-bottom:16px; }
      .audio-info { font-size:12px; color:#6b7280; margin:4px 0 10px; }
      .audio-controls { display:flex; align-items:center; gap:12px; flex-wrap:wrap; }
      .btn-grabar {
        background:#ef4444; color:#fff; border:none; border-radius:20px;
        padding:10px 18px; font-size:13px; font-weight:600; cursor:pointer;
      }
      .timer-display {
        display:flex; align-items:center; gap:6px; font-size:13px; color:#374151;
      }
      .timer-dot {
        width:10px; height:10px; border-radius:50%; background:#ef4444;
        animation: pulse-dot 1s infinite;
      }
      .audio-preview-label { font-size:13px; color:#374151; margin:10px 0 4px; }
      .audio-player { width:100%; margin-bottom:8px; }

      /* IA BADGE */
      .ia-badge {
        background:#fef3c7; border:1px solid #fbbf24; border-radius:8px;
        padding:8px 12px; font-size:12px; color:#92400e; margin-bottom:12px;
      }
      .ia-badge-detalle {
        background:#fef3c7; border:1px solid #fbbf24; border-radius:6px;
        padding:3px 8px; font-size:11px; color:#92400e;
      }
      .ia-mini-badge {
        background:#fef3c7; border-radius:4px;
        padding:1px 5px; font-size:10px; color:#92400e;
      }
      .ia-sugerencias h4 { font-size:13px; margin:12px 0 6px; }
      .sugerencias-lista-ia { padding-left:20px; font-size:13px; color:#374151; }
      .sugerencias-lista-ia li { margin-bottom:3px; }

      /* BOTONES */
      .btn-primary {
        background:#1a56db; color:#fff; border:none; border-radius:10px;
        padding:12px 20px; font-size:14px; font-weight:600; cursor:pointer;
        width:100%; transition: background 0.2s;
      }
      .btn-primary:hover { background:#1e429f; }
      .btn-primary:disabled { background:#9ca3af; cursor:not-allowed; }
      .btn-secondary {
        background:#f3f4f6; color:#374151; border:1.5px solid #d1d5db;
        border-radius:10px; padding:10px 16px; font-size:13px;
        font-weight:600; cursor:pointer; transition: all 0.2s;
      }
      .btn-publicar { margin-top:16px; }

      /* MIS EMPLEOS */
      .mis-empleos-section { margin-top:20px; padding-top:16px; border-top:1px solid #e5e7eb; }
      .mis-empleos-section h3 { font-size:14px; font-weight:700; margin:0 0 10px; }
      .mi-empleo-card {
        background:#f9fafb; border:1px solid #e5e7eb; border-radius:8px;
        padding:10px 12px; margin-bottom:8px;
      }
      .mi-empleo-titulo { font-size:13px; font-weight:600; margin-bottom:6px; }
      .mi-empleo-meta { display:flex; gap:10px; align-items:center; font-size:12px; color:#6b7280; }

      /* BODY */
      .empleo-body { display:flex; position:relative; }
      .empleo-lista-wrapper { flex:1; overflow-y:auto; }

      /* CARDS */
      .empleo-lista { padding:12px; display:flex; flex-direction:column; gap:10px; }
      .empleo-card {
        background:#fff; border:1.5px solid #e5e7eb; border-radius:12px;
        padding:14px; cursor:pointer; transition: all 0.2s;
        box-shadow: 0 1px 3px rgba(0,0,0,0.05);
      }
      .empleo-card:hover { border-color:#1a56db; box-shadow:0 4px 12px rgba(26,86,219,0.1); transform:translateY(-1px); }
      .card-header-row { display:flex; justify-content:space-between; align-items:flex-start; gap:8px; margin-bottom:8px; }
      .card-titulo { font-size:15px; font-weight:700; color:#111; margin:0 0 3px; }
      .card-comercio { font-size:13px; color:#6b7280; margin:0; }
      .card-meta { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:10px; }
      .turno-tag, .salario-tag {
        font-size:12px; background:#f3f4f6; padding:4px 8px;
        border-radius:6px; color:#374151;
      }
      .card-footer-row { display:flex; justify-content:space-between; align-items:center; }
      .fecha-tag { font-size:11px; color:#9ca3af; }

      /* BOTÓN POSTULAR */
      .btn-postular {
        background:#1a56db; color:#fff; border:none; border-radius:8px;
        padding:7px 14px; font-size:12px; font-weight:600; cursor:pointer;
        transition: background 0.2s;
      }
      .btn-postular:hover { background:#1e429f; }

      /* BADGES */
      .badge {
        font-size:11px; padding:3px 8px; border-radius:12px;
        font-weight:600; white-space:nowrap;
      }
      .badge-blue { background:#dbeafe; color:#1e40af; }
      .badge-green { background:#d1fae5; color:#065f46; }
      .badge-orange { background:#fef3c7; color:#92400e; }
      .badge-gray { background:#f3f4f6; color:#374151; }

      /* DETALLE */
      .empleo-detalle {
        position:fixed; top:0; right:0; bottom:0; width:min(380px,100vw);
        background:#fff; box-shadow:-4px 0 20px rgba(0,0,0,0.15);
        overflow-y:auto; padding:16px; z-index:500;
        transition: transform 0.3s;
      }
      .btn-cerrar-detalle {
        background:#f3f4f6; border:1px solid #d1d5db; border-radius:8px;
        padding:6px 12px; font-size:12px; cursor:pointer; margin-bottom:12px;
      }
      .detalle-header { margin-bottom:8px; }
      .detalle-header h2 { font-size:18px; font-weight:700; margin:0 0 4px; }
      .detalle-comercio { font-size:14px; color:#6b7280; margin:0 0 14px; }
      .detalle-meta-grid {
        display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:14px;
      }
      .detalle-meta-item {
        background:#f9fafb; border-radius:8px; padding:8px 10px;
      }
      .meta-label { display:block; font-size:11px; color:#9ca3af; margin-bottom:2px; }
      .meta-value { font-size:13px; font-weight:600; color:#111; }
      .detalle-descripcion, .detalle-requisitos { margin-bottom:14px; }
      .detalle-descripcion h4, .detalle-requisitos h4 {
        font-size:13px; font-weight:700; color:#374151; margin:0 0 6px;
      }
      .detalle-descripcion p { font-size:14px; color:#374151; line-height:1.5; }
      .detalle-lista { padding-left:16px; font-size:13px; color:#374151; }
      .detalle-lista li { margin-bottom:4px; }
      .detalle-sugerencias { background:#fffbeb; border:1px solid #fde68a; border-radius:8px; padding:12px; margin-bottom:14px; }
      .detalle-sugerencias h4 { font-size:12px; font-weight:700; color:#92400e; margin:0 0 6px; }
      .sugerencias-lista { color:#78350f !important; }
      .detalle-audio { margin-bottom:14px; }
      .detalle-audio h4 { font-size:13px; margin:0 0 6px; }
      .btn-postular-detalle {
        background:#1a56db; color:#fff; border:none; border-radius:10px;
        padding:14px; font-size:15px; font-weight:700; cursor:pointer;
        width:100%; margin-top:8px;
      }

      /* EMPTY STATE */
      .empty-state {
        text-align:center; padding:40px 20px; color:#6b7280;
      }
      .empty-icon { font-size:48px; margin-bottom:12px; }
      .empty-state p { font-size:15px; margin:0 0 6px; }
      .empty-sub { font-size:13px !important; color:#9ca3af; }
      .empty-state-small { font-size:12px; color:#9ca3af; text-align:center; }

      /* HIDDEN */
      .hidden { display:none !important; }
    `;
  }
}
