/**
 * reportar.js — Módulo del Flujo de Reporte · CiudadConecta Punta Alta
 * ---------------------------------------------------------------------
 * Flujo de 10 pasos:
 *   1. Permiso de cámara (solo trasera, no galería)
 *   2. Preview de video en vivo
 *   3. Captura de frame a canvas
 *   4. Selección de tipo de incidente
 *   5. Análisis IA simulado
 *   6. Resultado IA + barra de confianza
 *   7. Obtención de GPS real
 *   8. Verificación de duplicados en Firestore
 *   9. Agrupamiento si duplicado / guardado si nuevo
 *  10. Feedback final (confetti, cupón)
 *
 * Reglas de negocio: RN-01 a RN-06
 */

import {
  db,
  auth,
  collection,
  addDoc,
  getDocs,
  query,
  where,
  doc,
  updateDoc,
  serverTimestamp,
} from '../firebase-init.js';

import { clasificarImagen, verificarAutenticidad, detectarDuplicado } from './ai-engine.js';

// ── Constantes ────────────────────────────────────────────────────────────────

const RADIO_DUPLICADO_M = 50;
const UNA_SEMANA_MS = 7 * 24 * 60 * 60 * 1000;

/** Tipos de incidente disponibles */
const TIPOS = {
  bache:    { emoji: '🕳️', label: 'Bache',    color: '#e53e3e' },
  desague:  { emoji: '🌊', label: 'Desagüe',  color: '#d69e2e' },
};

// ── Clase ReportarModule ──────────────────────────────────────────────────────

export class ReportarModule {
  constructor() {
    /** Paso actual del wizard (1-10) */
    this._paso = 0;

    /** Stream de video de la cámara */
    this._stream = null;

    /** Referencia al elemento <video> */
    this._videoEl = null;

    /** DataURL de la foto capturada */
    this._fotoDataURL = null;

    /** Tipo seleccionado ('bache' | 'desague') */
    this._tipoSeleccionado = null;

    /** Resultado del análisis IA */
    this._resultadoIA = null;

    /** Coordenadas GPS obtenidas */
    this._gps = null;

    /** Timestamp de la captura */
    this._timestamp = null;

    /** Contenedor principal del wizard */
    this._container = null;

    /** Reportes existentes cacheados para verificar duplicados */
    this._reportesExistentes = [];
  }

  // ── init ──────────────────────────────────────────────────────────────────

  /**
   * Inicializa el módulo, renderiza el wizard en el contenedor.
   * @param {string} [containerId='reportar-container']
   */
  async init(containerId = 'reportar-container') {
    this._container = document.getElementById(containerId);
    if (!this._container) {
      throw new Error(`[ReportarModule] Contenedor #${containerId} no encontrado.`);
    }

    // Verificar límite semanal antes de iniciar
    const userId = this._getUserId();
    const dentroLimite = await this._verificarLimiteSemanal(userId);
    if (!dentroLimite) {
      this._mostrarLimiteSemanal();
      return;
    }

    // Pre-cargar reportes activos para verificación de duplicados
    await this._precargarReportes();

    // Comenzar el wizard desde el paso 1
    await this._irPaso(1);
  }

  // ── getUserId ─────────────────────────────────────────────────────────────

  /**
   * Obtiene el ID anónimo del usuario desde Firebase Auth.
   * @returns {string}
   */
  _getUserId() {
    return auth.currentUser?.uid || localStorage.getItem('cc_anon_uid') || 'desconocido';
  }

  /**
   * Genera un hash simple del userId para anonimizar en Firestore.
   * @param {string} uid
   * @returns {Promise<string>}
   */
  async _hashUserId(uid) {
    const encoder = new TextEncoder();
    const data = encoder.encode(uid + 'ciudadconecta-salt-2025');
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 20);
  }

  // ── verificarLimiteSemanal ────────────────────────────────────────────────

  /**
   * RN-01: Verifica si el usuario ya reportó en los últimos 7 días.
   * @param {string} userId
   * @returns {Promise<boolean>} true si puede reportar
   */
  async _verificarLimiteSemanal(userId) {
    try {
      const userIdHash = await this._hashUserId(userId);
      const haceUnaSemana = new Date(Date.now() - UNA_SEMANA_MS);

      const q = query(
        collection(db, 'reportes'),
        where('userId', '==', userIdHash),
        where('activo', '==', true)
      );

      const snapshot = await getDocs(q);
      const reportesRecientes = snapshot.docs.filter(d => {
        const ts = d.data().timestamp?.toMillis?.() || 0;
        return ts >= haceUnaSemana.getTime();
      });

      return reportesRecientes.length === 0;
    } catch (err) {
      console.warn('[ReportarModule] No se pudo verificar límite semanal:', err);
      // En caso de error, permitir el reporte
      return true;
    }
  }

  // ── precargarReportes ─────────────────────────────────────────────────────

  /**
   * Pre-carga reportes activos de Firestore para verificar duplicados offline.
   */
  async _precargarReportes() {
    try {
      const q = query(collection(db, 'reportes'), where('activo', '==', true));
      const snapshot = await getDocs(q);
      this._reportesExistentes = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
    } catch (err) {
      console.warn('[ReportarModule] No se pudo precargar reportes:', err);
      // Fallback: usar lo que haya en localStorage
      try {
        const cached = localStorage.getItem('cc_reportes_cache');
        if (cached) this._reportesExistentes = JSON.parse(cached);
      } catch { /* ignorar */ }
    }
  }

  // ── _irPaso ───────────────────────────────────────────────────────────────

  /**
   * Navega al paso indicado del wizard.
   * @param {number} paso
   */
  async _irPaso(paso) {
    this._paso = paso;
    this._container.innerHTML = '';

    const pasos = {
      1:  () => this._renderPaso1_Camara(),
      2:  () => this._renderPaso2_Preview(),
      3:  () => this._renderPaso3_Captura(),
      4:  () => this._renderPaso4_TipoIncidente(),
      5:  () => this._renderPaso5_AnalisisIA(),
      6:  () => this._renderPaso6_ResultadoIA(),
      7:  () => this._renderPaso7_GPS(),
      8:  () => this._renderPaso8_Duplicados(),
      9:  () => this._renderPaso9_Guardado(),
      10: () => this._renderPaso10_Feedback(),
    };

    if (pasos[paso]) {
      await pasos[paso]();
    }
  }

  // ── Paso 1: Cámara ────────────────────────────────────────────────────────

  async _renderPaso1_Camara() {
    this._renderShell('📷 Cámara', 1, `
      <p style="color:#4a5568; margin-bottom:16px; text-align:center;">
        Para reportar un incidente necesitamos acceder a tu cámara trasera.
        <br><small style="color:#a0aec0;">RN-02: Solo se permite foto desde cámara en vivo</small>
      </p>
      <div id="camara-error" style="display:none; color:#e53e3e; background:#fff5f5; padding:12px; border-radius:8px; margin-bottom:12px;"></div>
      <button id="btn-activar-camara" class="cc-btn cc-btn-primary" style="width:100%">
        📷 Activar cámara trasera
      </button>
    `);

    document.getElementById('btn-activar-camara').addEventListener('click', async () => {
      await this._solicitarCamara();
    });
  }

  /**
   * Solicita permiso de cámara trasera (RN-02: solo environment, no galería).
   */
  async _solicitarCamara() {
    const errorEl = document.getElementById('camara-error');

    // Ocultar input file (no galería — RN-02)
    // No usamos <input type="file"> intencionalmente

    try {
      this._stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' }, // Cámara trasera
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });

      await this._irPaso(2);
    } catch (err) {
      const msgs = {
        NotAllowedError: 'Permiso denegado. Habilitá la cámara en la configuración del navegador.',
        NotFoundError: 'No se encontró cámara en este dispositivo.',
        NotReadableError: 'La cámara está siendo usada por otra aplicación.',
        OverconstrainedError: 'La cámara no cumple los requisitos mínimos.',
      };

      const msg = msgs[err.name] || `Error de cámara: ${err.message}`;

      if (errorEl) {
        errorEl.style.display = 'block';
        errorEl.textContent = `⚠️ ${msg}`;
      }

      // Guardar en localStorage para sync posterior (RN offline)
      this._registrarErrorOffline('camara', msg);
    }
  }

  // ── Paso 2: Preview de video ───────────────────────────────────────────────

  async _renderPaso2_Preview() {
    this._renderShell('🎥 Preview en vivo', 2, `
      <div style="position:relative; background:#000; border-radius:12px; overflow:hidden; margin-bottom:16px;">
        <video id="cc-video-preview"
          autoplay playsinline muted
          style="width:100%; max-height:320px; object-fit:cover; display:block;"
        ></video>
        <div style="
          position:absolute; bottom:8px; left:50%; transform:translateX(-50%);
          background:rgba(0,0,0,0.6); color:white; padding:4px 10px;
          border-radius:12px; font-size:12px;
        ">📡 Cámara en vivo</div>
      </div>
      <p style="color:#718096; font-size:13px; text-align:center; margin-bottom:16px;">
        Apuntá al incidente y presioná el botón para capturar la foto.
      </p>
      <button id="btn-capturar" class="cc-btn cc-btn-primary" style="width:100%">
        📸 Capturar foto
      </button>
      <button id="btn-volver-cam" class="cc-btn cc-btn-secondary" style="width:100%; margin-top:8px;">
        ← Volver
      </button>
    `);

    const video = document.getElementById('cc-video-preview');
    this._videoEl = video;

    if (this._stream) {
      video.srcObject = this._stream;
      await video.play().catch(e => console.warn('Autoplay bloqueado:', e));
    }

    document.getElementById('btn-capturar').addEventListener('click', () => {
      this._capturarFrame();
    });

    document.getElementById('btn-volver-cam').addEventListener('click', async () => {
      this._detenerStream();
      await this._irPaso(1);
    });
  }

  // ── Paso 3: Captura ───────────────────────────────────────────────────────

  _capturarFrame() {
    const video = this._videoEl;
    if (!video) return;

    const canvas = document.createElement('canvas');
    canvas.width  = video.videoWidth  || 640;
    canvas.height = video.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    this._fotoDataURL = canvas.toDataURL('image/jpeg', 0.85);
    this._timestamp = new Date(); // RN-03: timestamp de hardware

    // Detener cámara después de capturar
    this._detenerStream();

    this._irPaso(3);
  }

  async _renderPaso3_Captura() {
    this._renderShell('✅ Foto capturada', 3, `
      <div style="text-align:center; margin-bottom:16px;">
        <img
          src="${this._fotoDataURL}"
          alt="Foto capturada"
          style="max-width:100%; max-height:260px; border-radius:12px; border:2px solid #e2e8f0;"
        />
        <p style="color:#68d391; font-size:13px; margin-top:8px;">✅ Foto capturada correctamente</p>
      </div>
      <div style="display:flex; gap:8px;">
        <button id="btn-repetir" class="cc-btn cc-btn-secondary" style="flex:1">
          🔁 Repetir
        </button>
        <button id="btn-continuar-tipo" class="cc-btn cc-btn-primary" style="flex:2">
          Continuar →
        </button>
      </div>
    `);

    document.getElementById('btn-repetir').addEventListener('click', async () => {
      this._fotoDataURL = null;
      this._timestamp = null;
      await this._solicitarCamara();
    });

    document.getElementById('btn-continuar-tipo').addEventListener('click', async () => {
      await this._irPaso(4);
    });
  }

  // ── Paso 4: Tipo de incidente ─────────────────────────────────────────────

  async _renderPaso4_TipoIncidente() {
    const botonesHTML = Object.entries(TIPOS).map(([key, t]) => `
      <button
        class="cc-btn-tipo"
        data-tipo="${key}"
        style="
          flex:1; padding:20px 12px; border:2px solid #e2e8f0;
          border-radius:12px; background:white; cursor:pointer;
          text-align:center; font-size:15px; transition:all 0.2s;
        "
      >
        <div style="font-size:36px; margin-bottom:8px;">${t.emoji}</div>
        <div style="font-weight:600; color:#2d3748;">${t.label}</div>
      </button>
    `).join('');

    this._renderShell('🔍 ¿Qué tipo de incidente?', 4, `
      <p style="color:#718096; text-align:center; margin-bottom:20px; font-size:14px;">
        Seleccioná el tipo de incidente que corresponde:
      </p>
      <div style="display:flex; gap:12px; margin-bottom:20px;">
        ${botonesHTML}
      </div>
      <button id="btn-volver-captura" class="cc-btn cc-btn-secondary" style="width:100%">
        ← Volver
      </button>
    `);

    document.querySelectorAll('.cc-btn-tipo').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const tipo = e.currentTarget.dataset.tipo;
        this._tipoSeleccionado = tipo;

        // Highlight selección
        document.querySelectorAll('.cc-btn-tipo').forEach(b => {
          b.style.borderColor = '#e2e8f0';
          b.style.background  = 'white';
        });
        e.currentTarget.style.borderColor = TIPOS[tipo].color;
        e.currentTarget.style.background  = '#f7fafc';

        // Pequeño delay para mostrar selección
        await new Promise(r => setTimeout(r, 300));
        await this._irPaso(5);
      });

      // Hover effect
      btn.addEventListener('mouseenter', () => { btn.style.borderColor = '#cbd5e0'; });
      btn.addEventListener('mouseleave', () => {
        if (btn.dataset.tipo !== this._tipoSeleccionado) btn.style.borderColor = '#e2e8f0';
      });
    });

    document.getElementById('btn-volver-captura').addEventListener('click', () => this._irPaso(3));
  }

  // ── Paso 5: Análisis IA ───────────────────────────────────────────────────

  async _renderPaso5_AnalisisIA() {
    this._renderShell('🤖 Analizando imagen...', 5, `
      <div style="text-align:center; padding:40px 20px;">
        <div class="cc-spinner" style="
          width:60px; height:60px; border:4px solid #e2e8f0;
          border-top-color:#4299e1; border-radius:50%;
          animation:spin 0.8s linear infinite; margin:0 auto 20px;
        "></div>
        <p style="color:#4a5568; font-size:16px; margin-bottom:8px;">
          🧠 Procesando con IA…
        </p>
        <p style="color:#a0aec0; font-size:13px;">
          Analizando imagen para detectar: <strong>${TIPOS[this._tipoSeleccionado]?.label || ''}</strong>
        </p>
        <div id="ia-progress-bar" style="
          height:4px; background:#e2e8f0; border-radius:4px;
          margin-top:24px; overflow:hidden;
        ">
          <div id="ia-progress-fill" style="
            height:100%; width:0%; background:linear-gradient(90deg,#4299e1,#63b3ed);
            transition:width 1.8s ease-in-out;
          "></div>
        </div>
      </div>
      <style>@keyframes spin { to { transform:rotate(360deg); } }</style>
    `);

    // Animar barra de progreso
    requestAnimationFrame(() => {
      const fill = document.getElementById('ia-progress-fill');
      if (fill) fill.style.width = '90%';
    });

    try {
      // Llamar al motor de IA simulado
      this._resultadoIA = await clasificarImagen(this._fotoDataURL, this._tipoSeleccionado);
      await this._irPaso(6);
    } catch (err) {
      console.error('[ReportarModule] Error en análisis IA:', err);
      // En caso de error, usar resultado por defecto
      this._resultadoIA = {
        tipo: this._tipoSeleccionado,
        confianza: 75,
        descripcion: 'Incidente detectado manualmente.',
        severidad: 'moderado',
      };
      await this._irPaso(6);
    }
  }

  // ── Paso 6: Resultado IA ──────────────────────────────────────────────────

  async _renderPaso6_ResultadoIA() {
    const { tipo, confianza, descripcion, severidad } = this._resultadoIA;
    const tipoInfo = TIPOS[tipo] || TIPOS.bache;
    const baja = confianza < 50;

    const confianzaColor = confianza >= 80 ? '#38a169' : confianza >= 60 ? '#d69e2e' : '#e53e3e';

    this._renderShell('🧠 Resultado del análisis', 6, `
      <div style="
        background:#f7fafc; border-radius:12px; padding:16px; margin-bottom:16px;
        border-left:4px solid ${confianzaColor};
      ">
        <div style="font-size:24px; margin-bottom:6px;">${tipoInfo.emoji} ${tipoInfo.label}</div>
        <p style="color:#4a5568; font-size:14px; margin-bottom:12px;">${descripcion}</p>
        <div style="margin-bottom:8px;">
          <div style="display:flex; justify-content:space-between; margin-bottom:4px;">
            <span style="font-size:13px; color:#718096;">Confianza IA</span>
            <span style="font-size:13px; font-weight:700; color:${confianzaColor}">${confianza}%</span>
          </div>
          <div style="height:8px; background:#e2e8f0; border-radius:4px; overflow:hidden;">
            <div id="conf-bar" style="
              height:100%; width:0%; background:${confianzaColor};
              border-radius:4px; transition:width 1s ease;
            "></div>
          </div>
        </div>
        <div style="font-size:12px; color:#718096;">
          Severidad: <strong>${severidad.charAt(0).toUpperCase() + severidad.slice(1)}</strong>
        </div>
      </div>

      ${baja ? `
        <div style="
          background:#fff5f5; border:1px solid #fc8181; border-radius:8px;
          padding:12px; margin-bottom:16px; color:#c53030; font-size:13px;
        ">
          ⚠️ <strong>Verificación manual requerida</strong><br>
          La confianza es menor al 50%. Un operador revisará este reporte antes de publicarlo.
        </div>
      ` : ''}

      <button id="btn-continuar-gps" class="cc-btn cc-btn-primary" style="width:100%">
        ${baja ? '📋 Enviar para revisión manual' : 'Continuar → Obtener GPS'}
      </button>
      <button id="btn-volver-tipo" class="cc-btn cc-btn-secondary" style="width:100%; margin-top:8px;">
        ← Cambiar tipo
      </button>
    `);

    // Animar barra de confianza
    requestAnimationFrame(() => {
      const bar = document.getElementById('conf-bar');
      if (bar) bar.style.width = confianza + '%';
    });

    document.getElementById('btn-continuar-gps').addEventListener('click', () => this._irPaso(7));
    document.getElementById('btn-volver-tipo').addEventListener('click', () => this._irPaso(4));
  }

  // ── Paso 7: GPS ───────────────────────────────────────────────────────────

  async _renderPaso7_GPS() {
    this._renderShell('📍 Obteniendo ubicación', 7, `
      <div style="text-align:center; padding:30px 20px;">
        <div style="font-size:48px; margin-bottom:12px;">📍</div>
        <p style="color:#4a5568; margin-bottom:8px;">Obteniendo tu ubicación GPS…</p>
        <p style="color:#a0aec0; font-size:13px;">RN-03: GPS capturado por hardware del dispositivo</p>
        <div id="gps-status" style="margin-top:20px; color:#718096; font-size:14px;"></div>
      </div>
    `);

    const statusEl = document.getElementById('gps-status');

    if (!navigator.geolocation) {
      this._gps = null;
      statusEl.textContent = '⚠️ GPS no disponible en este dispositivo.';
      this._registrarErrorOffline('gps', 'GPS no disponible');
      setTimeout(() => this._irPaso(8), 1500);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        this._gps = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        };

        // RN-03: Verificar autenticidad
        const auth = verificarAutenticidad(this._fotoDataURL, this._gps, this._timestamp);

        if (!auth.autentico) {
          statusEl.innerHTML = `<span style="color:#e53e3e;">⚠️ ${auth.razon}</span>`;
          // Continuar de todos modos si el GPS es válido pero el área no coincide
          // (podría ser imprecisión del GPS)
        } else {
          statusEl.innerHTML = `<span style="color:#38a169;">✅ Ubicación obtenida (±${Math.round(pos.coords.accuracy)}m)</span>`;
        }

        setTimeout(() => this._irPaso(8), 1200);
      },
      (err) => {
        console.warn('[ReportarModule] Error GPS:', err.message);
        this._gps = null;
        statusEl.innerHTML = `<span style="color:#e53e3e;">⚠️ No se pudo obtener GPS: ${err.message}</span>`;
        this._registrarErrorOffline('gps', err.message);

        // Mostrar opción de continuar sin GPS
        statusEl.insertAdjacentHTML('beforeend', `
          <br><br>
          <button id="btn-sin-gps" class="cc-btn cc-btn-secondary">Continuar sin GPS</button>
        `);

        document.getElementById('btn-sin-gps')?.addEventListener('click', () => this._irPaso(8));
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  }

  // ── Paso 8: Verificar duplicados ──────────────────────────────────────────

  async _renderPaso8_Duplicados() {
    this._renderShell('🔍 Verificando duplicados', 8, `
      <div style="text-align:center; padding:30px;">
        <div class="cc-spinner" style="
          width:40px; height:40px; border:3px solid #e2e8f0;
          border-top-color:#4299e1; border-radius:50%;
          animation:spin 0.8s linear infinite; margin:0 auto 16px;
        "></div>
        <p style="color:#718096;">Buscando reportes cercanos…</p>
      </div>
      <style>@keyframes spin { to { transform:rotate(360deg); } }</style>
    `);

    await this._verificarDuplicadoYContinuar();
  }

  /**
   * Verifica si hay un reporte duplicado a menos de 50m y toma acción.
   */
  async _verificarDuplicadoYContinuar() {
    if (!this._gps) {
      // Sin GPS no podemos verificar — ir directo a guardar
      await this._irPaso(9);
      return;
    }

    try {
      const { duplicado, distancia } = detectarDuplicado(
        this._gps.lat,
        this._gps.lng,
        this._reportesExistentes,
        this._tipoSeleccionado
      );

      if (duplicado) {
        // RN-04: Agrupar con reporte existente
        await this._agruparConExistente(duplicado, distancia);
      } else {
        await this._irPaso(9);
      }
    } catch (err) {
      console.error('[ReportarModule] Error verificando duplicados:', err);
      await this._irPaso(9);
    }
  }

  /**
   * Agrupa el reporte actual con uno existente (RN-04).
   * @param {Object} reporteExistente
   * @param {number} distancia
   */
  async _agruparConExistente(reporteExistente, distancia) {
    // Actualizar el reporte existente en Firestore
    try {
      const refDoc = doc(db, 'reportes', reporteExistente.id);
      const agrupados = Array.isArray(reporteExistente.agrupado_con)
        ? reporteExistente.agrupado_con
        : [];

      const userIdHash = await this._hashUserId(this._getUserId());
      agrupados.push(userIdHash);

      await updateDoc(refDoc, {
        agrupado_con: agrupados,
      });
    } catch (err) {
      console.warn('[ReportarModule] No se pudo actualizar reporte agrupado:', err);
    }

    // Mostrar toast de agrupamiento
    this._container.innerHTML = '';
    this._renderShell('👥 Reporte ya registrado', 8, `
      <div style="text-align:center; padding:20px;">
        <div style="font-size:56px; margin-bottom:16px;">📌</div>
        <h3 style="color:#2d3748; margin-bottom:8px;">¡Ya existe un reporte cercano!</h3>
        <p style="color:#718096; font-size:14px; margin-bottom:16px;">
          Hay un reporte a <strong>${distancia} metros</strong> de tu ubicación.<br>
          Tu apoyo fue sumado al reporte existente. ¡Gracias!
        </p>
        <div style="
          background:#ebf8ff; border-radius:12px; padding:16px; margin-bottom:20px;
          color:#2c5282; font-size:14px;
        ">
          👥 <strong>+1 vecino apoyó este reporte</strong><br>
          <small>Cuantos más lo reporten, mayor prioridad tendrá.</small>
        </div>
        <button id="btn-ver-mapa" class="cc-btn cc-btn-primary" style="width:100%">
          🗺️ Ver en el mapa
        </button>
      </div>
    `);

    // Otorgar puntos menores (RN-21)
    this._sumarPuntosReputacion('agrupado');

    document.getElementById('btn-ver-mapa')?.addEventListener('click', () => {
      window.dispatchEvent(new CustomEvent('nav:tab', { detail: { tab: 'mapa' } }));
    });
  }

  // ── Paso 9: Guardar en Firestore ──────────────────────────────────────────

  async _renderPaso9_Guardado() {
    this._renderShell('💾 Guardando reporte', 9, `
      <div style="text-align:center; padding:30px;">
        <div class="cc-spinner" style="
          width:50px; height:50px; border:4px solid #e2e8f0;
          border-top-color:#38a169; border-radius:50%;
          animation:spin 0.8s linear infinite; margin:0 auto 16px;
        "></div>
        <p style="color:#4a5568;">Guardando tu reporte…</p>
      </div>
      <style>@keyframes spin { to { transform:rotate(360deg); } }</style>
    `);

    await this._guardarReporte();
  }

  /**
   * Guarda el reporte en Firestore.
   */
  async _guardarReporte() {
    const userIdHash = await this._hashUserId(this._getUserId());

    const reporte = {
      userId:      userIdHash,           // RN-05: anónimo (hash)
      tipo:        this._tipoSeleccionado,
      lat:         this._gps?.lat   ?? null,
      lng:         this._gps?.lng   ?? null,
      timestamp:   serverTimestamp(),
      estado:      this._resultadoIA.confianza < 50 ? 'recibido' : 'recibido',
      foto_url:    null,                 // En producción: subir a Storage
      confianza_ia: this._resultadoIA.confianza,
      descripcion: this._resultadoIA.descripcion,
      agrupado_con: [],
      activo:      true,
      severidad:   this._resultadoIA.severidad,
      // RN-06: marcar para revisión manual si confianza < 50
      requiere_verificacion: this._resultadoIA.confianza < 50,
    };

    try {
      await addDoc(collection(db, 'reportes'), reporte);
      await this._irPaso(10);
    } catch (err) {
      console.error('[ReportarModule] Error guardando en Firestore:', err);

      // Guardar offline para sync posterior
      this._guardarOffline(reporte);

      // Mostrar mensaje de éxito offline
      await this._irPaso(10);
    }
  }

  // ── Paso 10: Feedback final ───────────────────────────────────────────────

  async _renderPaso10_Feedback() {
    const tipo = TIPOS[this._tipoSeleccionado] || TIPOS.bache;

    this._renderShell('🎉 ¡Reporte enviado!', 10, `
      <div style="text-align:center; padding:20px 10px;">
        <div id="confetti-container" style="position:relative; height:80px; overflow:hidden; margin-bottom:8px;">
          ${this._generarConfettiHTML()}
        </div>

        <div style="font-size:56px; margin-bottom:12px;">✅</div>
        <h3 style="color:#276749; margin-bottom:8px;">¡Gracias por contribuir!</h3>
        <p style="color:#4a5568; font-size:14px; margin-bottom:20px;">
          Tu reporte de <strong>${tipo.emoji} ${tipo.label}</strong> fue enviado correctamente.<br>
          El municipio recibirá una notificación.
        </p>

        <div style="
          background:linear-gradient(135deg,#f0fff4,#c6f6d5);
          border-radius:12px; padding:16px; margin-bottom:20px;
        ">
          <div style="font-size:20px; margin-bottom:4px;">🏆 +10 puntos de reputación</div>
          <div style="color:#276749; font-size:13px;">¡Seguís construyendo una mejor ciudad!</div>
        </div>

        <div style="
          background:#ebf8ff; border-radius:12px; padding:12px; margin-bottom:20px;
          color:#2c5282; font-size:13px; text-align:left;
        ">
          📋 <strong>¿Qué pasa ahora?</strong><br>
          1. Tu reporte ingresa al sistema municipal<br>
          2. Se agenda según prioridad<br>
          3. Te notificaremos el avance en <em>Mis Reportes</em>
        </div>

        <div style="display:flex; gap:8px;">
          <button id="btn-ver-mapa-final" class="cc-btn cc-btn-secondary" style="flex:1">
            🗺️ Ver mapa
          </button>
          <button id="btn-nuevo-reporte" class="cc-btn cc-btn-primary" style="flex:1">
            ➕ Nuevo reporte
          </button>
        </div>
      </div>
    `);

    // Sumar puntos (RN-20)
    this._sumarPuntosReputacion('nuevo');

    // Disparar evento para generar cupón (integración con módulo cupones)
    window.dispatchEvent(new CustomEvent('reporte:nuevo', {
      detail: {
        tipo: this._tipoSeleccionado,
        confianza: this._resultadoIA.confianza,
        gps: this._gps,
      }
    }));

    // Disparar evento para agregar marcador al mapa
    window.dispatchEvent(new CustomEvent('mapa:nuevoReporte', {
      detail: {
        lat: this._gps?.lat,
        lng: this._gps?.lng,
        tipo: this._tipoSeleccionado,
        confianza: this._resultadoIA.confianza,
      }
    }));

    document.getElementById('btn-ver-mapa-final')?.addEventListener('click', () => {
      window.dispatchEvent(new CustomEvent('nav:tab', { detail: { tab: 'mapa' } }));
    });

    document.getElementById('btn-nuevo-reporte')?.addEventListener('click', async () => {
      this._reset();
      await this.init(this._container.id);
    });
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  /**
   * Renderiza el shell común del wizard (header + barra de progreso + contenido).
   */
  _renderShell(titulo, paso, contenido) {
    const totalPasos = 10;
    const pct = Math.round((paso / totalPasos) * 100);

    this._container.innerHTML = `
      <style>
        .cc-btn {
          padding: 12px 16px;
          border-radius: 10px;
          border: none;
          cursor: pointer;
          font-size: 15px;
          font-weight: 600;
          transition: all 0.2s;
        }
        .cc-btn-primary {
          background: #4299e1;
          color: white;
        }
        .cc-btn-primary:hover { background: #3182ce; }
        .cc-btn-secondary {
          background: #edf2f7;
          color: #4a5568;
        }
        .cc-btn-secondary:hover { background: #e2e8f0; }
      </style>

      <div style="padding:16px; max-width:420px; margin:0 auto;">
        <div style="margin-bottom:16px;">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
            <h2 style="font-size:18px; font-weight:700; color:#1a202c; margin:0;">${titulo}</h2>
            <span style="font-size:12px; color:#a0aec0;">Paso ${paso} de ${totalPasos}</span>
          </div>
          <div style="height:4px; background:#e2e8f0; border-radius:4px; overflow:hidden;">
            <div style="
              height:100%; width:${pct}%; background:linear-gradient(90deg,#4299e1,#63b3ed);
              border-radius:4px; transition:width 0.4s ease;
            "></div>
          </div>
        </div>
        ${contenido}
      </div>
    `;
  }

  /**
   * Genera HTML de confetti animado con CSS.
   */
  _generarConfettiHTML() {
    const colores = ['#f6e05e','#68d391','#63b3ed','#fc8181','#b794f4','#f6ad55'];
    return Array.from({ length: 20 }, (_, i) => {
      const color  = colores[i % colores.length];
      const left   = Math.random() * 100;
      const delay  = Math.random() * 0.8;
      const size   = 6 + Math.random() * 6;
      return `
        <div style="
          position:absolute; left:${left}%; top:-10px;
          width:${size}px; height:${size}px;
          background:${color}; border-radius:${Math.random() > 0.5 ? '50%' : '2px'};
          animation:fall 1.2s ease-in ${delay}s forwards;
        "></div>
      `;
    }).join('') + `
      <style>
        @keyframes fall {
          to { top: 90px; opacity:0; transform:rotate(${Math.random() * 360}deg); }
        }
      </style>
    `;
  }

  /**
   * Detiene el stream de video de la cámara.
   */
  _detenerStream() {
    if (this._stream) {
      this._stream.getTracks().forEach(t => t.stop());
      this._stream = null;
    }
    if (this._videoEl) {
      this._videoEl.srcObject = null;
      this._videoEl = null;
    }
  }

  /**
   * Guarda el reporte en localStorage para sync posterior (modo offline).
   */
  _guardarOffline(reporte) {
    try {
      const pendientes = JSON.parse(localStorage.getItem('cc_pendientes_sync') || '[]');
      pendientes.push({
        ...reporte,
        timestamp: new Date().toISOString(),
        _pendiente_sync: true,
      });
      localStorage.setItem('cc_pendientes_sync', JSON.stringify(pendientes));
      console.log('[ReportarModule] Reporte guardado offline para sync posterior.');
    } catch (err) {
      console.warn('[ReportarModule] No se pudo guardar offline:', err);
    }
  }

  /**
   * Registra un error offline para diagnóstico.
   */
  _registrarErrorOffline(tipo, mensaje) {
    try {
      const errores = JSON.parse(localStorage.getItem('cc_errores') || '[]');
      errores.push({ tipo, mensaje, fecha: new Date().toISOString() });
      if (errores.length > 50) errores.shift();
      localStorage.setItem('cc_errores', JSON.stringify(errores));
    } catch { /* ignorar */ }
  }

  /**
   * Suma puntos de reputación al localStorage del usuario.
   * @param {'nuevo'|'agrupado'} motivo
   */
  _sumarPuntosReputacion(motivo) {
    const puntosPorMotivo = { nuevo: 10, agrupado: 5 };
    try {
      const pts = parseInt(localStorage.getItem('cc_puntos') || '0', 10);
      localStorage.setItem('cc_puntos', String(pts + (puntosPorMotivo[motivo] || 0)));
      window.dispatchEvent(new CustomEvent('reputacion:actualizada', {
        detail: { puntos: pts + (puntosPorMotivo[motivo] || 0) }
      }));
    } catch { /* ignorar */ }
  }

  /**
   * Muestra el bloqueo por límite semanal (RN-01).
   */
  _mostrarLimiteSemanal() {
    this._container.innerHTML = `
      <div style="text-align:center; padding:40px 20px; font-family:sans-serif;">
        <div style="font-size:56px; margin-bottom:16px;">⏳</div>
        <h3 style="color:#2d3748; margin-bottom:8px;">Límite semanal alcanzado</h3>
        <p style="color:#718096; font-size:14px; margin-bottom:20px;">
          Ya realizaste un reporte esta semana. Podés volver a reportar en 7 días.<br>
          <small>(RN-01: Máximo 1 reporte por semana por usuario)</small>
        </p>
        <div style="
          background:#fff3cd; border-radius:12px; padding:16px; color:#856404; font-size:13px;
        ">
          💡 Mientras tanto, podés apoyar los reportes existentes de otros vecinos en el mapa.
        </div>
      </div>
    `;
  }

  /**
   * Resetea el estado del módulo para un nuevo reporte.
   */
  _reset() {
    this._detenerStream();
    this._paso = 0;
    this._fotoDataURL = null;
    this._tipoSeleccionado = null;
    this._resultadoIA = null;
    this._gps = null;
    this._timestamp = null;
  }
}

export default ReportarModule;
