/**
 * comercios.js — Módulo de Comercios Adheridos para CiudadConecta Punta Alta
 * Gestiona la lista de comercios con el programa de descuentos 25% OFF.
 * Stack: Vanilla JS ES modules + Firebase Firestore v10 CDN
 */

import {
  getFirestore,
  collection,
  getDocs,
  addDoc,
  query,
  where,
  serverTimestamp
} from '../firebase-init.js';

// ──────────────────────────────────────────────
// Lista hardcoded de comercios ficticios de Punta Alta
// Se usa como fallback si Firestore está vacío (demo / offline)
// ──────────────────────────────────────────────

const COMERCIOS_HARDCODED = [
  {
    id: 'com-1',
    nombre: 'La Ferretería del Centro',
    logo_emoji: '🔧',
    direccion: 'Av. Colón 450',
    categoria: 'Ferretería',
    telefono: '+54 291 456-0001',
    lat: -38.8791,
    lng: -62.0817,
    adherido: true,
    descripcion: 'Herramientas, materiales de construcción y artículos para el hogar.',
  },
  {
    id: 'com-2',
    nombre: 'Farmacia San Martín',
    logo_emoji: '💊',
    direccion: 'San Martín 123',
    categoria: 'Farmacia',
    telefono: '+54 291 456-0002',
    lat: -38.8820,
    lng: -62.0750,
    adherido: true,
    descripcion: 'Medicamentos, cosméticos y artículos de salud con atención personalizada.',
  },
  {
    id: 'com-3',
    nombre: 'Panadería El Trigo',
    logo_emoji: '🥖',
    direccion: 'Belgrano 78',
    categoria: 'Panadería',
    telefono: '+54 291 456-0003',
    lat: -38.8801,
    lng: -62.0830,
    adherido: true,
    descripcion: 'Pan artesanal, facturas y productos de pastelería frescos todos los días.',
  },
  {
    id: 'com-4',
    nombre: 'Librería Saber',
    logo_emoji: '📚',
    direccion: 'Brown 234',
    categoria: 'Librería',
    telefono: '+54 291 456-0004',
    lat: -38.8815,
    lng: -62.0795,
    adherido: true,
    descripcion: 'Libros, útiles escolares, papelería y artículos de oficina.',
  },
  {
    id: 'com-5',
    nombre: 'Bar Los Amigos',
    logo_emoji: '☕',
    direccion: 'Rivadavia 567',
    categoria: 'Gastronomía',
    telefono: '+54 291 456-0005',
    lat: -38.8835,
    lng: -62.0760,
    adherido: true,
    descripcion: 'Café, medialunas, sánguches y menú del día en el centro de Punta Alta.',
  },
  {
    id: 'com-6',
    nombre: 'Verdulería La Huerta',
    logo_emoji: '🥬',
    direccion: 'Moreno 89',
    categoria: 'Verdulería',
    telefono: '+54 291 456-0006',
    lat: -38.8808,
    lng: -62.0845,
    adherido: true,
    descripcion: 'Frutas y verduras frescas de productores locales. Compra y envío a domicilio.',
  },
  {
    id: 'com-7',
    nombre: 'Indumentaria Moda BA',
    logo_emoji: '👕',
    direccion: 'Av. Independencia 345',
    categoria: 'Indumentaria',
    telefono: '+54 291 456-0007',
    lat: -38.8778,
    lng: -62.0810,
    adherido: true,
    descripcion: 'Ropa para toda la familia, calzado y accesorios. Temporadas actuales.',
  },
  {
    id: 'com-8',
    nombre: 'Rotisería Don Pedro',
    logo_emoji: '🍗',
    direccion: 'España 12',
    categoria: 'Gastronomía',
    telefono: '+54 291 456-0008',
    lat: -38.8825,
    lng: -62.0770,
    adherido: true,
    descripcion: 'Pollo al spiedo, empanadas, milanesas y comidas listas para llevar.',
  },
];

// ──────────────────────────────────────────────
// ComerciosModule
// ──────────────────────────────────────────────

export class ComerciosModule {
  /**
   * @param {object} app - instancia Firebase App
   * @param {string} contenedorId - id del elemento DOM raíz donde renderizar
   * @param {object} [mapaRef] - referencia opcional al módulo de mapa para fly-to
   */
  constructor(app, contenedorId = 'app-root', mapaRef = null) {
    this.db = getFirestore(app);
    this.contenedorId = contenedorId;
    this.mapaRef = mapaRef;
    this.comercios = [];
    this._filtroActivo = 'todos';
  }

  // ─── init ────────────────────────────────────

  /**
   * Carga los comercios adheridos desde Firestore.
   * Si Firestore está vacío → usa la lista hardcoded y la persiste en Firestore.
   */
  async init() {
    try {
      this._mostrarSkeleton();
      await this._cargarComercios();
      this.renderizarLista();
    } catch (err) {
      console.error('[ComerciosModule] Error en init():', err);
      // Fallback total a hardcoded sin Firestore
      this.comercios = [...COMERCIOS_HARDCODED];
      this.renderizarLista();
    }
  }

  // ─── _cargarComercios ────────────────────────

  async _cargarComercios() {
    const q = query(collection(this.db, 'comercios'), where('adherido', '==', true));
    const snap = await getDocs(q);
    this.comercios = snap.docs.map(d => ({ id: d.id, ...d.data() }));

    // Si Firestore está vacío → usar hardcoded y sembrar la base de datos
    if (this.comercios.length === 0) {
      console.info('[ComerciosModule] Firestore vacío → usando lista hardcoded y sembrando BD');
      this.comercios = [...COMERCIOS_HARDCODED];
      await this._sembrarFirestore();
    }
  }

  /**
   * Persiste los comercios hardcoded en Firestore (seed inicial para demo).
   */
  async _sembrarFirestore() {
    const promesas = COMERCIOS_HARDCODED.map(c =>
      addDoc(collection(this.db, 'comercios'), {
        ...c,
        creado_en: serverTimestamp(),
      })
    );
    try {
      await Promise.all(promesas);
      console.info('[ComerciosModule] Comercios sembrados en Firestore ✓');
    } catch (err) {
      console.warn('[ComerciosModule] No se pudo sembrar Firestore:', err.message);
    }
  }

  // ─── renderizarLista ─────────────────────────

  /**
   * Renderiza el grid completo de comercios adheridos con filtro por categoría.
   */
  renderizarLista() {
    const contenedor = document.getElementById(this.contenedorId);
    if (!contenedor) return;

    const categorias = ['todos', ...new Set(this.comercios.map(c => c.categoria))];
    const filtrados = this._filtroActivo === 'todos'
      ? this.comercios
      : this.comercios.filter(c => c.categoria === this._filtroActivo);

    contenedor.innerHTML = `
      <div class="comercios-screen" style="${estilosBaseCom}">

        <!-- ── Header ── -->
        <div style="
          background: linear-gradient(135deg, #004d40 0%, #00695c 100%);
          color:white; padding:20px 16px 16px;
          border-radius:0 0 24px 24px;
          box-shadow:0 4px 16px rgba(0,77,64,0.3);
        ">
          <div style="font-size:22px; font-weight:700; margin-bottom:4px;">🏪 Comercios Adheridos</div>
          <div style="font-size:13px; opacity:0.85;">
            ${this.comercios.length} comercios • <strong>25% OFF</strong> con tu cupón CiudadConecta
          </div>

          <!-- Chips de categoría -->
          <div style="
            display:flex; gap:8px; overflow-x:auto; padding:12px 0 4px;
            scrollbar-width:none;
          ">
            ${categorias.map(cat => `
              <button
                class="chip-categoria"
                data-cat="${cat}"
                style="
                  white-space:nowrap; border:none; border-radius:20px;
                  padding:6px 14px; font-size:12px; font-weight:600; cursor:pointer;
                  background:${this._filtroActivo === cat ? 'white' : 'rgba(255,255,255,0.2)'};
                  color:${this._filtroActivo === cat ? '#004d40' : 'white'};
                  transition:all 0.2s;
                "
              >${this._capitalize(cat)}</button>
            `).join('')}
          </div>
        </div>

        <!-- ── Grid de comercios ── -->
        <div style="padding:16px;">
          ${filtrados.length === 0
            ? `<div style="text-align:center; padding:48px 0; color:#aaa;">
                <div style="font-size:48px;">🔍</div>
                <div style="margin-top:12px;">Sin comercios en esta categoría</div>
              </div>`
            : `<div class="comercios-grid" style="
                display:grid;
                grid-template-columns:repeat(auto-fill, minmax(260px, 1fr));
                gap:14px;
              ">
                ${filtrados.map(c => this._cardComercio(c)).join('')}
              </div>`
          }
        </div>

        <!-- ── CTA para comerciantes ── -->
        <div style="
          margin:0 16px 32px; padding:20px; text-align:center;
          background:linear-gradient(135deg,#004d40,#00695c); border-radius:16px;
          color:white;
        ">
          <div style="font-size:28px; margin-bottom:8px;">🤝</div>
          <div style="font-weight:700; font-size:16px; margin-bottom:6px;">¿Sos comerciante?</div>
          <div style="font-size:13px; opacity:0.85; margin-bottom:14px;">
            Sumá tu negocio al programa y llegá a toda la comunidad de Punta Alta.
          </div>
          <button id="btn-sumar-comercio" style="
            background:white; color:#004d40; border:none;
            padding:10px 24px; border-radius:20px; font-weight:700;
            font-size:14px; cursor:pointer;
          ">Quiero adherirme →</button>
        </div>

      </div>
    `;

    this._bindEventos();
  }

  // ─── _cardComercio ───────────────────────────

  _cardComercio(comercio) {
    return `
      <div class="comercio-card" style="
        background:white; border-radius:16px; overflow:hidden;
        box-shadow:0 2px 12px rgba(0,0,0,0.09);
        display:flex; flex-direction:column;
        transition:transform 0.15s, box-shadow 0.15s;
        position:relative;
      "
        onmouseenter="this.style.transform='translateY(-3px)';this.style.boxShadow='0 6px 20px rgba(0,0,0,0.15)'"
        onmouseleave="this.style.transform='translateY(0)';this.style.boxShadow='0 2px 12px rgba(0,0,0,0.09)'"
      >
        <!-- Badge descuento -->
        <div style="
          position:absolute; top:12px; right:12px;
          background:linear-gradient(135deg,#e65100,#f57c00);
          color:white; font-size:11px; font-weight:800;
          padding:4px 10px; border-radius:10px;
          box-shadow:0 2px 8px rgba(230,81,0,0.4);
        ">25% OFF</div>

        <!-- Header de la card con emoji grande -->
        <div style="
          background:linear-gradient(135deg,#004d40,#00796b);
          padding:24px 16px 16px; text-align:center;
        ">
          <div style="font-size:52px; filter:drop-shadow(0 2px 4px rgba(0,0,0,0.2));">
            ${comercio.logo_emoji}
          </div>
        </div>

        <!-- Contenido -->
        <div style="padding:14px 16px 16px; flex:1; display:flex; flex-direction:column; gap:6px;">
          <!-- Nombre -->
          <div style="font-size:15px; font-weight:800; color:#1b1b1b; line-height:1.2;">
            ${comercio.nombre}
          </div>

          <!-- Categoría -->
          <span style="
            display:inline-block; font-size:11px; font-weight:600;
            background:#e0f2f1; color:#00695c;
            padding:2px 10px; border-radius:10px; width:fit-content;
          ">${comercio.categoria}</span>

          <!-- Dirección -->
          <div style="font-size:13px; color:#666; display:flex; align-items:flex-start; gap:4px; margin-top:2px;">
            <span style="margin-top:1px;">📍</span>
            <span>${comercio.direccion}</span>
          </div>

          ${comercio.descripcion ? `
            <div style="font-size:12px; color:#888; line-height:1.4; margin-top:2px;">
              ${comercio.descripcion}
            </div>
          ` : ''}

          ${comercio.telefono ? `
            <div style="font-size:12px; color:#555; display:flex; align-items:center; gap:4px;">
              📞 <a href="tel:${comercio.telefono}" style="color:#00695c; text-decoration:none; font-weight:600;">
                ${comercio.telefono}
              </a>
            </div>
          ` : ''}

          <!-- Botones acción -->
          <div style="display:flex; gap:8px; margin-top:auto; padding-top:10px;">
            <button
              class="btn-ver-mapa"
              data-comercio-id="${comercio.id}"
              data-lat="${comercio.lat ?? ''}"
              data-lng="${comercio.lng ?? ''}"
              data-nombre="${comercio.nombre}"
              style="
                flex:1; padding:9px; border:2px solid #004d40;
                color:#004d40; background:transparent;
                border-radius:10px; font-size:13px; font-weight:700;
                cursor:pointer; transition:all 0.15s;
              "
              onmouseenter="this.style.background='#004d40';this.style.color='white'"
              onmouseleave="this.style.background='transparent';this.style.color='#004d40'"
            >🗺️ Ver en mapa</button>

            <button
              class="btn-usar-aqui"
              data-comercio-id="${comercio.id}"
              style="
                flex:1; padding:9px; border:none;
                background:linear-gradient(135deg,#004d40,#00695c);
                color:white; border-radius:10px;
                font-size:13px; font-weight:700; cursor:pointer;
              "
            >🎟️ Usar cupón</button>
          </div>
        </div>
      </div>
    `;
  }

  // ─── mostrarEnMapa ───────────────────────────

  /**
   * Navega a la pantalla de mapa y hace fly a las coordenadas del comercio.
   * @param {string} comercioId
   */
  mostrarEnMapa(comercioId) {
    const comercio = this.comercios.find(c => c.id === comercioId);
    if (!comercio) return;

    const { lat, lng, nombre } = comercio;

    // Si hay referencia al módulo de mapa → usar su API
    if (this.mapaRef && typeof this.mapaRef.flyTo === 'function') {
      this.mapaRef.flyTo(lat, lng, nombre);
      return;
    }

    // Alternativa: despachar evento personalizado que el router/mapa puede escuchar
    const evento = new CustomEvent('ciudadconecta:verEnMapa', {
      detail: { comercioId, lat, lng, nombre },
      bubbles: true,
    });
    document.dispatchEvent(evento);

    // Fallback visual: abrir en Google Maps si no hay integración nativa
    const url = `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
    const abrirMaps = confirm(`¿Abrir "${nombre}" en Google Maps?`);
    if (abrirMaps) window.open(url, '_blank');
  }

  // ─── Helpers ─────────────────────────────────

  _mostrarSkeleton() {
    const contenedor = document.getElementById(this.contenedorId);
    if (!contenedor) return;
    contenedor.innerHTML = `
      <div style="padding:20px; ${estilosBaseCom}">
        <div style="height:140px; background:#e0f2f1; border-radius:24px; animation:comSkel 1.4s infinite;"></div>
        <div style="margin-top:14px; display:grid; grid-template-columns:1fr 1fr; gap:12px;">
          ${[...Array(4)].map(() =>
            `<div style="height:220px; background:#e0f2f1; border-radius:16px; animation:comSkel 1.4s infinite;"></div>`
          ).join('')}
        </div>
        <style>@keyframes comSkel{0%,100%{opacity:1}50%{opacity:0.4}}</style>
      </div>
    `;
  }

  _bindEventos() {
    // Filtros de categoría
    document.querySelectorAll('.chip-categoria').forEach(chip => {
      chip.addEventListener('click', () => {
        this._filtroActivo = chip.dataset.cat;
        this.renderizarLista();
        // Scroll al top del contenedor
        document.getElementById(this.contenedorId)?.scrollTo({ top: 0, behavior: 'smooth' });
      });
    });

    // Botones "Ver en mapa"
    document.querySelectorAll('.btn-ver-mapa').forEach(btn => {
      btn.addEventListener('click', () => {
        this.mostrarEnMapa(btn.dataset.comercioId);
      });
    });

    // Botones "Usar cupón aquí"
    document.querySelectorAll('.btn-usar-aqui').forEach(btn => {
      btn.addEventListener('click', () => {
        const comercioId = btn.dataset.comercioId;
        // Despachar evento para que el módulo de cupones abra el QR
        const evt = new CustomEvent('ciudadconecta:usarCuponEnComercio', {
          detail: { comercioId },
          bubbles: true,
        });
        document.dispatchEvent(evt);
      });
    });

    // CTA "Quiero adherirme"
    document.getElementById('btn-sumar-comercio')?.addEventListener('click', () => {
      this._mostrarFormularioAdherirse();
    });
  }

  /**
   * Muestra un modal simple para que un comerciante exprese interés.
   * (MVP: no guarda en Firestore real, solo muestra confirmación)
   */
  _mostrarFormularioAdherirse() {
    const modal = document.createElement('div');
    modal.style.cssText = `
      position:fixed; inset:0; z-index:9999;
      background:rgba(0,0,0,0.6); display:flex; align-items:center; justify-content:center;
      padding:20px;
    `;
    modal.innerHTML = `
      <div style="
        background:white; border-radius:20px; padding:28px 24px;
        max-width:400px; width:100%; box-shadow:0 20px 60px rgba(0,0,0,0.3);
        animation:modalIn 0.3s ease;
      ">
        <style>@keyframes modalIn{from{opacity:0;transform:scale(0.9)}to{opacity:1;transform:scale(1)}}</style>
        <div style="font-size:32px; text-align:center; margin-bottom:12px;">🤝</div>
        <h3 style="margin:0 0 8px; font-size:18px; color:#004d40; text-align:center;">
          Adherí tu comercio
        </h3>
        <p style="font-size:13px; color:#666; text-align:center; margin:0 0 20px; line-height:1.5;">
          Completá tus datos y te contactamos para sumarte al programa de descuentos.
        </p>
        <input id="adh-nombre" placeholder="Nombre del comercio" style="${inputStyle}" />
        <input id="adh-tel" placeholder="Teléfono de contacto" type="tel" style="${inputStyle}" />
        <input id="adh-email" placeholder="Email" type="email" style="${inputStyle}" />
        <div style="display:flex; gap:10px; margin-top:4px;">
          <button id="btn-cancelar-adh" style="
            flex:1; padding:12px; border:2px solid #004d40; background:transparent;
            color:#004d40; border-radius:12px; font-weight:700; cursor:pointer;
          ">Cancelar</button>
          <button id="btn-enviar-adh" style="
            flex:1; padding:12px; border:none;
            background:linear-gradient(135deg,#004d40,#00695c);
            color:white; border-radius:12px; font-weight:700; cursor:pointer;
          ">Enviar →</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    document.getElementById('btn-cancelar-adh')?.addEventListener('click', () => modal.remove());
    modal.addEventListener('click', (e) => { if (e.target === modal) modal.remove(); });

    document.getElementById('btn-enviar-adh')?.addEventListener('click', async () => {
      const nombre = document.getElementById('adh-nombre')?.value?.trim();
      const tel = document.getElementById('adh-tel')?.value?.trim();
      const email = document.getElementById('adh-email')?.value?.trim();

      if (!nombre || !tel) {
        document.getElementById('adh-nombre').style.borderColor = nombre ? '#ccc' : '#c62828';
        document.getElementById('adh-tel').style.borderColor = tel ? '#ccc' : '#c62828';
        return;
      }

      try {
        await addDoc(collection(this.db, 'solicitudes_adherencia'), {
          nombre, telefono: tel, email,
          fecha: serverTimestamp(),
          estado: 'pendiente',
        });
      } catch { /* silencioso — puede fallar en modo demo */ }

      modal.remove();
      this._mostrarToast('¡Solicitud enviada! Te contactamos pronto 🎉', '#004d40');
    });
  }

  _mostrarToast(msg, color = '#004d40') {
    const toast = document.createElement('div');
    toast.style.cssText = `
      position:fixed; bottom:32px; left:50%; transform:translateX(-50%);
      background:${color}; color:white;
      padding:12px 24px; border-radius:50px; font-size:14px; font-weight:700;
      box-shadow:0 8px 24px ${color}55; z-index:10001;
      max-width:90vw; text-align:center; white-space:nowrap;
    `;
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(() => { toast.style.opacity='0'; toast.style.transition='opacity 0.3s'; setTimeout(()=>toast.remove(),350); }, 3000);
  }

  _capitalize(s) {
    if (!s) return '';
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  // ─── API pública de datos ────────────────────

  /**
   * Devuelve el array de comercios cargados (útil para otros módulos).
   * @returns {Array}
   */
  getComerciosAdheridos() { return this.comercios; }

  /**
   * Busca un comercio por id.
   * @param {string} id
   * @returns {object|undefined}
   */
  getComercio(id) { return this.comercios.find(c => c.id === id); }
}

// ── Estilos compartidos ───────────────────────
const estilosBaseCom = `
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  max-width:680px; margin:0 auto; min-height:100vh; background:#f1f8f7;
`;

const inputStyle = `
  width:100%; padding:11px 14px; border:1.5px solid #ccc;
  border-radius:10px; font-size:14px; margin-bottom:10px;
  outline:none; box-sizing:border-box;
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
`;

export default ComerciosModule;
