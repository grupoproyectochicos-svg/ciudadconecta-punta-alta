/**
 * mapa.js — Módulo del Mapa Interactivo · CiudadConecta Punta Alta
 * ----------------------------------------------------------------
 * Requiere: Leaflet.js cargado globalmente (window.L)
 * Requiere: firebase-init.js exportando { db, onSnapshot, collection, query, where }
 *
 * Uso:
 *   import { MapaModule } from './modules/mapa.js';
 *   const mapa = new MapaModule();
 *   await mapa.init('map-container');
 */

import {
  db,
  collection,
  query,
  where,
  onSnapshot,
} from '../firebase-init.js';

// ── Constantes ────────────────────────────────────────────────────────────────

const PUNTA_ALTA = { lat: -38.8802, lng: -62.0700 };
const ZOOM_INICIAL = 14;
const TILE_URL = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
const TILE_ATTRIBUTION =
  '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

/** Configuración visual de cada tipo de incidente */
const TIPO_CONFIG = {
  bache: {
    color: '#e53e3e',
    fillColor: '#fc8181',
    emoji: '🕳️',
    label: 'Bache',
  },
  desague: {
    color: '#d69e2e',
    fillColor: '#f6e05e',
    emoji: '🌊',
    label: 'Desagüe',
  },
  reciclaje: {
    color: '#38a169',
    fillColor: '#68d391',
    emoji: '♻️',
    label: 'Reciclaje',
  },
};

/** Colores de badge por estado */
const ESTADO_BADGE = {
  recibido:   { bg: '#bee3f8', color: '#2b6cb0', label: 'Recibido' },
  en_agenda:  { bg: '#fefcbf', color: '#975a16', label: 'En agenda' },
  en_obra:    { bg: '#fed7aa', color: '#c05621', label: 'En obra' },
  resuelto:   { bg: '#c6f6d5', color: '#276749', label: 'Resuelto ✓' },
};

// ── Clase MapaModule ──────────────────────────────────────────────────────────

export class MapaModule {
  constructor() {
    /** @type {L.Map|null} */
    this.map = null;

    /** Grupos de capas por tipo para el control de visibilidad */
    this.capas = {
      bache: null,
      desague: null,
      reciclaje: null,
    };

    /** Mapa de marcadores: docId → L.CircleMarker */
    this._marcadores = new Map();

    /** Unsubscribe del listener de Firestore */
    this._unsubscribe = null;

    /** Marcador de posición del usuario */
    this._markerUsuario = null;

    /** Marcadores temporales (antes de confirmar reporte) */
    this._marcadoresTemp = [];

    /** Cache de reportes para heatmap */
    this._reportesCache = [];

    /** Capa de heatmap (polígonos SVG simulados) */
    this._heatmapLayer = null;

    /** Control de estadísticas DOM */
    this._statsEl = null;
  }

  // ── init ──────────────────────────────────────────────────────────────────

  /**
   * Inicializa el mapa Leaflet dentro del contenedor indicado.
   * @param {string} containerId - ID del elemento DOM (sin #)
   * @returns {Promise<void>}
   */
  async init(containerId) {
    // Verificar que Leaflet esté disponible
    if (typeof L === 'undefined') {
      throw new Error('Leaflet.js no está cargado. Incluí el script en el HTML.');
    }

    const container = document.getElementById(containerId);
    if (!container) {
      throw new Error(`Contenedor #${containerId} no encontrado en el DOM.`);
    }

    // ── Crear mapa ──────────────────────────────────────────────────────────
    this.map = L.map(containerId, {
      center: [PUNTA_ALTA.lat, PUNTA_ALTA.lng],
      zoom: ZOOM_INICIAL,
      zoomControl: true,
      attributionControl: true,
    });

    // ── Tiles OSM ───────────────────────────────────────────────────────────
    L.tileLayer(TILE_URL, {
      attribution: TILE_ATTRIBUTION,
      maxZoom: 19,
    }).addTo(this.map);

    // ── Grupos de capas ─────────────────────────────────────────────────────
    this.capas.bache    = L.layerGroup().addTo(this.map);
    this.capas.desague  = L.layerGroup().addTo(this.map);
    this.capas.reciclaje = L.layerGroup().addTo(this.map);

    // ── Control de capas ────────────────────────────────────────────────────
    const overlays = {
      '🕳️ Baches':    this.capas.bache,
      '🌊 Desagües':  this.capas.desague,
      '♻️ Reciclaje': this.capas.reciclaje,
    };
    L.control.layers(null, overlays, { position: 'topright', collapsed: false }).addTo(this.map);

    // ── Panel de estadísticas ───────────────────────────────────────────────
    this._crearPanelEstadisticas();

    // ── Cargar datos y escuchar actualizaciones ─────────────────────────────
    this.escucharActualizaciones();

    console.log('[MapaModule] Inicializado correctamente en Punta Alta.');
  }

  // ── Panel de estadísticas ─────────────────────────────────────────────────

  _crearPanelEstadisticas() {
    const statsControl = L.control({ position: 'bottomleft' });

    statsControl.onAdd = () => {
      const div = L.DomUtil.create('div', 'mapa-stats');
      div.style.cssText = `
        background: rgba(255,255,255,0.92);
        padding: 8px 12px;
        border-radius: 8px;
        font-size: 12px;
        font-family: sans-serif;
        box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        line-height: 1.6;
        min-width: 200px;
      `;
      div.innerHTML = '<strong>📊 Cargando estadísticas...</strong>';
      this._statsEl = div;
      return div;
    };

    statsControl.addTo(this.map);
  }

  /**
   * Actualiza el panel de estadísticas según los reportes en cache.
   */
  _actualizarEstadisticas() {
    if (!this._statsEl) return;

    const reportes = this._reportesCache;
    const total = reportes.length;
    const baches  = reportes.filter(r => r.tipo === 'bache').length;
    const desagues = reportes.filter(r => r.tipo === 'desague').length;
    const reciclaje = reportes.filter(r => r.tipo === 'reciclaje').length;

    // Resueltos esta semana
    const haceSieteDias = Date.now() - 7 * 24 * 60 * 60 * 1000;
    const resueltasSemana = reportes.filter(r => {
      const ts = r.timestamp?.toMillis ? r.timestamp.toMillis() : (r.timestamp || 0);
      return r.estado === 'resuelto' && ts >= haceSieteDias;
    }).length;

    this._statsEl.innerHTML = `
      <strong style="color:#2d3748">📊 Estado de Punta Alta</strong><br>
      <span style="color:#e53e3e">🕳️ ${baches} baches activos</span><br>
      <span style="color:#d69e2e">🌊 ${desagues} desagües</span><br>
      <span style="color:#38a169">♻️ ${reciclaje} reciclaje</span><br>
      <span style="color:#276749">✅ ${resueltasSemana} resueltos esta semana</span><br>
      <span style="color:#718096;font-size:11px">Total activos: ${total}</span>
    `;
  }

  // ── cargarReportes ────────────────────────────────────────────────────────

  /**
   * Carga reportes activos de Firestore y pinta los marcadores.
   * Uso interno — preferir escucharActualizaciones() para tiempo real.
   */
  async cargarReportes() {
    // escucharActualizaciones ya hace esto con onSnapshot
    // Este método existe para compatibilidad / uso manual
    this.escucharActualizaciones();
  }

  // ── escucharActualizaciones ───────────────────────────────────────────────

  /**
   * Activa un listener onSnapshot en Firestore para actualizar el mapa en tiempo real.
   * Solo consulta reportes con activo == true.
   */
  escucharActualizaciones() {
    // Cancelar listener anterior si existe
    if (this._unsubscribe) {
      this._unsubscribe();
    }

    const q = query(
      collection(db, 'reportes'),
      where('activo', '==', true)
    );

    this._unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        // Procesar cambios incrementales
        snapshot.docChanges().forEach((change) => {
          const id = change.doc.id;
          const data = { id, ...change.doc.data() };

          if (change.type === 'added' || change.type === 'modified') {
            this._upsertMarcador(id, data);
          } else if (change.type === 'removed') {
            this._removerMarcador(id);
          }
        });

        // Actualizar cache completo para estadísticas
        this._reportesCache = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
        this._actualizarEstadisticas();
        this.generarHeatmap();
      },
      (error) => {
        console.error('[MapaModule] Error en Firestore onSnapshot:', error);
      }
    );
  }

  // ── _upsertMarcador ───────────────────────────────────────────────────────

  /**
   * Crea o actualiza el marcador de un reporte en el mapa.
   * @param {string} id
   * @param {Object} data
   */
  _upsertMarcador(id, data) {
    const { tipo, lat, lng, estado, timestamp, agrupado_con = [] } = data;

    if (lat == null || lng == null) return;

    const cfg = TIPO_CONFIG[tipo] || TIPO_CONFIG.bache;
    const cantidadAgrupados = Array.isArray(agrupado_con) ? agrupado_con.length + 1 : 1;
    const radius = 5 + (cantidadAgrupados - 1) * 2; // RN-04: radio cresce con agrupamiento

    // Quitar marcador anterior si existía
    this._removerMarcador(id);

    const marker = L.circleMarker([lat, lng], {
      radius,
      color: cfg.color,
      fillColor: cfg.fillColor,
      fillOpacity: 0.75,
      weight: 2,
      opacity: 0.9,
    });

    // Determinar la capa correcta
    const capa = this.capas[tipo] || this.capas.bache;
    marker.addTo(capa);

    // Popup con información del reporte
    const popup = this._crearPopup(data, cantidadAgrupados);
    marker.bindPopup(popup, { maxWidth: 260 });

    // Tooltip al hover
    marker.bindTooltip(
      `${cfg.emoji} ${cfg.label} — ${cantidadAgrupados > 1 ? cantidadAgrupados + ' reportes' : '1 reporte'}`,
      { direction: 'top', offset: [0, -5] }
    );

    this._marcadores.set(id, marker);
  }

  // ── _crearPopup ───────────────────────────────────────────────────────────

  /**
   * Genera el HTML del popup de un marcador.
   */
  _crearPopup(data, cantidadAgrupados) {
    const { id, tipo, estado = 'recibido', timestamp, descripcion = '' } = data;
    const cfg = TIPO_CONFIG[tipo] || TIPO_CONFIG.bache;
    const badge = ESTADO_BADGE[estado] || ESTADO_BADGE.recibido;

    // Formatear fecha
    let fechaStr = 'Sin fecha';
    if (timestamp) {
      const ts = timestamp.toMillis ? timestamp.toMillis() : timestamp;
      fechaStr = new Date(ts).toLocaleDateString('es-AR', {
        day: '2-digit', month: '2-digit', year: 'numeric',
      });
    }

    return `
      <div style="font-family: sans-serif; font-size: 13px; min-width: 200px;">
        <div style="font-weight: bold; font-size: 15px; margin-bottom: 6px;">
          ${cfg.emoji} ${cfg.label}
        </div>
        <div style="margin-bottom: 6px;">
          <span style="
            background: ${badge.bg};
            color: ${badge.color};
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
          ">${badge.label}</span>
        </div>
        ${cantidadAgrupados > 1
          ? `<div style="color:#718096; font-size:12px; margin-bottom:4px;">👥 ${cantidadAgrupados} vecinos reportaron esto</div>`
          : ''}
        ${descripcion
          ? `<div style="color:#4a5568; margin-bottom:6px; font-size:12px;">${descripcion.substring(0, 80)}${descripcion.length > 80 ? '…' : ''}</div>`
          : ''}
        <div style="color:#a0aec0; font-size:11px; margin-bottom:8px;">📅 ${fechaStr}</div>
        <button
          onclick="window.dispatchEvent(new CustomEvent('mapa:verDetalle', { detail: { id: '${id}' } }))"
          style="
            background: #4299e1;
            color: white;
            border: none;
            padding: 5px 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            width: 100%;
          "
        >Ver detalle →</button>
      </div>
    `;
  }

  // ── _removerMarcador ──────────────────────────────────────────────────────

  /**
   * Elimina un marcador del mapa.
   * @param {string} id
   */
  _removerMarcador(id) {
    const marker = this._marcadores.get(id);
    if (marker) {
      marker.remove();
      this._marcadores.delete(id);
    }
  }

  // ── centrarEnUsuario ──────────────────────────────────────────────────────

  /**
   * Obtiene la geolocalización del usuario y centra el mapa en su posición.
   * Agrega un marcador azul pulsante en la posición actual.
   * @returns {Promise<{lat: number, lng: number}>}
   */
  centrarEnUsuario() {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocalización no soportada por este navegador.'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const { latitude: lat, longitude: lng, accuracy } = pos.coords;

          // Volar suavemente a la posición del usuario
          this.map.flyTo([lat, lng], 16, { animate: true, duration: 1.2 });

          // Quitar marcador anterior si existía
          if (this._markerUsuario) {
            this._markerUsuario.remove();
          }

          // Marcador azul con círculo de precisión
          this._markerUsuario = L.circleMarker([lat, lng], {
            radius: 8,
            color: '#3182ce',
            fillColor: '#63b3ed',
            fillOpacity: 0.9,
            weight: 3,
          }).addTo(this.map);

          // Círculo de precisión
          L.circle([lat, lng], {
            radius: accuracy,
            color: '#3182ce',
            fillColor: '#bee3f8',
            fillOpacity: 0.15,
            weight: 1,
          }).addTo(this.map);

          this._markerUsuario.bindPopup(
            `<b>📍 Tu ubicación</b><br><small>Precisión: ±${Math.round(accuracy)} m</small>`
          ).openPopup();

          resolve({ lat, lng });
        },
        (err) => {
          console.warn('[MapaModule] Error de geolocalización:', err.message);
          reject(err);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    });
  }

  // ── agregarReporte ────────────────────────────────────────────────────────

  /**
   * Agrega un marcador temporal en el mapa mientras se confirma el reporte.
   * @param {number} lat
   * @param {number} lng
   * @param {'bache'|'desague'|'reciclaje'} tipo
   * @param {number} confianza - Valor 0-100
   * @returns {L.CircleMarker} Marcador temporal (para poder removerlo luego)
   */
  agregarReporte(lat, lng, tipo, confianza) {
    const cfg = TIPO_CONFIG[tipo] || TIPO_CONFIG.bache;

    const marker = L.circleMarker([lat, lng], {
      radius: 7,
      color: cfg.color,
      fillColor: cfg.fillColor,
      fillOpacity: 0.5,
      weight: 2,
      dashArray: '4,4', // Línea punteada para indicar que es provisional
    }).addTo(this.map);

    marker.bindTooltip(
      `⏳ ${cfg.emoji} Pendiente de confirmación (IA: ${confianza}%)`,
      { permanent: true, direction: 'top', className: 'marker-temp-tooltip' }
    );

    this._marcadoresTemp.push(marker);

    // Centrar mapa en el nuevo reporte
    this.map.panTo([lat, lng]);

    return marker;
  }

  /**
   * Elimina todos los marcadores temporales del mapa.
   */
  limpiarMarcadoresTemp() {
    this._marcadoresTemp.forEach(m => m.remove());
    this._marcadoresTemp = [];
  }

  // ── generarHeatmap ────────────────────────────────────────────────────────

  /**
   * Genera un heatmap simulado coloreando zonas según densidad de reportes.
   * Divide el área de Punta Alta en una grilla y colorea cada celda.
   */
  generarHeatmap() {
    if (!this.map || this._reportesCache.length === 0) return;

    // Quitar heatmap anterior
    if (this._heatmapLayer) {
      this._heatmapLayer.clearLayers();
    } else {
      this._heatmapLayer = L.layerGroup();
      // El heatmap NO se agrega al mapa por defecto — se activa con toggle
      // Comentar la siguiente línea para que sea opt-in:
      // this._heatmapLayer.addTo(this.map);
    }

    // Configuración de la grilla
    const CELDA_GRADOS = 0.003; // ~333m por celda
    const celdas = new Map(); // "lat_lng" → count

    for (const r of this._reportesCache) {
      if (!r.lat || !r.lng) continue;
      const keyLat = Math.floor(r.lat / CELDA_GRADOS) * CELDA_GRADOS;
      const keyLng = Math.floor(r.lng / CELDA_GRADOS) * CELDA_GRADOS;
      const key = `${keyLat}_${keyLng}`;
      celdas.set(key, (celdas.get(key) || 0) + 1);
    }

    const maxCount = Math.max(...celdas.values(), 1);

    celdas.forEach((count, key) => {
      const [latStr, lngStr] = key.split('_');
      const lat = parseFloat(latStr);
      const lng = parseFloat(lngStr);

      // Intensidad 0–1
      const intensidad = count / maxCount;

      // Color interpolado: verde → amarillo → rojo
      const r = Math.round(intensidad * 220);
      const g = Math.round((1 - intensidad) * 180);
      const b = 30;
      const color = `rgb(${r},${g},${b})`;

      const rect = L.rectangle(
        [[lat, lng], [lat + CELDA_GRADOS, lng + CELDA_GRADOS]],
        {
          color: 'transparent',
          fillColor: color,
          fillOpacity: 0.25 + intensidad * 0.25,
          weight: 0,
        }
      );

      rect.bindTooltip(`🌡️ ${count} reporte${count > 1 ? 's' : ''} en esta zona`, {
        sticky: true,
      });

      this._heatmapLayer.addLayer(rect);
    });
  }

  /**
   * Muestra u oculta el heatmap del mapa.
   * @param {boolean} visible
   */
  toggleHeatmap(visible) {
    if (!this._heatmapLayer) return;
    if (visible) {
      this._heatmapLayer.addTo(this.map);
    } else {
      this._heatmapLayer.remove();
    }
  }

  // ── destroy ───────────────────────────────────────────────────────────────

  /**
   * Cancela listeners y limpia recursos.
   */
  destroy() {
    if (this._unsubscribe) {
      this._unsubscribe();
      this._unsubscribe = null;
    }
    if (this.map) {
      this.map.remove();
      this.map = null;
    }
    this._marcadores.clear();
    this._reportesCache = [];
  }
}

export default MapaModule;
