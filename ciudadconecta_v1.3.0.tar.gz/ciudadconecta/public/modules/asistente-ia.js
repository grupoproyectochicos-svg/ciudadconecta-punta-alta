/**
 * asistente-ia.js — Asistente Virtual flotante 🤖
 * CiudadConecta Punta Alta v1.0
 * Chat inteligente con respuestas contextuales sobre la app
 */

const RESPUESTAS = {
  saludos: {
    keywords: ['hola', 'buenas', 'hey', 'buenos días', 'buenas tardes', 'buenas noches'],
    respuesta: '¡Hola! Soy el asistente de CiudadConecta 🤖 ¿En qué te puedo ayudar hoy?'
  },
  reporte: {
    keywords: ['reporte', 'reportar', 'bache', 'desagüe', 'desague', 'foto', 'cámara', 'camara', 'cómo reporto', 'como reporto'],
    respuesta: '📸 Para reportar un incidente:\n\n1. Tocá el botón <b>📸 REPORTAR</b> en el mapa\n2. Apuntá la cámara al bache o desagüe\n3. Capturá la foto (la galería está bloqueada para garantizar autenticidad)\n4. ¡Listo! La IA clasifica el incidente y lo agrega al mapa\n\n¿Tenés alguna duda más?'
  },
  cupones: {
    keywords: ['cupón', 'cupon', 'cupones', 'descuento', 'qr', 'canje', 'comercio', 'vence', 'vencimiento'],
    respuesta: '🎟️ <b>Cupones de descuento:</b>\n\nPor tener la app activa recibís cupones de <b>25% OFF</b> todos los meses en comercios adheridos de Punta Alta.\n\n📅 Vencen el último día del mes\n🔒 Son personales e intransferibles\n📲 Para canjear: mostrá el QR al comercio\n\nEncontrás tus cupones en la sección 🎟️ del menú inferior.'
  },
  empleo: {
    keywords: ['empleo', 'trabajo', 'laburo', 'oferta', 'postular', 'postulación', 'comerciante', 'publicar'],
    respuesta: '💼 <b>Empleo Local:</b>\n\nPodés ver ofertas de trabajo de comercios de Punta Alta. Filtrá por turno o tipo de contrato.\n\n¿Sos comerciante? Tocá "Soy comerciante 🏪" y grabá un audio de 30s a 3 minutos describiendo la búsqueda. La IA convierte tu voz en un aviso profesional.\n\nSección 💼 del menú inferior.'
  },
  transporte: {
    keywords: ['transporte', 'colectivo', 'ómnibus', 'omnibus', 'línea', 'linea', 'horario', 'demora', 'llega', 'cuándo llega'],
    respuesta: '🚌 <b>Transporte Público:</b>\n\nEl predictor de transporte usa los baches reportados para estimar demoras en las líneas de colectivos.\n\n📍 3 líneas disponibles: Centro↔Base Naval, Circular Norte, Sur↔Estación\n⏱️ Muestra el próximo horario y demoras estimadas\n\nSección 🚌 del menú inferior.'
  },
  mapa: {
    keywords: ['mapa', 'incidente', 'baches activos', 'ver', 'dónde', 'donde', 'zona'],
    respuesta: '🗺️ <b>Mapa de incidentes:</b>\n\nEl mapa muestra en tiempo real todos los baches 🔴, desagüe 🟡 y puntos de reciclaje 🟢 de Punta Alta.\n\nCuantos más vecinos reportan el mismo punto, más grande aparece el marcador. El municipio actualiza los estados dentro de las 72 horas.'
  },
  privacidad: {
    keywords: ['dni', 'datos', 'privacidad', 'anónimo', 'anonimo', 'guardan', 'seguro', 'ley', 'información'],
    respuesta: '🔒 <b>Tu privacidad es prioridad:</b>\n\n✅ Tu DNI se convierte en un código único (hash SHA-256) — nunca guardamos el número real\n✅ Los reportes se envían de forma 100% anónima\n✅ La ubicación solo se usa durante el reporte\n✅ Cumplimos la Ley 25.326 de Protección de Datos Personales'
  },
  municipio: {
    keywords: ['municipio', 'panel', 'gestión', 'gobierno', 'estado', 'resolución', 'obra', 'cuándo arreglan'],
    respuesta: '🏛️ <b>Panel Municipal:</b>\n\nEl municipio tiene acceso a un dashboard con todos los reportes, mapa calórico y sistema de gestión.\n\nDeben actualizar el estado de cada reporte en un máximo de <b>72 horas</b>. Podés seguir el avance en "Mis Reportes 📋".'
  },
  reputacion: {
    keywords: ['reputación', 'reputacion', 'puntos', 'nivel', 'embajador', 'confiable', 'activo', 'nuevo'],
    respuesta: '⭐ <b>Sistema de reputación:</b>\n\nCada reporte válido suma puntos:\n🌱 Nuevo: 0-10 pts\n🌟 Activo: 11-30 pts\n⭐ Confiable: 31-60 pts\n🏆 Embajador: 61+ pts\n\n¡Los embajadores reciben cupones adicionales por su contribución!'
  },
  gracias: {
    keywords: ['gracias', 'gracia', 'perfecto', 'genial', 'buenísimo', 'ok', 'entendí', 'listo'],
    respuesta: '¡De nada! 😊 Cualquier otra duda, acá estoy. ¡Gracias por usar CiudadConecta y ayudar a mejorar Punta Alta! 🏙️'
  }
};

const SUGERENCIAS = [
  '¿Cómo reporto un bache?',
  '¿Cuándo vencen mis cupones?',
  '¿Cómo funciona el empleo?',
  '¿Mis datos son privados?',
];

export class AsistenteIA {
  constructor() {
    this._abierto  = false;
    this._mensajes = [];
    this._el       = null;
  }

  init() {
    this._inyectarHTML();
    this._bindEvents();
    // Saludo inicial al abrir por primera vez
    this._mensajes = [];
  }

  // ─── HTML base ────────────────────────────────────────────────────
  _inyectarHTML() {
    // Botón flotante
    const fab = document.createElement('div');
    fab.id = 'asistente-fab';
    fab.className = 'fixed bottom-24 left-4 z-50';
    fab.innerHTML = `
      <button id="asistente-toggle"
        class="w-14 h-14 bg-secondary text-white rounded-full shadow-xl flex items-center justify-center text-2xl
               hover:scale-110 active:scale-95 transition-transform">
        🤖
      </button>
      <div id="asistente-badge" class="hidden absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full
        flex items-center justify-center text-white text-xs font-bold">1</div>
    `;
    document.body.appendChild(fab);

    // Panel de chat
    const panel = document.createElement('div');
    panel.id = 'asistente-panel';
    panel.className = 'fixed bottom-24 left-4 z-50 hidden';
    panel.style.cssText = 'width: min(340px, calc(100vw - 2rem));';
    panel.innerHTML = `
      <div class="bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden" style="height:460px; max-height:60vh">
        <!-- Header -->
        <div class="bg-secondary text-white px-4 py-3 flex items-center gap-3">
          <span class="text-2xl">🤖</span>
          <div class="flex-1">
            <div class="font-semibold text-sm">Asistente CiudadConecta</div>
            <div class="text-xs opacity-75 flex items-center gap-1">
              <span class="w-2 h-2 bg-green-300 rounded-full inline-block"></span> En línea
            </div>
          </div>
          <button id="asistente-cerrar" class="text-white/80 hover:text-white text-xl leading-none">✕</button>
        </div>

        <!-- Mensajes -->
        <div id="asistente-mensajes" class="flex-1 overflow-y-auto p-3 space-y-2 bg-gray-50">
          <!-- se llenan dinámicamente -->
        </div>

        <!-- Sugerencias -->
        <div id="asistente-sugerencias" class="px-3 py-2 flex gap-2 overflow-x-auto bg-gray-50 border-t">
          ${SUGERENCIAS.map(s => `
            <button onclick="window.asistente?.enviarMensaje('${s}')"
              class="flex-shrink-0 text-xs bg-white border border-gray-200 text-gray-600
                     px-2.5 py-1.5 rounded-full hover:border-secondary hover:text-secondary transition-colors">
              ${s}
            </button>
          `).join('')}
        </div>

        <!-- Input -->
        <div class="px-3 py-2 bg-white border-t flex gap-2">
          <input id="asistente-input" type="text" placeholder="Escribí tu pregunta..."
            class="flex-1 text-sm border border-gray-200 rounded-xl px-3 py-2 outline-none
                   focus:border-secondary focus:ring-2 focus:ring-green-100"
            autocomplete="off" />
          <button id="asistente-enviar"
            class="w-9 h-9 bg-secondary text-white rounded-xl flex items-center justify-center
                   hover:bg-green-700 active:scale-95 transition-all flex-shrink-0">
            ➤
          </button>
        </div>
      </div>
    `;
    document.body.appendChild(panel);
    this._el = panel;
  }

  // ─── Eventos ──────────────────────────────────────────────────────
  _bindEvents() {
    document.getElementById('asistente-toggle')?.addEventListener('click', () => this.toggle());
    document.getElementById('asistente-cerrar')?.addEventListener('click', () => this.cerrar());

    const input  = document.getElementById('asistente-input');
    const btnEnv = document.getElementById('asistente-enviar');

    input?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        this.enviarMensaje(input.value.trim());
        input.value = '';
      }
    });
    btnEnv?.addEventListener('click', () => {
      const txt = input?.value.trim();
      if (txt) { this.enviarMensaje(txt); input.value = ''; }
    });
  }

  // ─── Toggle / Cerrar ──────────────────────────────────────────────
  toggle() {
    this._abierto ? this.cerrar() : this.abrir();
  }

  abrir() {
    this._abierto = true;
    this._el.classList.remove('hidden');
    document.getElementById('asistente-fab')?.querySelector('button')?.classList.add('bg-gray-600');
    document.getElementById('asistente-badge')?.classList.add('hidden');

    if (this._mensajes.length === 0) {
      // Mensaje de bienvenida
      this._agregarMensajeBot(
        '¡Hola! Soy el asistente de CiudadConecta 🤖\n\nPuedo ayudarte con reportes, cupones, empleo, transporte y más.\n\n¿Sobre qué querés saber?'
      );
    }

    setTimeout(() => document.getElementById('asistente-input')?.focus(), 100);
  }

  cerrar() {
    this._abierto = false;
    this._el.classList.add('hidden');
    document.getElementById('asistente-fab')?.querySelector('button')?.classList.remove('bg-gray-600');
  }

  // ─── Chat ─────────────────────────────────────────────────────────
  enviarMensaje(texto) {
    if (!texto || texto.length < 1) return;
    if (!this._abierto) this.abrir();

    // Mensaje del usuario
    this._agregarMensajeUsuario(texto);
    this._mensajes.push({ rol: 'usuario', texto });

    // Ocultar sugerencias después de la primera interacción
    document.getElementById('asistente-sugerencias')?.classList.add('hidden');

    // Typing indicator
    this._mostrarTyping();

    setTimeout(() => {
      this._ocultarTyping();
      const respuesta = this._generarRespuesta(texto);
      this._agregarMensajeBot(respuesta);
      this._mensajes.push({ rol: 'bot', texto: respuesta });
    }, 1200 + Math.random() * 600);
  }

  _generarRespuesta(texto) {
    const lower = texto.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

    for (const [, config] of Object.entries(RESPUESTAS)) {
      if (config.keywords.some(kw => lower.includes(kw.normalize('NFD').replace(/[\u0300-\u036f]/g, '')))) {
        return config.respuesta;
      }
    }

    // Respuesta genérica
    const genericas = [
      '🤔 No estoy seguro de cómo ayudarte con eso. Podés preguntarme sobre <b>reportes, cupones, empleo, transporte o privacidad</b>.',
      '📲 Para más información, explorá las secciones del menú inferior de la app.',
      '🏙️ Recordá que CiudadConecta es una herramienta para mejorar Punta Alta entre todos. ¡Cualquier duda, estoy acá!',
    ];
    return genericas[Math.floor(Math.random() * genericas.length)];
  }

  // ─── Render mensajes ──────────────────────────────────────────────
  _agregarMensajeUsuario(texto) {
    const cont = document.getElementById('asistente-mensajes');
    if (!cont) return;
    const div = document.createElement('div');
    div.className = 'flex justify-end';
    div.innerHTML = `
      <div class="bg-primary text-white text-sm rounded-2xl rounded-br-sm px-3 py-2 max-w-[80%]">
        ${this._escHtml(texto)}
      </div>
    `;
    cont.appendChild(div);
    cont.scrollTop = cont.scrollHeight;
  }

  _agregarMensajeBot(texto) {
    const cont = document.getElementById('asistente-mensajes');
    if (!cont) return;
    const div = document.createElement('div');
    div.className = 'flex gap-2 items-end';
    div.innerHTML = `
      <div class="w-7 h-7 bg-secondary rounded-full flex items-center justify-center text-sm flex-shrink-0">🤖</div>
      <div class="bg-white border border-gray-100 text-gray-800 text-sm rounded-2xl rounded-bl-sm px-3 py-2 max-w-[82%] shadow-sm">
        ${texto.replace(/\n/g, '<br>')}
      </div>
    `;
    cont.appendChild(div);
    cont.scrollTop = cont.scrollHeight;
  }

  _mostrarTyping() {
    const cont = document.getElementById('asistente-mensajes');
    if (!cont) return;
    const div = document.createElement('div');
    div.id = 'typing-indicator';
    div.className = 'flex gap-2 items-end';
    div.innerHTML = `
      <div class="w-7 h-7 bg-secondary rounded-full flex items-center justify-center text-sm">🤖</div>
      <div class="bg-white border border-gray-100 rounded-2xl rounded-bl-sm px-4 py-3 shadow-sm">
        <div class="flex gap-1">
          <span class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay:0ms"></span>
          <span class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay:150ms"></span>
          <span class="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style="animation-delay:300ms"></span>
        </div>
      </div>
    `;
    cont.appendChild(div);
    cont.scrollTop = cont.scrollHeight;
  }

  _ocultarTyping() {
    document.getElementById('typing-indicator')?.remove();
  }

  _escHtml(str) {
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }
}

// Singleton global
const asistente = new AsistenteIA();
window.asistente = asistente;

export default asistente;
