/**
 * reputacion.js — Módulo de Reputación Ciudadana para CiudadConecta Punta Alta
 * RN-20 a RN-24: sistema de puntos, niveles, fraude y suspensión.
 * Stack: Vanilla JS ES modules + Firebase Firestore v10 CDN
 */

import {
  getFirestore,
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  addDoc,
  query,
  where,
  orderBy,
  limit,
  increment,
  serverTimestamp,
  Timestamp
} from '../firebase-init.js';

// ──────────────────────────────────────────────
// Constantes de negocio
// ──────────────────────────────────────────────

/** RN-23: Rangos de nivel por puntos */
const NIVELES = [
  { id: 'nuevo',     min: 0,  max: 10,  emoji: '🌱', color: '#78909c', label: 'Nuevo',     bg: '#eceff1' },
  { id: 'activo',    min: 11, max: 30,  emoji: '⚡', color: '#1565c0', label: 'Activo',    bg: '#e3f2fd' },
  { id: 'confiable', min: 31, max: 60,  emoji: '🛡️', color: '#6a1b9a', label: 'Confiable', bg: '#f3e5f5' },
  { id: 'embajador', min: 61, max: Infinity, emoji: '🏆', color: '#e65100', label: 'Embajador', bg: '#fff3e0' },
];

/** RN-20/21: Puntos por motivo */
const PUNTOS_MOTIVO = {
  reporte_valido:    { delta: +5, label: 'Reporte validado',       icono: '✅' },
  reporte_rechazado: { delta: -3, label: 'Reporte rechazado',      icono: '❌' },
  primer_reporte:    { delta: +2, label: 'Primer reporte del día', icono: '🌟' },
  racha_semanal:     { delta: +3, label: 'Racha semanal',          icono: '🔥' },
};

/** RN-22: umbrales de fraude y suspensión */
const FRAUDES_LIMITE = 3;
const SUSPENSION_MS  = 30 * 24 * 60 * 60 * 1000; // 30 días en ms

// ──────────────────────────────────────────────
// ReputacionModule
// ──────────────────────────────────────────────

export class ReputacionModule {
  /**
   * @param {object} app - instancia Firebase App
   * @param {string} contenedorId - id del elemento DOM raíz donde renderizar
   */
  constructor(app, contenedorId = 'app-root') {
    this.db = getFirestore(app);
    this.contenedorId = contenedorId;
    this.userId = null;
    this.userData = null;
    this.historial = [];
  }

  // ─── init ────────────────────────────────────

  /**
   * Inicializa el módulo para un usuario dado.
   * Si no existe en Firestore → crea el documento con valores iniciales.
   * @param {string} userId
   */
  async init(userId) {
    this.userId = userId;
    try {
      this._mostrarSkeleton();
      await this._cargarOCrearUsuario();
      await this._cargarHistorial();
      this.renderizarPerfil();
    } catch (err) {
      console.error('[ReputacionModule] Error en init():', err);
      this._mostrarError('No se pudo cargar el perfil de reputación.');
    }
  }

  // ─── _cargarOCrearUsuario ────────────────────

  async _cargarOCrearUsuario() {
    const ref = doc(this.db, 'usuarios', this.userId);
    const snap = await getDoc(ref);

    if (!snap.exists()) {
      // Crear con valores iniciales
      const inicial = {
        id: this.userId,
        nivel: 'nuevo',
        puntos: 0,
        reportes_validos: 0,
        reportes_rechazados: 0,
        fraudes_consecutivos: 0,
        suspendido_hasta: null,
        fecha_registro: serverTimestamp(),
        ultimo_acceso: serverTimestamp(),
      };
      await setDoc(ref, inicial);
      this.userData = inicial;
    } else {
      this.userData = snap.data();
      // Actualizar último acceso
      await updateDoc(ref, { ultimo_acceso: serverTimestamp() });
    }
  }

  // ─── _cargarHistorial ────────────────────────

  async _cargarHistorial() {
    try {
      const q = query(
        collection(this.db, 'historial_puntos'),
        where('userId', '==', this.userId),
        orderBy('fecha', 'desc'),
        limit(10)
      );
      const snap = await getDocs(q);
      this.historial = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    } catch {
      this.historial = [];
    }
  }

  // ─── calcularNivel ───────────────────────────

  /**
   * Calcula el nivel de reputación a partir de los puntos.
   * RN-23.
   * @param {number} puntos
   * @returns {{ nivel:string, color:string, emoji:string, label:string, bg:string,
   *             puntosParaSiguiente:number|null, progreso_pct:number }}
   */
  calcularNivel(puntos) {
    const pts = Math.max(0, puntos);
    const actual = NIVELES.findLast(n => pts >= n.min) ?? NIVELES[0];
    const idxActual = NIVELES.indexOf(actual);
    const siguiente = NIVELES[idxActual + 1] ?? null;

    let progreso_pct = 100;
    let puntosParaSiguiente = null;

    if (siguiente) {
      const rango = siguiente.min - actual.min;
      const avance = pts - actual.min;
      progreso_pct = Math.min(100, Math.round((avance / rango) * 100));
      puntosParaSiguiente = siguiente.min - pts;
    }

    return { ...actual, puntosParaSiguiente, progreso_pct };
  }

  // ─── sumarPuntos ─────────────────────────────

  /**
   * Suma o resta puntos al usuario y actualiza Firestore atómicamente.
   * Si sube de nivel → muestra animación de celebración.
   * RN-20/21.
   * @param {string} userId
   * @param {'reporte_valido'|'reporte_rechazado'|'primer_reporte'|'racha_semanal'} motivo
   * @param {number} [cantidadOverride] - sobreescribe la cantidad por defecto del motivo
   */
  async sumarPuntos(userId, motivo, cantidadOverride = null) {
    const config = PUNTOS_MOTIVO[motivo];
    if (!config) {
      console.warn(`[ReputacionModule] Motivo desconocido: ${motivo}`);
      return;
    }
    const delta = cantidadOverride ?? config.delta;

    try {
      const ref = doc(this.db, 'usuarios', userId);
      const nivelAntes = this.calcularNivel(this.userData?.puntos ?? 0).id;

      // Actualización atómica con increment (RN-20/21)
      const updates = { puntos: increment(delta) };

      if (motivo === 'reporte_valido') {
        updates.reportes_validos = increment(1);
        updates.fraudes_consecutivos = 0; // resetear racha de fraudes
      } else if (motivo === 'reporte_rechazado') {
        updates.reportes_rechazados = increment(1);
        updates.fraudes_consecutivos = increment(1);
      }

      await updateDoc(ref, updates);

      // Registrar en historial
      await addDoc(collection(this.db, 'historial_puntos'), {
        userId,
        motivo,
        delta,
        label: config.label,
        icono: config.icono,
        fecha: serverTimestamp(),
      });

      // Actualizar estado local
      this.userData = {
        ...this.userData,
        puntos: (this.userData?.puntos ?? 0) + delta,
        reportes_validos: motivo === 'reporte_valido'
          ? (this.userData?.reportes_validos ?? 0) + 1
          : (this.userData?.reportes_validos ?? 0),
        reportes_rechazados: motivo === 'reporte_rechazado'
          ? (this.userData?.reportes_rechazados ?? 0) + 1
          : (this.userData?.reportes_rechazados ?? 0),
      };

      // Verificar subida de nivel
      const nivelDespues = this.calcularNivel(this.userData.puntos).id;
      if (nivelDespues !== nivelAntes && NIVELES.findIndex(n => n.id === nivelDespues) > NIVELES.findIndex(n => n.id === nivelAntes)) {
        await updateDoc(ref, { nivel: nivelDespues });
        this.userData.nivel = nivelDespues;
        this.mostrarInsignia(nivelDespues);
      }

      // Verificar fraude tras reporte rechazado
      if (motivo === 'reporte_rechazado') {
        await this.verificarFraude(userId);
      }

      console.log(`[ReputacionModule] ${delta > 0 ? '+' : ''}${delta} pts por "${motivo}" (total: ${this.userData.puntos})`);
    } catch (err) {
      console.error('[ReputacionModule] Error al sumar puntos:', err);
      throw err;
    }
  }

  // ─── verificarFraude ─────────────────────────

  /**
   * Verifica si el usuario supera el umbral de fraudes consecutivos.
   * RN-22: 3 fraudes → suspensión 30 días.
   * @param {string} userId
   */
  async verificarFraude(userId) {
    try {
      const ref = doc(this.db, 'usuarios', userId);
      const snap = await getDoc(ref);
      if (!snap.exists()) return;

      const data = snap.data();
      const fraudes = data.fraudes_consecutivos ?? 0;

      if (fraudes >= FRAUDES_LIMITE) {
        const suspendido_hasta = Date.now() + SUSPENSION_MS;
        await updateDoc(ref, {
          suspendido_hasta,
          fraudes_consecutivos: 0, // resetear tras aplicar suspensión
          activo: false,
        });
        this.userData = { ...this.userData, suspendido_hasta, activo: false };

        // Notificar al usuario
        this._mostrarSuspension(suspendido_hasta);
        console.warn(`[ReputacionModule] Usuario ${userId} suspendido hasta ${new Date(suspendido_hasta).toLocaleDateString()}`);
      }
    } catch (err) {
      console.error('[ReputacionModule] Error al verificar fraude:', err);
    }
  }

  // ─── renderizarPerfil ────────────────────────

  /**
   * Renderiza la pantalla completa del perfil de reputación.
   */
  renderizarPerfil() {
    const contenedor = document.getElementById(this.contenedorId);
    if (!contenedor) return;

    const puntos = this.userData?.puntos ?? 0;
    const nivelInfo = this.calcularNivel(puntos);
    const suspendido = this._estaSuspendido();
    const rvValidos = this.userData?.reportes_validos ?? 0;
    const rvRechazados = this.userData?.reportes_rechazados ?? 0;
    const cuponesUsados = 0; // se puede conectar con CuponesModule si se pasa referencia

    contenedor.innerHTML = `
      <div class="reputacion-screen" style="${estilosBaseRep}">

        <!-- ── Header ── -->
        <div style="
          background: linear-gradient(135deg, ${nivelInfo.color} 0%, ${this._darken(nivelInfo.color)} 100%);
          padding: 24px 16px 20px; color:white; border-radius:0 0 28px 28px;
          box-shadow: 0 4px 20px ${nivelInfo.color}55; text-align:center;
        ">
          <!-- Avatar / Emoji nivel -->
          <div style="
            width:80px; height:80px; border-radius:50%; background:rgba(255,255,255,0.2);
            display:flex; align-items:center; justify-content:center;
            font-size:44px; margin:0 auto 12px;
            border:3px solid rgba(255,255,255,0.4);
          ">${nivelInfo.emoji}</div>

          <!-- Nivel badge -->
          <div style="
            display:inline-flex; align-items:center; gap:8px;
            background:rgba(255,255,255,0.2); border-radius:20px;
            padding:6px 18px; font-weight:700; font-size:18px;
          ">
            ${nivelInfo.emoji} ${nivelInfo.label}
          </div>

          ${suspendido ? `
            <div style="
              margin-top:10px; background:rgba(198,40,40,0.85);
              border-radius:10px; padding:8px 16px; font-size:13px; font-weight:600;
            ">🚫 Cuenta suspendida hasta ${this._fechaSuspension()}</div>
          ` : ''}

          <!-- Puntos grandes -->
          <div style="font-size:52px; font-weight:900; margin-top:8px; letter-spacing:-2px;">
            ${puntos} <span style="font-size:22px; opacity:0.8;">pts</span>
          </div>

          <!-- Barra de progreso hacia siguiente nivel -->
          ${nivelInfo.puntosParaSiguiente !== null ? `
            <div style="margin-top:12px; padding:0 16px;">
              <div style="background:rgba(255,255,255,0.2); border-radius:8px; height:10px; overflow:hidden;">
                <div style="
                  height:100%; width:${nivelInfo.progreso_pct}%;
                  background:rgba(255,255,255,0.85);
                  border-radius:8px; transition:width 0.8s ease;
                "></div>
              </div>
              <div style="font-size:12px; opacity:0.8; margin-top:6px;">
                ${nivelInfo.puntosParaSiguiente} pts para el siguiente nivel
              </div>
            </div>
          ` : `
            <div style="margin-top:8px; font-size:13px; opacity:0.8;">🏆 ¡Nivel máximo alcanzado!</div>
          `}
        </div>

        <!-- ── Estadísticas ── -->
        <div style="padding:20px 16px 0;">
          <h3 style="margin:0 0 12px; font-size:15px; color:#333; font-weight:700;">📊 Tus estadísticas</h3>
          <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:10px;">
            ${this._statCard('✅', rvValidos, 'Reportes válidos', '#2e7d32', '#e8f5e9')}
            ${this._statCard('❌', rvRechazados, 'Rechazados', '#c62828', '#ffebee')}
            ${this._statCard('🎟️', cuponesUsados, 'Cupones usados', '#1565c0', '#e3f2fd')}
          </div>
        </div>

        <!-- ── Historial de actividad ── -->
        <div style="padding:20px 16px;">
          <h3 style="margin:0 0 12px; font-size:15px; color:#333; font-weight:700;">📋 Actividad reciente</h3>
          ${this.historial.length === 0
            ? `<div style="text-align:center; padding:24px; color:#aaa; font-size:14px;">
                Sin actividad registrada aún.<br>¡Hacé tu primer reporte! 🚀
              </div>`
            : `<div style="display:flex; flex-direction:column; gap:8px;">
                ${this.historial.map(h => this._itemHistorial(h)).join('')}
              </div>`
          }
        </div>

        <!-- ── Guía de niveles ── -->
        <div style="padding:0 16px 32px;">
          <h3 style="margin:0 0 12px; font-size:15px; color:#333; font-weight:700;">🗺️ Guía de niveles</h3>
          <div style="display:flex; flex-direction:column; gap:8px;">
            ${NIVELES.map(n => this._filaNivel(n, puntos)).join('')}
          </div>
        </div>

      </div>
    `;
  }

  // ─── mostrarInsignia ─────────────────────────

  /**
   * Muestra animación de insignia desbloqueada al subir de nivel.
   * @param {string} nivelId
   */
  mostrarInsignia(nivelId) {
    const info = NIVELES.find(n => n.id === nivelId) ?? NIVELES[0];

    // Overlay de celebración
    const overlay = document.createElement('div');
    overlay.style.cssText = `
      position:fixed; inset:0; z-index:9998;
      background:rgba(0,0,0,0.75); display:flex; align-items:center; justify-content:center;
      flex-direction:column; animation:insigniaFadeIn 0.4s ease;
    `;

    overlay.innerHTML = `
      <style>
        @keyframes insigniaFadeIn { from{opacity:0} to{opacity:1} }
        @keyframes insigniaBounce {
          0%{transform:scale(0) rotate(-20deg)}
          60%{transform:scale(1.15) rotate(5deg)}
          80%{transform:scale(0.95) rotate(-3deg)}
          100%{transform:scale(1) rotate(0deg)}
        }
        @keyframes confetti {
          0%{transform:translateY(-20px) rotate(0deg); opacity:1}
          100%{transform:translateY(80px) rotate(360deg); opacity:0}
        }
      </style>

      <!-- Confetti sencillo (4 partículas CSS) -->
      ${['🎊','🎉','✨','🎈'].map((s, i) => `
        <div style="
          position:fixed; top:20%; left:${15 + i * 22}%;
          font-size:32px; animation:confetti ${1 + i * 0.2}s ease ${i * 0.15}s forwards;
          pointer-events:none;
        ">${s}</div>
      `).join('')}

      <!-- Card de insignia -->
      <div style="
        background:white; border-radius:24px; padding:36px 40px; text-align:center;
        max-width:320px; animation:insigniaBounce 0.6s cubic-bezier(0.36,0.07,0.19,0.97) 0.1s both;
      ">
        <div style="font-size:72px; margin-bottom:8px;">${info.emoji}</div>
        <div style="font-size:13px; color:#888; font-weight:600; letter-spacing:1px; text-transform:uppercase; margin-bottom:4px;">
          ¡Nuevo nivel!
        </div>
        <div style="font-size:28px; font-weight:900; color:${info.color};">
          ${info.label}
        </div>
        <div style="margin-top:12px; font-size:14px; color:#555; line-height:1.5;">
          ${this._mensajeNivel(nivelId)}
        </div>
        <button id="btn-cerrar-insignia" style="
          margin-top:20px; padding:12px 36px; background:${info.color}; color:white;
          border:none; border-radius:50px; font-size:15px; font-weight:700; cursor:pointer;
          width:100%;
        ">¡Genial! 🎉</button>
      </div>
    `;

    document.body.appendChild(overlay);

    // Toast adicional
    this._mostrarToast(`¡Subiste a ${info.label}! 🏆`, info.color);

    // Cerrar
    const cerrar = () => {
      overlay.style.animation = 'insigniaFadeIn 0.2s ease reverse';
      setTimeout(() => overlay.remove(), 250);
    };
    document.getElementById('btn-cerrar-insignia')?.addEventListener('click', cerrar);
    setTimeout(cerrar, 6000); // auto-cierre tras 6s
  }

  // ─── Helpers de UI ───────────────────────────

  _statCard(icono, valor, label, color, bg) {
    return `
      <div style="
        background:${bg}; border-radius:14px; padding:14px 10px;
        text-align:center; border:1px solid ${color}22;
      ">
        <div style="font-size:24px;">${icono}</div>
        <div style="font-size:22px; font-weight:800; color:${color}; margin-top:4px;">${valor}</div>
        <div style="font-size:11px; color:#666; margin-top:2px; line-height:1.3;">${label}</div>
      </div>
    `;
  }

  _itemHistorial(item) {
    const fecha = item.fecha?.toDate?.() ?? new Date(item.fecha ?? Date.now());
    const positivo = item.delta > 0;
    return `
      <div style="
        display:flex; align-items:center; gap:12px;
        background:white; border-radius:12px; padding:10px 14px;
        box-shadow:0 1px 6px rgba(0,0,0,0.07);
      ">
        <span style="font-size:22px;">${item.icono ?? (positivo ? '✅' : '❌')}</span>
        <div style="flex:1; min-width:0;">
          <div style="font-size:13px; font-weight:600; color:#333; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
            ${item.label ?? item.motivo}
          </div>
          <div style="font-size:11px; color:#aaa; margin-top:2px;">${this._fechaRelativa(fecha)}</div>
        </div>
        <div style="
          font-size:15px; font-weight:800;
          color:${positivo ? '#2e7d32' : '#c62828'};
          white-space:nowrap;
        ">
          ${positivo ? '+' : ''}${item.delta} pts
        </div>
      </div>
    `;
  }

  _filaNivel(nivelDef, puntosActuales) {
    const esActual = puntosActuales >= nivelDef.min &&
      (nivelDef.max === Infinity || puntosActuales <= nivelDef.max);
    const alcanzado = puntosActuales >= nivelDef.min;
    const rangoLabel = nivelDef.max === Infinity ? `${nivelDef.min}+ pts` : `${nivelDef.min}–${nivelDef.max} pts`;

    return `
      <div style="
        display:flex; align-items:center; gap:12px;
        background:${esActual ? nivelDef.bg : 'white'};
        border-radius:12px; padding:10px 14px;
        border:2px solid ${esActual ? nivelDef.color : 'transparent'};
        box-shadow: 0 1px 6px rgba(0,0,0,${esActual ? '0.12' : '0.05'});
        opacity:${alcanzado ? 1 : 0.55};
      ">
        <span style="font-size:28px;">${nivelDef.emoji}</span>
        <div style="flex:1;">
          <div style="font-size:14px; font-weight:700; color:${nivelDef.color};">${nivelDef.label}</div>
          <div style="font-size:12px; color:#888;">${rangoLabel}</div>
        </div>
        ${esActual ? `<span style="
          background:${nivelDef.color}; color:white; font-size:10px; font-weight:700;
          padding:3px 8px; border-radius:10px;
        ">ACTUAL</span>` : alcanzado ? `<span style="font-size:18px;">✓</span>` : ''}
      </div>
    `;
  }

  _estaSuspendido() {
    return this.userData?.suspendido_hasta && Date.now() < this.userData.suspendido_hasta;
  }

  _fechaSuspension() {
    if (!this.userData?.suspendido_hasta) return '';
    return new Date(this.userData.suspendido_hasta).toLocaleDateString('es-AR', {
      day: '2-digit', month: 'long', year: 'numeric'
    });
  }

  _mostrarSuspension(suspendido_hasta) {
    const fecha = new Date(suspendido_hasta).toLocaleDateString('es-AR', {
      day: '2-digit', month: 'long', year: 'numeric'
    });
    this._mostrarToast(`🚫 Cuenta suspendida hasta ${fecha}`, '#c62828', 6000);
  }

  _mostrarToast(msg, color = '#1a237e', duracion = 3000) {
    const toast = document.createElement('div');
    toast.style.cssText = `
      position:fixed; bottom:32px; left:50%; transform:translateX(-50%);
      background:${color}; color:white;
      padding:14px 24px; border-radius:50px; font-size:14px; font-weight:700;
      box-shadow:0 8px 24px ${color}55; z-index:10001;
      max-width:90vw; text-align:center; white-space:nowrap;
      animation:toastSlide 0.35s ease;
    `;
    toast.textContent = msg;
    const s = document.createElement('style');
    s.textContent = `@keyframes toastSlide{from{opacity:0;transform:translateX(-50%) translateY(16px)}to{opacity:1;transform:translateX(-50%) translateY(0)}}`;
    document.head.appendChild(s);
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.3s';
      setTimeout(() => toast.remove(), 350);
    }, duracion);
  }

  _mostrarSkeleton() {
    const contenedor = document.getElementById(this.contenedorId);
    if (!contenedor) return;
    contenedor.innerHTML = `
      <div style="padding:20px; ${estilosBaseRep}">
        <div style="height:260px; background:#e8eaf6; border-radius:28px; animation:repSkel 1.4s infinite;"></div>
        <div style="margin-top:16px; height:100px; background:#e8eaf6; border-radius:16px; animation:repSkel 1.4s infinite 0.2s;"></div>
        <style>@keyframes repSkel{0%,100%{opacity:1}50%{opacity:0.4}}</style>
      </div>
    `;
  }

  _mostrarError(msg) {
    const contenedor = document.getElementById(this.contenedorId);
    if (!contenedor) return;
    contenedor.innerHTML = `
      <div style="padding:40px 20px; text-align:center; ${estilosBaseRep}">
        <div style="font-size:48px;">😕</div>
        <div style="margin-top:12px; color:#c62828; font-weight:600;">${msg}</div>
      </div>
    `;
  }

  _mensajeNivel(nivelId) {
    const mensajes = {
      activo:    'Ya sos parte activa de la comunidad. ¡Seguí reportando!',
      confiable: 'La comunidad confía en vos. Tus reportes tienen más peso.',
      embajador: '¡Sos un referente de Punta Alta! Accedés a cupones exclusivos 🎟️',
    };
    return mensajes[nivelId] ?? '¡Seguí participando!';
  }

  _fechaRelativa(fecha) {
    const diff = Date.now() - fecha.getTime();
    const mins = Math.floor(diff / 60000);
    const hrs = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    if (mins < 1) return 'Ahora';
    if (mins < 60) return `Hace ${mins} min`;
    if (hrs < 24) return `Hace ${hrs}h`;
    if (days < 7) return `Hace ${days} día${days > 1 ? 's' : ''}`;
    return fecha.toLocaleDateString('es-AR');
  }

  _darken(hex) {
    // Oscurece levemente un color hex para gradiente
    try {
      const n = parseInt(hex.slice(1), 16);
      const r = Math.max(0, ((n >> 16) & 0xff) - 30);
      const g = Math.max(0, ((n >> 8) & 0xff) - 30);
      const b = Math.max(0, (n & 0xff) - 30);
      return `rgb(${r},${g},${b})`;
    } catch { return hex; }
  }
}

const estilosBaseRep = `
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  max-width:600px; margin:0 auto; min-height:100vh; background:#f3f4f9;
`;

export default ReputacionModule;
