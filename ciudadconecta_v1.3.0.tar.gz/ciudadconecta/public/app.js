/**
 * app.js — Bootstrap y Router principal de CiudadConecta Punta Alta
 * ==================================================================
 * Módulo ES6: importa Firebase, inicializa la app, maneja routing
 * y expone helpers globales (showToast, showLoading).
 *
 * Stack: Vanilla JS + Firebase v10 + Leaflet
 * Versión: 1.0.0
 */

import { initializeApp }       from 'firebase/app';
import { getFirestore, collection, addDoc, getDocs, query, where, orderBy, serverTimestamp }
                                from 'firebase/firestore';
import { getAuth, signInAnonymously, onAuthStateChanged }
                                from 'firebase/auth';
import { getStorage }          from 'firebase/storage';

// ── Módulos de la app ──────────────────────────────────────────
import { MapaModule }           from './modules/mapa.js';
import { ReportarModule }       from './modules/reportar.js';
import { MisReportesModule }    from './modules/mis-reportes.js';
import { CuponesModule }        from './modules/cupones.js';
import { ReputacionModule }     from './modules/reputacion.js';
import { ComerciosModule }      from './modules/comercios.js';
import { EmpleoModule }         from './modules/empleo.js';
import { TransporteModule }     from './modules/transporte.js';
import asistente                from './modules/asistente-ia.js';

// ─────────────────────────────────────────────────────────────
//  FIREBASE CONFIG
// ─────────────────────────────────────────────────────────────
const FIREBASE_CONFIG = {
  apiKey:            'AIzaSyCWWX8oCxNbSMXn9oUEXd8SCOQ1FFQ4tpw',
  authDomain:        'grupochicos.firebaseapp.com',
  projectId:         'grupochicos',
  storageBucket:     'grupochicos.firebasestorage.app',
  messagingSenderId: '98905266348',
  appId:             '1:98905266348:web:09cca26c6733b4a8cda709',
};

// ─────────────────────────────────────────────────────────────
//  CONSTANTES
// ─────────────────────────────────────────────────────────────
const FIRST_USE_KEY     = 'cc_first_use_done';
const USER_POINTS_KEY   = 'cc_user_points';
const USER_LEVEL_KEY    = 'cc_user_level';
const REPORT_DRAFT_KEY  = 'cc_report_draft';

/** Coordenadas del centro de Punta Alta */
const PUNTA_ALTA_CENTER = [-38.8794, -62.0745];
const PUNTA_ALTA_ZOOM   = 14;

// ─────────────────────────────────────────────────────────────
//  HELPERS GLOBALES — Toast
// ─────────────────────────────────────────────────────────────
const TOAST_ICONS = {
  success: '✅',
  error:   '❌',
  warning: '⚠️',
  info:    'ℹ️',
};

/**
 * Muestra una notificación toast en la parte inferior.
 * @param {string} message  — Texto a mostrar
 * @param {'success'|'error'|'warning'|'info'} type
 * @param {number} [duration=3000] — ms antes de desaparecer
 */
window.showToast = function showToast(message, type = 'info', duration = 3000) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${TOAST_ICONS[type] ?? 'ℹ️'}</span>
    <span>${message}</span>
  `;
  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('fade-out');
    toast.addEventListener('animationend', () => toast.remove(), { once: true });
  }, duration);
};

// ─────────────────────────────────────────────────────────────
//  HELPERS GLOBALES — Loading overlay
// ─────────────────────────────────────────────────────────────
/**
 * Muestra u oculta el overlay de carga global.
 * @param {boolean} show
 */
window.showLoading = function showLoading(show) {
  const overlay = document.getElementById('loading-overlay');
  if (!overlay) return;
  overlay.classList.toggle('hidden', !show);
};

// ─────────────────────────────────────────────────────────────
//  ROUTER
// ─────────────────────────────────────────────────────────────
class Router {
  constructor() {
    /** Pantallas que se muestran en la bottom nav */
    this.navScreens = [
      'screen-home',
      'screen-mis-reportes',
      'screen-cupones',
      'screen-empleo',
      'screen-transporte',
    ];

    /** Pantallas que NO forman parte del nav principal */
    this.fullscreenScreens = [
      'screen-splash',
      'screen-onboarding',
      'screen-login',
      'screen-reportar',
      'screen-municipal',
    ];

    this.allScreens = [...this.navScreens, ...this.fullscreenScreens];
    this.currentScreen = null;
  }

  /**
   * Navega a la pantalla indicada.
   * @param {string} screenId  — id del div (ej: 'screen-home')
   * @param {boolean} [updateNav=true]
   */
  navigate(screenId, updateNav = true) {
    // Ocultar todas las screens
    this.allScreens.forEach((id) => {
      const el = document.getElementById(id);
      if (el) {
        el.classList.remove('active');
      }
    });

    // Mostrar la screen destino
    const target = document.getElementById(screenId);
    if (!target) {
      console.warn('[Router] Screen no encontrada:', screenId);
      return;
    }
    target.classList.add('active');
    this.currentScreen = screenId;

    // Actualizar bottom nav
    if (updateNav) {
      const isNavScreen = this.navScreens.includes(screenId);
      const bottomNav   = document.getElementById('bottom-nav');
      if (bottomNav) {
        bottomNav.style.display = isNavScreen ? '' : 'none';
      }

      document.querySelectorAll('.nav-item').forEach((btn) => {
        btn.classList.toggle('active', btn.dataset.screen === screenId);
      });
    }

    // Ocultar asistente flotante en pantallas fullscreen
    const isFullscreen = this.fullscreenScreens.includes(screenId);
    const fab        = document.getElementById('fab-reportar');
    const asistente  = document.getElementById('btn-asistente');
    if (fab)       fab.style.display       = (screenId === 'screen-home') ? '' : 'none';
    if (asistente) asistente.style.display = isFullscreen ? 'none' : '';

    // Scroll top en pantallas con scroll
    if (target.querySelector('.overflow-y-auto')) {
      target.querySelector('.overflow-y-auto').scrollTop = 0;
    }

    console.log('[Router] Navegando a:', screenId);
  }

  /** Atajo: volver a home */
  goHome() {
    this.navigate('screen-home');
  }
}

// ─────────────────────────────────────────────────────────────
//  MAPA LEAFLET
// ─────────────────────────────────────────────────────────────
class MapManager {
  constructor() {
    this.map        = null;
    this.reportMap  = null;
    this.markers    = [];
    this.userMarker = null;
  }

  /** Inicializa el mapa principal en #map */
  initMainMap() {
    if (this.map) return; // ya inicializado

    this.map = L.map('map', {
      center: PUNTA_ALTA_CENTER,
      zoom:   PUNTA_ALTA_ZOOM,
      zoomControl: true,
      attributionControl: true,
    });

    // Capa de tiles OpenStreetMap
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19,
    }).addTo(this.map);

    // Invalidar tamaño al navegar (el mapa puede renderizarse con tamaño 0)
    setTimeout(() => this.map.invalidateSize(), 300);

    this._addDemoMarkers();
  }

  /** Inicializa el mini-mapa en #map-report (wizard de reporte) */
  initReportMap() {
    if (this.reportMap) {
      this.reportMap.invalidateSize();
      return;
    }

    this.reportMap = L.map('map-report', {
      center: PUNTA_ALTA_CENTER,
      zoom:   15,
      zoomControl: false,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
    }).addTo(this.reportMap);

    // Marcador draggable para ubicar el reporte
    const marker = L.marker(PUNTA_ALTA_CENTER, { draggable: true })
      .addTo(this.reportMap)
      .bindPopup('Arrastrá para ajustar la ubicación');

    marker.on('dragend', (e) => {
      const { lat, lng } = e.target.getLatLng();
      document.getElementById('report-address').value = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
    });

    this._reportMarker = marker;
    setTimeout(() => this.reportMap.invalidateSize(), 100);
  }

  /** Centra el mapa en la ubicación del usuario */
  centerOnUser() {
    if (!navigator.geolocation) {
      showToast('Tu navegador no soporta geolocalización', 'warning');
      return;
    }

    showLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        showLoading(false);
        const { latitude: lat, longitude: lng } = pos.coords;

        if (this.map) {
          this.map.setView([lat, lng], 16);
          if (this.userMarker) this.map.removeLayer(this.userMarker);
          this.userMarker = L.circleMarker([lat, lng], {
            radius: 8,
            fillColor: '#1a56db',
            color: '#fff',
            weight: 2,
            fillOpacity: 1,
          }).addTo(this.map).bindPopup('Tu ubicación');
        }

        if (this.reportMap && this._reportMarker) {
          this.reportMap.setView([lat, lng], 16);
          this._reportMarker.setLatLng([lat, lng]);
          document.getElementById('report-address').value = `${lat.toFixed(5)}, ${lng.toFixed(5)}`;
        }
      },
      (err) => {
        showLoading(false);
        showToast('No pudimos obtener tu ubicación', 'error');
        console.warn('[Map] Geolocation error:', err);
      },
      { timeout: 8000 }
    );
  }

  /** Agrega marcadores de demo en el mapa principal */
  _addDemoMarkers() {
    const demoReportes = [
      { lat: -38.8794, lng: -62.0745, tipo: 'bache',    title: 'Bache en Av. Colón', emoji: '🕳️' },
      { lat: -38.878,  lng: -62.072,  tipo: 'desague',  title: 'Desagüe tapado',      emoji: '💧' },
      { lat: -38.881,  lng: -62.077,  tipo: 'luminaria', title: 'Luminaria rota',     emoji: '💡' },
      { lat: -38.877,  lng: -62.070,  tipo: 'reciclaje', title: 'Punto verde',        emoji: '♻️' },
    ];

    demoReportes.forEach(({ lat, lng, tipo, title, emoji }) => {
      const icon = L.divIcon({
        className: '',
        html: `<div style="
          background:${this._colorForTipo(tipo)};
          width:32px;height:32px;border-radius:50% 50% 50% 0;
          transform:rotate(-45deg);display:flex;align-items:center;
          justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,0.25);">
          <span style="transform:rotate(45deg);font-size:14px;">${emoji}</span>
        </div>`,
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -36],
      });

      L.marker([lat, lng], { icon })
        .addTo(this.map)
        .bindPopup(`<b>${emoji} ${title}</b><br><small>Estado: <span style="color:#057a55">En revisión</span></small>`);
    });
  }

  _colorForTipo(tipo) {
    const colors = { bache: '#e02424', desague: '#c27803', luminaria: '#7c3aed', vereda: '#0891b2', reciclaje: '#057a55', otro: '#6b7280' };
    return colors[tipo] ?? '#6b7280';
  }
}

// ─────────────────────────────────────────────────────────────
//  WIZARD DE REPORTE
// ─────────────────────────────────────────────────────────────
class ReportWizard {
  constructor(db, auth, mapManager) {
    this.db         = db;
    this.auth       = auth;
    this.mapManager = mapManager;
    this.currentStep = 1;
    this.totalSteps  = 4;
    this.draft = {
      tipo:    'bache',
      desc:    '',
      foto:    null,
      lat:     PUNTA_ALTA_CENTER[0],
      lng:     PUNTA_ALTA_CENTER[1],
      address: '',
    };
  }

  init() {
    // Tipos de problema
    document.querySelectorAll('.tipo-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.tipo-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.draft.tipo = btn.dataset.tipo;
      });
    });

    // Foto
    const photoInput = document.getElementById('report-photo');
    document.getElementById('btn-take-photo')?.addEventListener('click', () => photoInput?.click());
    photoInput?.addEventListener('change', (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      this.draft.foto = file;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const preview = document.getElementById('photo-preview');
        if (preview) {
          preview.innerHTML = `<img src="${ev.target.result}" class="w-full h-full object-cover" alt="Vista previa" />`;
        }
      };
      reader.readAsDataURL(file);
    });
    document.getElementById('btn-skip-photo')?.addEventListener('click', () => this.goToStep(3));

    // Ubicación
    document.getElementById('btn-my-location')?.addEventListener('click', () => {
      this.mapManager.centerOnUser();
    });

    // Nav wizard
    document.getElementById('btn-report-next')?.addEventListener('click', () => this.nextStep());
    document.getElementById('btn-report-prev')?.addEventListener('click', () => this.prevStep());

    // Enviar
    document.getElementById('btn-enviar-reporte')?.addEventListener('click', () => this.submitReport());

    // Back button
    document.getElementById('btn-back-reportar')?.addEventListener('click', () => {
      window.router.navigate('screen-home');
      this.reset();
    });
  }

  goToStep(step) {
    if (step < 1 || step > this.totalSteps) return;

    // Ocultar step actual
    document.getElementById(`report-step-${this.currentStep}`)?.classList.add('hidden');

    this.currentStep = step;

    // Mostrar nuevo step
    const newStep = document.getElementById(`report-step-${step}`);
    if (newStep) {
      newStep.classList.remove('hidden');
      newStep.classList.add('slide-up');
    }

    // Actualizar stepper visual
    this._updateStepper();

    // Actualizar botones de navegación
    const prevBtn = document.getElementById('btn-report-prev');
    const nextBtn = document.getElementById('btn-report-next');
    if (prevBtn) prevBtn.classList.toggle('hidden', step === 1);
    if (nextBtn) {
      nextBtn.style.display = step === this.totalSteps ? 'none' : '';
    }

    // Inicializar mapa de reporte en step 3
    if (step === 3) {
      setTimeout(() => this.mapManager.initReportMap(), 100);
    }

    // Llenar resumen en step 4
    if (step === 4) {
      this._fillSummary();
    }
  }

  nextStep() {
    // Guardar datos del step actual antes de avanzar
    if (this.currentStep === 1) {
      this.draft.desc = document.getElementById('report-desc')?.value?.trim() || '';
    }
    if (this.currentStep === 3) {
      this.draft.address = document.getElementById('report-address')?.value || 'Punta Alta, Buenos Aires';
      if (this.mapManager._reportMarker) {
        const { lat, lng } = this.mapManager._reportMarker.getLatLng();
        this.draft.lat = lat;
        this.draft.lng = lng;
      }
    }
    this.goToStep(this.currentStep + 1);
  }

  prevStep() {
    this.goToStep(this.currentStep - 1);
  }

  _updateStepper() {
    document.querySelectorAll('.step-item').forEach((item) => {
      const stepNum = parseInt(item.dataset.step);
      item.classList.remove('active', 'done');
      if (stepNum === this.currentStep) item.classList.add('active');
      if (stepNum < this.currentStep) item.classList.add('done');
    });

    document.querySelectorAll('.step-line').forEach((line, idx) => {
      line.classList.toggle('done', idx < this.currentStep - 1);
    });
  }

  _fillSummary() {
    const labels = {
      bache: '🕳️ Bache / calzada', desague: '💧 Desagüe / inundación',
      luminaria: '💡 Luminaria rota', vereda: '🚶 Vereda rota',
      reciclaje: '♻️ Reciclaje', otro: '📌 Otro',
    };
    const summaryTipo = document.getElementById('summary-tipo');
    const summaryDesc = document.getElementById('summary-desc');
    const summaryLoc  = document.getElementById('summary-loc');
    if (summaryTipo) summaryTipo.textContent = labels[this.draft.tipo] || this.draft.tipo;
    if (summaryDesc) summaryDesc.textContent = this.draft.desc || '(sin descripción)';
    if (summaryLoc)  summaryLoc.textContent  = this.draft.address || 'No especificada';
  }

  async submitReport() {
    if (!this.db || !this.auth?.currentUser) {
      showToast('Iniciá sesión para enviar reportes', 'error');
      return;
    }

    showLoading(true);
    try {
      const reporte = {
        tipo:      this.draft.tipo,
        descripcion: this.draft.desc,
        lat:       this.draft.lat,
        lng:       this.draft.lng,
        direccion: this.draft.address,
        estado:    'recibido',
        userId:    this.auth.currentUser.uid,
        puntos:    50,
        fotoUrl:   null, // TODO: subir a Storage en v2
        createdAt: serverTimestamp(),
      };

      await addDoc(collection(this.db, 'reportes'), reporte);

      // Actualizar puntos localmente
      const pts = parseInt(localStorage.getItem(USER_POINTS_KEY) || '0') + 50;
      localStorage.setItem(USER_POINTS_KEY, String(pts));
      const ptsEl = document.getElementById('user-points');
      if (ptsEl) ptsEl.textContent = pts;

      showLoading(false);
      showToast('¡Reporte enviado! +50 puntos 🎉', 'success');
      window.router.navigate('screen-mis-reportes');
      this.reset();

      // Recargar lista de reportes
      window.app.loadUserReports();
    } catch (err) {
      showLoading(false);
      console.error('[ReportWizard] Error al enviar:', err);
      showToast('Error al enviar el reporte. Verificá tu conexión.', 'error');
    }
  }

  reset() {
    this.draft = { tipo: 'bache', desc: '', foto: null, lat: PUNTA_ALTA_CENTER[0], lng: PUNTA_ALTA_CENTER[1], address: '' };
    this.currentStep = 1;
    // Reset UI
    document.querySelectorAll('.tipo-btn').forEach((b, i) => b.classList.toggle('active', i === 0));
    const photoPreview = document.getElementById('photo-preview');
    if (photoPreview) photoPreview.innerHTML = `<div class="text-center text-gray-400"><p class="text-4xl mb-1">📷</p><p class="text-sm">Toca para agregar foto</p></div>`;
    const reportDesc = document.getElementById('report-desc');
    if (reportDesc) reportDesc.value = '';
    // Mostrar solo step 1
    for (let i = 1; i <= this.totalSteps; i++) {
      document.getElementById(`report-step-${i}`)?.classList.toggle('hidden', i !== 1);
    }
    this._updateStepper();
    const prevBtn = document.getElementById('btn-report-prev');
    const nextBtn = document.getElementById('btn-report-next');
    if (prevBtn) prevBtn.classList.add('hidden');
    if (nextBtn) nextBtn.style.display = '';
  }
}

// ─────────────────────────────────────────────────────────────
//  ASISTENTE IA
// ─────────────────────────────────────────────────────────────
class Asistente {
  constructor() {
    this.isOpen = false;
    this.responses = {
      default: '¡Hola! Puedo ayudarte con reportes, cupones, transporte y trámites municipales de Punta Alta.',
      hola: '¡Hola vecino/a! ¿En qué puedo ayudarte hoy?',
      reporte: 'Para reportar un problema, tocá el botón 📸 REPORTAR en el mapa, o andá a la pestaña 📋 Reportes.',
      cupon: 'Tus cupones se ganan reportando problemas. Cada reporte verificado da +50 puntos. ¡Canjeálos en la pestaña 🎟️ Cupones!',
      transporte: 'Encontrá horarios de colectivos en la pestaña 🚌 Transporte. La Línea 51 conecta con Bahía Blanca.',
      empleo: 'Buscá trabajo local en la pestaña 💼 Empleo. Se actualizan las ofertas cada semana.',
      municipal: 'El Panel Municipal es para funcionarios. Si sos vecino/a, usá la app para reportar problemas.',
      punto: 'Ganás 50 puntos por cada reporte verificado. Con 150 puntos podés canjear tu primer cupón.',
    };
  }

  init() {
    const btn      = document.getElementById('btn-asistente');
    const panel    = document.getElementById('panel-asistente');
    const closeBtn = document.getElementById('btn-cerrar-asistente');
    const input    = document.getElementById('chat-input');
    const sendBtn  = document.getElementById('btn-send-chat');

    btn?.addEventListener('click', () => this.toggle());
    closeBtn?.addEventListener('click', () => this.close());

    sendBtn?.addEventListener('click', () => this.sendMessage());
    input?.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') this.sendMessage();
    });
  }

  toggle() {
    this.isOpen ? this.close() : this.open();
  }

  open() {
    this.isOpen = true;
    document.getElementById('panel-asistente')?.classList.remove('hidden');
  }

  close() {
    this.isOpen = false;
    document.getElementById('panel-asistente')?.classList.add('hidden');
  }

  sendMessage() {
    const input = document.getElementById('chat-input');
    const text = input?.value?.trim();
    if (!text) return;

    this.addMessage(text, 'user');
    input.value = '';

    // Respuesta "IA" simple basada en palabras clave
    setTimeout(() => {
      const response = this.getResponse(text.toLowerCase());
      this.addMessage(response, 'bot');
    }, 600);
  }

  addMessage(text, from) {
    const container = document.getElementById('chat-messages');
    if (!container) return;

    const bubble = document.createElement('div');
    bubble.className = `chat-bubble ${from}`;
    bubble.innerHTML = `<p>${text}</p>`;
    container.appendChild(bubble);
    container.scrollTop = container.scrollHeight;
  }

  getResponse(text) {
    if (text.includes('hola') || text.includes('buenas')) return this.responses.hola;
    if (text.includes('report') || text.includes('problema') || text.includes('bache')) return this.responses.reporte;
    if (text.includes('cup') || text.includes('descuento') || text.includes('canje')) return this.responses.cupon;
    if (text.includes('colect') || text.includes('transport') || text.includes('51') || text.includes('bus')) return this.responses.transporte;
    if (text.includes('empleo') || text.includes('trabajo') || text.includes('labur')) return this.responses.empleo;
    if (text.includes('munic') || text.includes('panel') || text.includes('funcionar')) return this.responses.municipal;
    if (text.includes('punto') || text.includes('puntaje') || text.includes('nivel')) return this.responses.punto;
    return this.responses.default;
  }
}

// ─────────────────────────────────────────────────────────────
//  APP PRINCIPAL
// ─────────────────────────────────────────────────────────────
class App {
  constructor() {
    this.firebaseApp = null;
    this.db          = null;
    this.auth        = null;
    this.storage     = null;
    this.user        = null;
    this.mapManager  = new MapManager();
    this.reportWizard = null;
    this.asistente   = new Asistente();
  }

  async init() {
    console.log('[App] Iniciando CiudadConecta Punta Alta…');

    // 1. Verificar config Firebase
    if (!FIREBASE_CONFIG.apiKey || FIREBASE_CONFIG.apiKey === 'TU_API_KEY') {
      this._showConfigError();
      return;
    }

    // 2. Inicializar Firebase
    try {
      this.firebaseApp = initializeApp(FIREBASE_CONFIG);
      this.db          = getFirestore(this.firebaseApp);
      this.auth        = getAuth(this.firebaseApp);
      this.storage     = getStorage(this.firebaseApp);
      console.log('[App] Firebase inicializado ✓');
    } catch (err) {
      console.error('[App] Error al inicializar Firebase:', err);
      showToast('Error de configuración. Modo offline.', 'warning');
    }

    // 3. Registrar Service Worker
    this._registerSW();

    // 4. Configurar listeners globales de UI
    this._setupNavListeners();
    this._setupFAB();
    this.asistente.init();

    // 5. Splash → iniciar auth flow
    this._showSplash();
  }

  /** Muestra el splash screen y luego continúa con el flujo */
  _showSplash() {
    const splash = document.getElementById('screen-splash');
    if (splash) splash.classList.add('active');

    // Iniciar autenticación en paralelo
    const authPromise = this._initAuth();

    // Después de 2.5s, ocultar splash
    setTimeout(async () => {
      if (splash) {
        splash.classList.add('fade-out-splash');
        splash.addEventListener('animationend', () => {
          splash.classList.remove('active', 'fade-out-splash');
          splash.style.display = 'none';
        }, { once: true });
      }

      // Esperar auth si todavía está pendiente
      await authPromise;

      // Decidir a dónde ir
      const firstUseDone = localStorage.getItem(FIRST_USE_KEY);
      if (!firstUseDone) {
        this._showOnboarding();
      } else if (this.user) {
        window.router.navigate('screen-home');
        this._onHomeReady();
      } else {
        window.router.navigate('screen-login');
      }
    }, 2500);
  }

  /** Inicializa autenticación anónima con Firebase */
  async _initAuth() {
    if (!this.auth) return;

    return new Promise((resolve) => {
      const unsubscribe = onAuthStateChanged(this.auth, async (user) => {
        if (user) {
          this.user = user;
          console.log('[App] Usuario autenticado:', user.uid, '| Anónimo:', user.isAnonymous);
        } else {
          // Auto sign-in anónimo
          try {
            const result = await signInAnonymously(this.auth);
            this.user = result.user;
            console.log('[App] Login anónimo exitoso:', this.user.uid);
          } catch (err) {
            console.warn('[App] Error en login anónimo:', err);
          }
        }
        unsubscribe();
        resolve(this.user);
      });
    });
  }

  /** Muestra el onboarding */
  _showOnboarding() {
    window.router.navigate('screen-onboarding', false);

    let currentSlide = 0;
    const slides = document.querySelectorAll('.onboarding-slide');
    const dots   = document.querySelectorAll('.dot');

    const goToSlide = (idx) => {
      slides.forEach((s, i) => {
        s.style.transform = `translateX(${(i - idx) * 100}%)`;
      });
      dots.forEach((d, i) => {
        d.className = `dot w-2 h-2 rounded-full ${i === idx ? 'bg-primary' : 'bg-gray-300'}`;
      });
      currentSlide = idx;
    };

    goToSlide(0);

    const btnNext = document.getElementById('btn-onboarding-next');
    btnNext?.addEventListener('click', () => {
      if (currentSlide < slides.length - 1) {
        goToSlide(currentSlide + 1);
        if (currentSlide === slides.length - 1) {
          btnNext.textContent = 'Comenzar';
        }
      } else {
        this._finishOnboarding();
      }
    });

    document.getElementById('btn-onboarding-skip')?.addEventListener('click', () => {
      this._finishOnboarding();
    });
  }

  _finishOnboarding() {
    localStorage.setItem(FIRST_USE_KEY, '1');
    if (this.user) {
      window.router.navigate('screen-home');
      this._onHomeReady();
    } else {
      window.router.navigate('screen-login');
    }
  }

  /** Configura el login screen */
  _setupLoginScreen() {
    document.getElementById('btn-login-anon')?.addEventListener('click', async () => {
      showLoading(true);
      try {
        if (this.auth && !this.user) {
          const result = await signInAnonymously(this.auth);
          this.user = result.user;
        }
        localStorage.setItem(FIRST_USE_KEY, '1');
        showLoading(false);
        window.router.navigate('screen-home');
        this._onHomeReady();
      } catch (err) {
        showLoading(false);
        showToast('Error al iniciar sesión', 'error');
      }
    });

    document.getElementById('btn-login-google')?.addEventListener('click', () => {
      showToast('Login con Google próximamente', 'info');
    });
  }

  /** Acciones cuando la pantalla home está lista */
  _onHomeReady() {
    // Pequeño delay para que el DOM esté listo
    setTimeout(() => {
      // ── Mapa principal (Leaflet) ──
      this.mapManager.initMainMap();

      // ── Módulo Mapa avanzado (Firestore realtime) ──
      if (!this._mapaModule) {
        this._mapaModule = new MapaModule();
        this._mapaModule.init('map');
      }

      // ── Módulo Reportar ──
      if (!this._reportarModule) {
        this._reportarModule = new ReportarModule();
        this._reportarModule.init();
        window.reportarModule = this._reportarModule;
      }

      // ── Módulo Mis Reportes ──
      if (!this._misReportesModule) {
        this._misReportesModule = new MisReportesModule();
        this._misReportesModule.init();
        window.misReportes = this._misReportesModule;
      }

      // ── Módulo Cupones ──
      if (!this._cuponesModule) {
        this._cuponesModule = new CuponesModule();
        this._cuponesModule.init();
        window.cuponesModule = this._cuponesModule;
      }

      // ── Módulo Reputación ──
      if (!this._reputacionModule) {
        this._reputacionModule = new ReputacionModule();
        this._reputacionModule.init(this.user?.uid);
        window.reputacionModule = this._reputacionModule;
      }

      // ── Módulo Comercios ──
      if (!this._comerciosModule) {
        this._comerciosModule = new ComerciosModule();
        this._comerciosModule.init();
      }

      // ── Módulo Empleo ──
      if (!this._empleoModule) {
        this._empleoModule = new EmpleoModule();
        this._empleoModule.init();
        window.empleoModule = this._empleoModule;
      }

      // ── Módulo Transporte ──
      if (!this._transporteModule) {
        this._transporteModule = new TransporteModule();
        this._transporteModule.init();
        window.transporteModule = this._transporteModule;
      }

      // ── Asistente IA ──
      asistente.init();
      window.asistente = asistente;

      this._loadUserPoints();
      this._setupLoginScreen();
      this.reportWizard = new ReportWizard(this.db, this.auth, this.mapManager);
      this.reportWizard.init();
    }, 150);
  }

  /** Carga los puntos del usuario desde localStorage */
  _loadUserPoints() {
    const pts = localStorage.getItem(USER_POINTS_KEY) || '0';
    const ptsEl = document.getElementById('user-points');
    if (ptsEl) ptsEl.textContent = pts;

    const cuponPtsEl = document.getElementById('cupon-points');
    if (cuponPtsEl) cuponPtsEl.textContent = pts;
  }

  /** Carga los reportes del usuario actual desde Firestore */
  async loadUserReports() {
    if (!this.db || !this.user) return;

    try {
      const q = query(
        collection(this.db, 'reportes'),
        where('userId', '==', this.user.uid),
        orderBy('createdAt', 'desc')
      );
      const snap = await getDocs(q);
      const listaEl = document.getElementById('lista-reportes');
      const emptyEl = document.getElementById('empty-reportes');

      if (!listaEl) return;

      if (snap.empty) {
        if (emptyEl) emptyEl.style.display = '';
        return;
      }

      if (emptyEl) emptyEl.style.display = 'none';

      // Limpiar lista (excepto el placeholder vacío)
      listaEl.querySelectorAll('.reporte-card').forEach(el => el.remove());

      snap.forEach((doc) => {
        const r = doc.data();
        const card = this._createReporteCard(doc.id, r);
        listaEl.appendChild(card);
      });
    } catch (err) {
      console.error('[App] Error al cargar reportes:', err);
    }
  }

  /** Crea el HTML de una card de reporte */
  _createReporteCard(id, reporte) {
    const estadoLabels = { recibido: 'Recibido', en_agenda: 'En agenda', en_obra: 'En obra', resuelto: 'Resuelto' };
    const tipoLabels   = { bache: '🕳️ Bache', desague: '💧 Desagüe', luminaria: '💡 Luminaria', vereda: '🚶 Vereda', reciclaje: '♻️ Reciclaje', otro: '📌 Otro' };

    const estados = ['recibido', 'en_agenda', 'en_obra', 'resuelto'];
    const currentEstado = reporte.estado || 'recibido';

    const stepperHTML = estados.map((e) => {
      const isDone   = estados.indexOf(e) < estados.indexOf(currentEstado);
      const isActive = e === currentEstado;
      const cls = isDone ? 'done' : isActive ? 'active' : '';
      return `<div class="status-step ${cls}">${estadoLabels[e]}</div>`;
    }).join('');

    const div = document.createElement('div');
    div.className = 'reporte-card p-4 mb-2';
    div.dataset.tipo = reporte.tipo;
    div.innerHTML = `
      <div class="flex items-center justify-between mb-2">
        <span class="font-semibold text-gray-800 text-sm">${tipoLabels[reporte.tipo] || reporte.tipo}</span>
        <span class="text-xs text-gray-400">${this._formatDate(reporte.createdAt)}</span>
      </div>
      ${reporte.descripcion ? `<p class="text-xs text-gray-500 mb-2 line-clamp-2">${reporte.descripcion}</p>` : ''}
      <div class="status-stepper rounded-lg overflow-hidden text-center border border-gray-100 mt-2">
        ${stepperHTML}
      </div>
    `;
    return div;
  }

  _formatDate(ts) {
    if (!ts) return '';
    try {
      const date = ts.toDate ? ts.toDate() : new Date(ts);
      return date.toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit', year: '2-digit' });
    } catch { return ''; }
  }

  /** Configura los listeners de la bottom nav */
  _setupNavListeners() {
    // Bottom nav items
    document.querySelectorAll('.nav-item').forEach((btn) => {
      btn.addEventListener('click', () => {
        const screenId = btn.dataset.screen;
        window.router.navigate(screenId);

        // Lazy init del mapa al navegar a home
        if (screenId === 'screen-home') {
          setTimeout(() => this.mapManager.initMainMap(), 150);
        }

        // Cargar reportes al ir a mis-reportes
        if (screenId === 'screen-mis-reportes') {
          this.loadUserReports();
        }

        // Sync puntos en cupones
        if (screenId === 'screen-cupones') {
          this._loadUserPoints();
        }
      });
    });

    // Filtros de reportes
    document.querySelectorAll('.filtro-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.filtro-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        // TODO: filtrar lista de reportes por estado
      });
    });

    // Categorías de empleo
    document.querySelectorAll('.categoria-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.categoria-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });

    // Cupones: canjear
    document.querySelectorAll('.canjear-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const pts = parseInt(localStorage.getItem(USER_POINTS_KEY) || '0');
        if (pts < 150) {
          showToast('No tenés suficientes puntos', 'warning');
          return;
        }
        document.getElementById('qr-modal')?.classList.remove('hidden');
      });
    });

    // Cerrar QR
    document.getElementById('btn-cerrar-qr')?.addEventListener('click', () => {
      document.getElementById('qr-modal')?.classList.add('hidden');
    });

    // Tabs de cupones
    document.querySelectorAll('.cupon-tab').forEach((tab) => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.cupon-tab').forEach(t => {
          t.classList.remove('active', 'border-b-2', 'border-secondary', 'text-secondary');
          t.classList.add('text-gray-400');
        });
        tab.classList.add('active', 'border-b-2', 'border-secondary', 'text-secondary');
        tab.classList.remove('text-gray-400');
      });
    });

    // Shortcut desde manifest (URL params)
    const params = new URLSearchParams(window.location.search);
    const shortcut = params.get('shortcut');
    if (shortcut) {
      const map = { reportar: 'screen-reportar', cupones: 'screen-cupones', municipal: 'screen-municipal' };
      if (map[shortcut]) {
        setTimeout(() => window.router.navigate(map[shortcut]), 2600);
      }
    }
  }

  /** Configura el FAB de reportar */
  _setupFAB() {
    document.getElementById('fab-reportar')?.addEventListener('click', () => {
      window.router.navigate('screen-reportar');
      if (this.reportWizard) this.reportWizard.reset();
    });
  }

  /** Registra el Service Worker */
  async _registerSW() {
    if (!('serviceWorker' in navigator)) {
      console.warn('[App] Service Worker no soportado en este navegador');
      return;
    }
    try {
      const reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
      console.log('[App] Service Worker registrado:', reg.scope);

      // Si hay una nueva versión disponible, notificar
      reg.addEventListener('updatefound', () => {
        const newWorker = reg.installing;
        newWorker?.addEventListener('statechange', () => {
          if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
            showToast('Nueva versión disponible. Recargá para actualizar.', 'info', 6000);
          }
        });
      });
    } catch (err) {
      console.warn('[App] Error al registrar Service Worker:', err);
    }
  }

  /** Muestra mensaje de error de configuración */
  _showConfigError() {
    const splash = document.getElementById('screen-splash');
    if (splash) {
      splash.innerHTML = `
        <div class="text-center text-white px-8">
          <p class="text-5xl mb-4">⚠️</p>
          <h2 class="text-xl font-bold mb-2">Configuración requerida</h2>
          <p class="text-sm opacity-80">Completá la configuración de Firebase en app.js para usar la app.</p>
        </div>
      `;
    }
  }
}

// ─────────────────────────────────────────────────────────────
//  BOOTSTRAP
// ─────────────────────────────────────────────────────────────
const router = new Router();
const app    = new App();

// Exponer globalmente para que el HTML inline y otros módulos accedan
window.router = router;
window.app    = app;

// Arrancar
app.init().catch((err) => {
  console.error('[App] Error fatal en init:', err);
  showToast('Error al iniciar la app', 'error');
});
