/**
 * panel.js — CiudadConecta Panel Municipal
 * Clase principal que maneja toda la lógica del dashboard
 */

// ─── Firebase Config ──────────────────────────────────────────────────────────
const FIREBASE_CONFIG = {
  apiKey: "AIzaSyCWWX8oCxNbSMXn9oUEXd8SCOQ1FFQ4tpw",
  authDomain: "grupochicos.firebaseapp.com",
  projectId: "grupochicos",
  storageBucket: "grupochicos.firebasestorage.app",
  messagingSenderId: "98905266348",
  appId: "1:98905266348:web:09cca26c6733b4a8cda709"
};

// ─── Demo Data ────────────────────────────────────────────────────────────────
const REPORTES_DEMO = [
  { tipo: 'bache',     lat: -38.878, lng: -62.071, estado: 'recibido',  descripcion: 'Bache grande en esquina',       confianza_ia: 94 },
  { tipo: 'bache',     lat: -38.882, lng: -62.068, estado: 'en_agenda', descripcion: 'Bache en calzada',              confianza_ia: 87 },
  { tipo: 'desague',   lat: -38.880, lng: -62.073, estado: 'en_obra',   descripcion: 'Obstrucción en sumidero',       confianza_ia: 91 },
  { tipo: 'bache',     lat: -38.875, lng: -62.065, estado: 'resuelto',  descripcion: 'Bache reparado',                confianza_ia: 88 },
  { tipo: 'desague',   lat: -38.884, lng: -62.070, estado: 'recibido',  descripcion: 'Tapón en calle inundada',       confianza_ia: 76 },
  { tipo: 'bache',     lat: -38.877, lng: -62.074, estado: 'recibido',  descripcion: 'Múltiples baches',              confianza_ia: 92 },
  { tipo: 'reciclaje', lat: -38.881, lng: -62.067, estado: 'resuelto',  descripcion: 'Campana llena vaciada',         confianza_ia: 85 },
  { tipo: 'bache',     lat: -38.879, lng: -62.072, estado: 'en_agenda', descripcion: 'Bache peligroso',               confianza_ia: 96 }
];

const COMERCIOS_DEMO = [
  { nombre: 'Supermercado El Ahorro',   rubro: 'Alimentación',  activo: true,  cuponesCanjeados: 34 },
  { nombre: 'Farmacia Central',         rubro: 'Salud',         activo: true,  cuponesCanjeados: 18 },
  { nombre: 'Librería El Saber',        rubro: 'Educación',     activo: false, cuponesCanjeados: 7  },
  { nombre: 'Panadería Don Luis',       rubro: 'Alimentación',  activo: true,  cuponesCanjeados: 22 },
  { nombre: 'Ferretería La Llave',      rubro: 'Construcción',  activo: true,  cuponesCanjeados: 11 },
  { nombre: 'Almacén La Esquina',       rubro: 'Alimentación',  activo: false, cuponesCanjeados: 3  }
];

const ESTADOS_LABELS = window.ESTADOS_LABELS = {
  recibido:  { label: 'Recibido',   color: 'bg-blue-100 text-blue-800'   },
  en_agenda: { label: 'En agenda',  color: 'bg-yellow-100 text-yellow-800' },
  en_obra:   { label: 'En obra',    color: 'bg-orange-100 text-orange-800' },
  resuelto:  { label: 'Resuelto',   color: 'bg-green-100 text-green-800'  }
};

const TIPO_ICONS = window.TIPO_ICONS = {
  bache:     '🕳️',
  desague:   '🌊',
  reciclaje: '♻️',
  luminaria: '💡',
  arbolado:  '🌳',
  otro:      '📌'
};

// ─── Clase Principal ──────────────────────────────────────────────────────────
class PanelMunicipal {
  constructor() {
    this.db         = null;
    this.reportes   = [];
    this.comercios  = COMERCIOS_DEMO;
    this.seccionActual = 'dashboard';
    this.mapa       = null;
    this.mapaIniciado = false;
    this.paginaActual = 1;
    this.reportesPorPagina = 10;
    this.filtros    = { estado: '', tipo: '', zona: '' };
    this.seleccionados = new Set();
    this.unsubscribeReportes = null;
  }

  // ─── Init ─────────────────────────────────────────────────────────────────
  async init() {
    try {
      const { initializeApp } = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js');
      const { getFirestore, collection, getDocs, addDoc, updateDoc, doc, onSnapshot, query, orderBy }
        = await import('https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js');

      const app = initializeApp(FIREBASE_CONFIG);
      this.db   = getFirestore(app);
      this._fs  = { collection, getDocs, addDoc, updateDoc, doc, onSnapshot, query, orderBy };

      await this.iniciarDemoData();
      this.suscribirReportesEnTiempoReal();
    } catch (err) {
      console.error('Error inicializando Firebase:', err);
      this.usarDatosLocales();
    }
  }

  usarDatosLocales() {
    this.reportes = REPORTES_DEMO.map((r, i) => ({
      id: `demo-${i}`,
      ...r,
      userId: 'demo',
      timestamp: Date.now() - Math.floor(Math.random() * 7 * 86400000),
      activo: true,
      foto_url: null
    }));
    this.renderizarSeccion(this.seccionActual);
  }

  // ─── Seed Demo Data ───────────────────────────────────────────────────────
  async iniciarDemoData() {
    const { collection, getDocs, addDoc } = this._fs;
    try {
      const snap = await getDocs(collection(this.db, 'reportes'));
      if (!snap.empty) return;

      const ahora = Date.now();
      for (const r of REPORTES_DEMO) {
        await addDoc(collection(this.db, 'reportes'), {
          ...r,
          userId: 'demo',
          timestamp: ahora - Math.floor(Math.random() * 7 * 86400000),
          activo: true,
          foto_url: null,
          zona: this.inferirZona(r.lat, r.lng)
        });
      }
    } catch (e) {
      console.warn('No se pudo cargar demo data:', e.message);
    }
  }

  inferirZona(lat, lng) {
    if (lat < -38.880) return 'Sur';
    if (lat > -38.878) return 'Norte';
    if (lng < -62.070) return 'Este';
    return 'Centro';
  }

  // ─── Tiempo Real ──────────────────────────────────────────────────────────
  suscribirReportesEnTiempoReal() {
    if (!this.db) return;
    const { collection, onSnapshot, query, orderBy } = this._fs;
    const q = query(collection(this.db, 'reportes'), orderBy('timestamp', 'desc'));

    this.unsubscribeReportes = onSnapshot(q, snap => {
      this.reportes = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      this.renderizarSeccion(this.seccionActual);
    }, err => {
      console.warn('Error stream:', err.message);
      this.usarDatosLocales();
    });
  }

  // ─── Cambiar Estado Reporte ───────────────────────────────────────────────
  async cambiarEstado(id, nuevoEstado) {
    if (this.db) {
      try {
        const { doc, updateDoc } = this._fs;
        await updateDoc(doc(this.db, 'reportes', id), { estado: nuevoEstado });
      } catch (e) {
        console.warn('Error actualizando:', e.message);
      }
    }
    // Actualizar local también
    const r = this.reportes.find(x => x.id === id);
    if (r) r.estado = nuevoEstado;
    this.renderizarSeccion(this.seccionActual);
    mostrarToast(`Estado actualizado: ${ESTADOS_LABELS[nuevoEstado]?.label}`);
  }

  // ─── Bulk Actions ─────────────────────────────────────────────────────────
  async marcarSeleccionadosEnAgenda() {
    for (const id of this.seleccionados) {
      await this.cambiarEstado(id, 'en_agenda');
    }
    this.seleccionados.clear();
    mostrarToast(`${this.seleccionados.size || 'Reportes'} marcados como "En agenda"`);
  }

  // ─── Export CSV ───────────────────────────────────────────────────────────
  exportarCSV() {
    const headers = ['ID', 'Tipo', 'Descripcion', 'Estado', 'Zona', 'Lat', 'Lng', 'Confianza IA', 'Fecha'];
    const filas = this.reportes.map(r => [
      r.id,
      r.tipo,
      `"${(r.descripcion || '').replace(/"/g, '""')}"`,
      r.estado,
      r.zona || '',
      r.lat,
      r.lng,
      r.confianza_ia + '%',
      r.timestamp ? new Date(r.timestamp).toLocaleDateString('es-AR') : ''
    ]);
    const csv = [headers, ...filas].map(f => f.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `reportes_ciudadconecta_${new Date().toISOString().slice(0,10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    mostrarToast('CSV exportado correctamente');
  }

  // ─── KPIs ─────────────────────────────────────────────────────────────────
  calcularKPIs() {
    const ahora   = Date.now();
    const mes     = 30 * 86400000;
    const activos = this.reportes.filter(r => r.estado !== 'resuelto');
    const resueltosEsteMes = this.reportes.filter(r =>
      r.estado === 'resuelto' && (ahora - (r.timestamp || 0)) < mes
    );
    const enProgreso = this.reportes.filter(r => ['en_agenda','en_obra'].includes(r.estado));

    // Tiempo promedio de resolución (días)
    const tiempos = this.reportes
      .filter(r => r.estado === 'resuelto' && r.timestamp)
      .map(r => Math.floor((ahora - r.timestamp) / 86400000));
    const promedio = tiempos.length
      ? Math.round(tiempos.reduce((a,b) => a+b, 0) / tiempos.length)
      : 0;

    return {
      activos: activos.length,
      resueltosEsteMes: resueltosEsteMes.length,
      enProgreso: enProgreso.length,
      promedioDias: promedio
    };
  }

  // ─── Reportes sin actualizar >72hs ────────────────────────────────────────
  reportesSinActualizar() {
    const limite = Date.now() - 72 * 3600000;
    return this.reportes.filter(r =>
      r.estado !== 'resuelto' && r.timestamp && r.timestamp < limite
    );
  }

  // ─── Datos para gráfico de barras (últimas 4 semanas) ─────────────────────
  datosBarras() {
    const ahora = Date.now();
    const semanas = [0,1,2,3].map(i => {
      const inicio = ahora - (i+1)*7*86400000;
      const fin    = ahora - i*7*86400000;
      const count  = this.reportes.filter(r => r.timestamp >= inicio && r.timestamp < fin).length;
      const label  = `Sem -${i+1}`;
      return { label, count };
    }).reverse();
    return semanas;
  }

  // ─── Renderizado Principal ─────────────────────────────────────────────────
  renderizarSeccion(seccion) {
    this.seccionActual = seccion;
    // Highlight sidebar
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.dataset.seccion === seccion);
    });

    const contenido = document.getElementById('contenido-principal');
    if (!contenido) return;

    switch(seccion) {
      case 'dashboard':     contenido.innerHTML = this.htmlDashboard();   this.postRenderDashboard();   break;
      case 'mapa':          contenido.innerHTML = this.htmlMapa();         this.postRenderMapa();         break;
      case 'reportes':      contenido.innerHTML = this.htmlReportes();     this.postRenderReportes();     break;
      case 'comercios':     contenido.innerHTML = this.htmlComercios();                                   break;
      case 'usuarios':      contenido.innerHTML = this.htmlUsuarios();                                    break;
      case 'configuracion': contenido.innerHTML = this.htmlConfiguracion();                               break;
    }
  }

  // ─── HTML Dashboard ───────────────────────────────────────────────────────
  htmlDashboard() {
    const kpi    = this.calcularKPIs();
    const alerta = this.reportesSinActualizar();
    const barras = this.datosBarras();
    const max    = Math.max(...barras.map(b => b.count), 1);
    const ultimos10 = this.reportes.slice(0, 10);

    const alertaHtml = alerta.length > 0 ? `
      <div class="bg-red-50 border-l-4 border-red-500 p-4 rounded-lg mb-6 flex items-center gap-3">
        <span class="text-2xl">⚠️</span>
        <div>
          <p class="font-semibold text-red-800">Atención: ${alerta.length} reporte(s) sin actualizar hace más de 72 horas</p>
          <p class="text-red-600 text-sm">${alerta.map(r => r.descripcion).join(', ')}</p>
        </div>
      </div>` : '';

    const barrasHtml = barras.map(b => `
      <div class="flex flex-col items-center gap-1 flex-1">
        <span class="text-xs font-bold text-gray-700">${b.count}</span>
        <div class="w-full bg-blue-500 rounded-t transition-all" style="height:${Math.max(4, Math.round((b.count/max)*100))}px"></div>
        <span class="text-xs text-gray-500">${b.label}</span>
      </div>`).join('');

    const filasTabla = ultimos10.map(r => {
      const est = ESTADOS_LABELS[r.estado] || { label: r.estado, color: 'bg-gray-100 text-gray-700' };
      const fecha = r.timestamp ? new Date(r.timestamp).toLocaleDateString('es-AR') : '—';
      return `
        <tr class="border-b hover:bg-gray-50">
          <td class="py-2 px-3 text-sm">${TIPO_ICONS[r.tipo] || '📌'} ${r.tipo || '—'}</td>
          <td class="py-2 px-3 text-sm text-gray-600">${r.zona || inferirZona(r.lat, r.lng)}</td>
          <td class="py-2 px-3">
            <span class="px-2 py-1 rounded-full text-xs font-medium ${est.color}">${est.label}</span>
          </td>
          <td class="py-2 px-3 text-sm text-gray-500">${fecha}</td>
          <td class="py-2 px-3">
            <select onchange="panel.cambiarEstado('${r.id}', this.value)"
              class="text-xs border rounded px-2 py-1 bg-white cursor-pointer">
              ${Object.entries(ESTADOS_LABELS).map(([k,v]) =>
                `<option value="${k}" ${r.estado===k?'selected':''}>${v.label}</option>`
              ).join('')}
            </select>
          </td>
        </tr>`;
    }).join('');

    return `
      <div class="p-6 space-y-6">
        <div class="flex items-center justify-between mb-2">
          <h1 class="text-2xl font-bold text-gray-800">📊 Dashboard</h1>
          <span class="text-sm text-gray-400">Actualización en tiempo real</span>
        </div>

        ${alertaHtml}

        <!-- KPIs -->
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div class="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <p class="text-sm text-blue-600 font-medium">Total Reportes Activos</p>
            <p class="text-3xl font-bold text-blue-700 mt-1">${kpi.activos}</p>
            <p class="text-xs text-blue-400 mt-1">sin contar resueltos</p>
          </div>
          <div class="bg-green-50 border border-green-200 rounded-xl p-4">
            <p class="text-sm text-green-600 font-medium">Resueltos este mes</p>
            <p class="text-3xl font-bold text-green-700 mt-1">${kpi.resueltosEsteMes}</p>
            <p class="text-xs text-green-400 mt-1">últimos 30 días</p>
          </div>
          <div class="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
            <p class="text-sm text-yellow-600 font-medium">En progreso</p>
            <p class="text-3xl font-bold text-yellow-700 mt-1">${kpi.enProgreso}</p>
            <p class="text-xs text-yellow-400 mt-1">en agenda + en obra</p>
          </div>
          <div class="bg-gray-50 border border-gray-200 rounded-xl p-4">
            <p class="text-sm text-gray-600 font-medium">Tiempo promedio</p>
            <p class="text-3xl font-bold text-gray-700 mt-1">${kpi.promedioDias}d</p>
            <p class="text-xs text-gray-400 mt-1">resolución</p>
          </div>
        </div>

        <!-- Gráfico y Mapa mini -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <!-- Gráfico barras -->
          <div class="bg-white border rounded-xl p-5 shadow-sm">
            <h2 class="font-semibold text-gray-700 mb-4">Reportes por semana</h2>
            <div class="flex items-end gap-4 h-28 px-4">
              ${barrasHtml}
            </div>
          </div>
          <!-- Mini mapa -->
          <div class="bg-white border rounded-xl p-5 shadow-sm">
            <h2 class="font-semibold text-gray-700 mb-3">Mapa de incidentes activos</h2>
            <div id="mini-mapa" class="w-full rounded-lg overflow-hidden" style="height:160px;background:#e8f4f8;"></div>
          </div>
        </div>

        <!-- Tabla últimos reportes -->
        <div class="bg-white border rounded-xl shadow-sm overflow-hidden">
          <div class="px-5 py-4 border-b flex items-center justify-between">
            <h2 class="font-semibold text-gray-700">Últimos 10 reportes</h2>
            <button onclick="panel.renderizarSeccion('reportes')"
              class="text-sm text-blue-600 hover:underline">Ver todos →</button>
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left">
              <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
                <tr>
                  <th class="py-2 px-3">Tipo</th>
                  <th class="py-2 px-3">Zona</th>
                  <th class="py-2 px-3">Estado</th>
                  <th class="py-2 px-3">Fecha</th>
                  <th class="py-2 px-3">Cambiar</th>
                </tr>
              </thead>
              <tbody>${filasTabla || '<tr><td colspan="5" class="py-8 text-center text-gray-400">Sin datos aún</td></tr>'}</tbody>
            </table>
          </div>
        </div>
      </div>`;
  }

  postRenderDashboard() {
    // Mini mapa Leaflet
    setTimeout(() => {
      const el = document.getElementById('mini-mapa');
      if (!el || !window.L) return;
      if (this._miniMapa) { this._miniMapa.remove(); this._miniMapa = null; }
      const m = L.map('mini-mapa', { zoomControl: false, dragging: false, scrollWheelZoom: false })
        .setView([-38.879, -62.070], 13);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(m);
      this.reportes.filter(r => r.estado !== 'resuelto').forEach(r => {
        if (r.lat && r.lng) L.circleMarker([r.lat, r.lng], { radius:6, color: '#3B82F6', fillOpacity:0.8 }).addTo(m);
      });
      this._miniMapa = m;
    }, 300);
  }

  // ─── HTML Mapa ─────────────────────────────────────────────────────────────
  htmlMapa() {
    return `
      <div class="p-6 h-full flex flex-col" style="height:calc(100vh - 60px)">
        <div class="flex items-center justify-between mb-4">
          <h1 class="text-2xl font-bold text-gray-800">🗺️ Mapa de Incidentes</h1>
          <div class="flex gap-2 text-sm">
            <span class="px-2 py-1 bg-blue-100 text-blue-800 rounded-full">🔵 Recibido</span>
            <span class="px-2 py-1 bg-yellow-100 text-yellow-800 rounded-full">🟡 En agenda</span>
            <span class="px-2 py-1 bg-orange-100 text-orange-800 rounded-full">🟠 En obra</span>
            <span class="px-2 py-1 bg-green-100 text-green-800 rounded-full">🟢 Resuelto</span>
          </div>
        </div>
        <div id="mapa-principal" class="flex-1 rounded-xl overflow-hidden border shadow"
          style="min-height:500px"></div>
      </div>`;
  }

  postRenderMapa() {
    setTimeout(() => {
      if (!window.L) return;
      if (this._mapaP) { this._mapaP.remove(); this._mapaP = null; }
      const colores = { recibido:'#3B82F6', en_agenda:'#F59E0B', en_obra:'#F97316', resuelto:'#22C55E' };
      const m = L.map('mapa-principal').setView([-38.879, -62.070], 13);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap'
      }).addTo(m);
      this.reportes.forEach(r => {
        if (!r.lat || !r.lng) return;
        const color = colores[r.estado] || '#6B7280';
        const est   = ESTADOS_LABELS[r.estado]?.label || r.estado;
        L.circleMarker([r.lat, r.lng], { radius:10, color, fillColor:color, fillOpacity:0.8, weight:2 })
          .bindPopup(`<b>${TIPO_ICONS[r.tipo]||'📌'} ${r.tipo}</b><br>${r.descripcion}<br>
            <span style="color:${color}">${est}</span><br>
            <a href="https://maps.google.com/?q=${r.lat},${r.lng}" target="_blank" class="text-blue-600">Ver en Google Maps</a>`)
          .addTo(m);
      });
      this._mapaP = m;
    }, 300);
  }

  // ─── HTML Reportes ─────────────────────────────────────────────────────────
  htmlReportes() {
    let datos = [...this.reportes];
    if (this.filtros.estado) datos = datos.filter(r => r.estado === this.filtros.estado);
    if (this.filtros.tipo)   datos = datos.filter(r => r.tipo   === this.filtros.tipo);
    if (this.filtros.zona)   datos = datos.filter(r => (r.zona||'').toLowerCase().includes(this.filtros.zona.toLowerCase()));

    const total   = datos.length;
    const inicio  = (this.paginaActual - 1) * this.reportesPorPagina;
    const pagina  = datos.slice(inicio, inicio + this.reportesPorPagina);
    const totalPaginas = Math.max(1, Math.ceil(total / this.reportesPorPagina));

    const filas = pagina.map(r => {
      const est   = ESTADOS_LABELS[r.estado] || { label: r.estado, color: 'bg-gray-100 text-gray-700' };
      const fecha = r.timestamp ? new Date(r.timestamp).toLocaleDateString('es-AR') : '—';
      const sel   = this.seleccionados.has(r.id);
      return `
        <tr class="border-b hover:bg-gray-50 ${sel ? 'bg-blue-50' : ''}">
          <td class="py-3 px-3">
            <input type="checkbox" ${sel?'checked':''} onchange="panel.toggleSeleccion('${r.id}', this.checked)"
              class="rounded border-gray-300">
          </td>
          <td class="py-3 px-3">
            ${r.foto_url
              ? `<img src="${r.foto_url}" class="w-12 h-12 object-cover rounded-lg">`
              : `<div class="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center text-2xl">${TIPO_ICONS[r.tipo]||'📌'}</div>`}
          </td>
          <td class="py-3 px-3">
            <p class="font-medium text-gray-800 capitalize">${r.tipo || '—'}</p>
            <p class="text-xs text-gray-500">${r.descripcion || ''}</p>
          </td>
          <td class="py-3 px-3">
            <a href="https://maps.google.com/?q=${r.lat},${r.lng}" target="_blank"
              class="text-blue-600 text-sm hover:underline flex items-center gap-1">
              📍 Ver ubicación
            </a>
          </td>
          <td class="py-3 px-3">
            <select onchange="panel.cambiarEstado('${r.id}', this.value)"
              class="text-xs border rounded-lg px-2 py-1.5 bg-white cursor-pointer ${est.color}">
              ${Object.entries(ESTADOS_LABELS).map(([k,v]) =>
                `<option value="${k}" ${r.estado===k?'selected':''}>${v.label}</option>`
              ).join('')}
            </select>
          </td>
          <td class="py-3 px-3 text-sm text-gray-500">${fecha}</td>
          <td class="py-3 px-3">
            <div class="flex items-center gap-1">
              <div class="w-16 bg-gray-200 rounded-full h-2">
                <div class="bg-green-500 h-2 rounded-full" style="width:${r.confianza_ia||0}%"></div>
              </div>
              <span class="text-xs text-gray-600">${r.confianza_ia||0}%</span>
            </div>
          </td>
        </tr>`;
    }).join('');

    return `
      <div class="p-6 space-y-4">
        <div class="flex items-center justify-between">
          <h1 class="text-2xl font-bold text-gray-800">📋 Gestión de Reportes</h1>
          <div class="flex gap-2">
            <button onclick="panel.marcarSeleccionadosEnAgenda()"
              class="px-4 py-2 bg-yellow-500 text-white rounded-lg text-sm font-medium hover:bg-yellow-600 transition">
              📅 En agenda (${this.seleccionados.size})
            </button>
            <button onclick="panel.exportarCSV()"
              class="px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition">
              ⬇️ Exportar CSV
            </button>
          </div>
        </div>

        <!-- Filtros -->
        <div class="bg-white border rounded-xl p-4 flex flex-wrap gap-3">
          <select onchange="panel.aplicarFiltro('estado', this.value)"
            class="border rounded-lg px-3 py-2 text-sm bg-white">
            <option value="">Todos los estados</option>
            ${Object.entries(ESTADOS_LABELS).map(([k,v]) =>
              `<option value="${k}" ${this.filtros.estado===k?'selected':''}>${v.label}</option>`
            ).join('')}
          </select>
          <select onchange="panel.aplicarFiltro('tipo', this.value)"
            class="border rounded-lg px-3 py-2 text-sm bg-white">
            <option value="">Todos los tipos</option>
            ${Object.keys(TIPO_ICONS).map(t =>
              `<option value="${t}" ${this.filtros.tipo===t?'selected':''}>${TIPO_ICONS[t]} ${t}</option>`
            ).join('')}
          </select>
          <input type="text" placeholder="🔍 Filtrar por zona..." value="${this.filtros.zona}"
            oninput="panel.aplicarFiltro('zona', this.value)"
            class="border rounded-lg px-3 py-2 text-sm flex-1 min-w-32">
          <button onclick="panel.limpiarFiltros()"
            class="px-3 py-2 text-sm text-gray-600 hover:text-gray-900 border rounded-lg">
            ✕ Limpiar
          </button>
        </div>

        <!-- Tabla -->
        <div class="bg-white border rounded-xl shadow-sm overflow-hidden">
          <div class="px-5 py-3 border-b bg-gray-50 flex items-center justify-between">
            <p class="text-sm text-gray-600">${total} reporte(s) — Página ${this.paginaActual} de ${totalPaginas}</p>
            <label class="flex items-center gap-2 text-sm text-gray-600 cursor-pointer">
              <input type="checkbox" onchange="panel.toggleTodos(this.checked)" class="rounded">
              Seleccionar todos
            </label>
          </div>
          <div class="overflow-x-auto">
            <table class="w-full text-left">
              <thead class="bg-gray-50 text-xs text-gray-500 uppercase">
                <tr>
                  <th class="py-2 px-3 w-8"></th>
                  <th class="py-2 px-3 w-16">Foto</th>
                  <th class="py-2 px-3">Tipo / Descripción</th>
                  <th class="py-2 px-3">Ubicación</th>
                  <th class="py-2 px-3">Estado</th>
                  <th class="py-2 px-3">Fecha</th>
                  <th class="py-2 px-3">Confianza IA</th>
                </tr>
              </thead>
              <tbody>${filas || '<tr><td colspan="7" class="py-10 text-center text-gray-400">No hay reportes con estos filtros</td></tr>'}</tbody>
            </table>
          </div>
          <!-- Paginación -->
          <div class="px-5 py-3 border-t flex items-center justify-between bg-gray-50">
            <button onclick="panel.irPagina(${this.paginaActual - 1})"
              ${this.paginaActual===1?'disabled':''} class="px-3 py-1 border rounded text-sm disabled:opacity-40">← Anterior</button>
            <div class="flex gap-1">
              ${Array.from({length:totalPaginas}, (_,i) => `
                <button onclick="panel.irPagina(${i+1})"
                  class="px-3 py-1 border rounded text-sm ${this.paginaActual===i+1?'bg-blue-500 text-white':''}">${i+1}</button>
              `).join('')}
            </div>
            <button onclick="panel.irPagina(${this.paginaActual + 1})"
              ${this.paginaActual===totalPaginas?'disabled':''} class="px-3 py-1 border rounded text-sm disabled:opacity-40">Siguiente →</button>
          </div>
        </div>
      </div>`;
  }

  postRenderReportes() { /* Sin acciones post-render */ }

  aplicarFiltro(campo, valor) {
    this.filtros[campo] = valor;
    this.paginaActual = 1;
    this.renderizarSeccion('reportes');
  }

  limpiarFiltros() {
    this.filtros = { estado: '', tipo: '', zona: '' };
    this.paginaActual = 1;
    this.renderizarSeccion('reportes');
  }

  irPagina(n) {
    const total = Math.ceil(this.reportes.length / this.reportesPorPagina);
    if (n < 1 || n > total) return;
    this.paginaActual = n;
    this.renderizarSeccion('reportes');
  }

  toggleSeleccion(id, checked) {
    if (checked) this.seleccionados.add(id);
    else this.seleccionados.delete(id);
    // Actualizar contador sin re-render completo
    const btn = document.querySelector('[onclick="panel.marcarSeleccionadosEnAgenda()"]');
    if (btn) btn.textContent = `📅 En agenda (${this.seleccionados.size})`;
  }

  toggleTodos(checked) {
    const datos = this.reportes;
    if (checked) datos.forEach(r => this.seleccionados.add(r.id));
    else this.seleccionados.clear();
    this.renderizarSeccion('reportes');
  }

  // ─── HTML Comercios ────────────────────────────────────────────────────────
  htmlComercios() {
    const filas = this.comercios.map((c, i) => `
      <tr class="border-b hover:bg-gray-50">
        <td class="py-3 px-4 font-medium text-gray-800">${c.nombre}</td>
        <td class="py-3 px-4 text-sm text-gray-500">${c.rubro}</td>
        <td class="py-3 px-4">
          <span class="px-2 py-1 rounded-full text-xs font-medium ${c.activo ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'}">
            ${c.activo ? '✅ Activo' : '⭕ Inactivo'}
          </span>
        </td>
        <td class="py-3 px-4">
          <div class="flex items-center gap-2">
            <div class="w-24 bg-gray-200 rounded-full h-2">
              <div class="bg-purple-500 h-2 rounded-full" style="width:${Math.min(100, c.cuponesCanjeados * 2.5)}%"></div>
            </div>
            <span class="text-sm text-gray-700">${c.cuponesCanjeados}</span>
          </div>
        </td>
        <td class="py-3 px-4">
          <label class="relative inline-flex items-center cursor-pointer">
            <input type="checkbox" ${c.activo ? 'checked' : ''} class="sr-only peer"
              onchange="panel.toggleComercio(${i}, this.checked)">
            <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer
              peer-checked:after:translate-x-full peer-checked:after:border-white after:content-['']
              after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300
              after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
          </label>
        </td>
      </tr>`).join('');

    const totalCupones = this.comercios.reduce((a,c) => a + c.cuponesCanjeados, 0);
    const activos = this.comercios.filter(c => c.activo).length;

    return `
      <div class="p-6 space-y-6">
        <h1 class="text-2xl font-bold text-gray-800">🏪 Comercios Adheridos</h1>

        <div class="grid grid-cols-3 gap-4">
          <div class="bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
            <p class="text-3xl font-bold text-blue-700">${this.comercios.length}</p>
            <p class="text-sm text-blue-600">Total comercios</p>
          </div>
          <div class="bg-green-50 border border-green-200 rounded-xl p-4 text-center">
            <p class="text-3xl font-bold text-green-700">${activos}</p>
            <p class="text-sm text-green-600">Activos</p>
          </div>
          <div class="bg-purple-50 border border-purple-200 rounded-xl p-4 text-center">
            <p class="text-3xl font-bold text-purple-700">${totalCupones}</p>
            <p class="text-sm text-purple-600">Cupones canjeados</p>
          </div>
        </div>

        <div class="bg-white border rounded-xl shadow-sm overflow-hidden">
          <div class="px-5 py-4 border-b bg-gray-50">
            <h2 class="font-semibold text-gray-700">Lista de comercios</h2>
          </div>
          <table class="w-full text-left">
            <thead class="text-xs text-gray-500 uppercase bg-gray-50">
              <tr>
                <th class="py-2 px-4">Nombre</th>
                <th class="py-2 px-4">Rubro</th>
                <th class="py-2 px-4">Estado</th>
                <th class="py-2 px-4">Cupones canjeados</th>
                <th class="py-2 px-4">Activar/Desactivar</th>
              </tr>
            </thead>
            <tbody>${filas}</tbody>
          </table>
        </div>
      </div>`;
  }

  toggleComercio(index, activo) {
    this.comercios[index].activo = activo;
    mostrarToast(`${this.comercios[index].nombre} ${activo ? 'activado' : 'desactivado'}`);
  }

  // ─── HTML Usuarios ─────────────────────────────────────────────────────────
  htmlUsuarios() {
    return `
      <div class="p-6 space-y-6">
        <h1 class="text-2xl font-bold text-gray-800">👥 Usuarios</h1>
        <div class="bg-white border rounded-xl p-8 text-center shadow-sm">
          <div class="text-5xl mb-4">🔐</div>
          <h2 class="text-xl font-semibold text-gray-700 mb-2">Privacidad por diseño</h2>
          <p class="text-gray-500 max-w-md mx-auto">
            Los usuarios de CiudadConecta son anónimos. Sus DNI se hashean con SHA-256
            y nunca se almacena información personal identificable.
          </p>
          <div class="mt-6 grid grid-cols-3 gap-4 max-w-sm mx-auto">
            <div class="bg-blue-50 rounded-xl p-3 text-center">
              <p class="text-2xl font-bold text-blue-700">${this.reportes.length}</p>
              <p class="text-xs text-blue-600">Reportes totales</p>
            </div>
            <div class="bg-green-50 rounded-xl p-3 text-center">
              <p class="text-2xl font-bold text-green-700">—</p>
              <p class="text-xs text-green-600">Usuarios activos</p>
            </div>
            <div class="bg-purple-50 rounded-xl p-3 text-center">
              <p class="text-2xl font-bold text-purple-700">—</p>
              <p class="text-xs text-purple-600">Cupones emitidos</p>
            </div>
          </div>
        </div>
      </div>`;
  }

  // ─── HTML Configuración ────────────────────────────────────────────────────
  htmlConfiguracion() {
    return `
      <div class="p-6 space-y-6">
        <h1 class="text-2xl font-bold text-gray-800">⚙️ Configuración</h1>
        <div class="bg-white border rounded-xl p-6 shadow-sm space-y-4 max-w-lg">
          <h2 class="font-semibold text-gray-700 mb-4">Configuración del municipio</h2>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Nombre del municipio</label>
            <input type="text" value="Municipio de Punta Alta"
              class="w-full border rounded-lg px-3 py-2 text-sm">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Email de contacto</label>
            <input type="email" value="municipio@puntaalta.gov.ar"
              class="w-full border rounded-lg px-3 py-2 text-sm">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Alerta SLA (horas)</label>
            <input type="number" value="72"
              class="w-full border rounded-lg px-3 py-2 text-sm">
            <p class="text-xs text-gray-400 mt-1">Se alertará si un reporte supera este tiempo sin actualización</p>
          </div>
          <button onclick="mostrarToast('Configuración guardada ✅')"
            class="w-full bg-blue-600 text-white py-2 rounded-lg font-medium hover:bg-blue-700 transition">
            Guardar cambios
          </button>
        </div>

        <div class="bg-white border rounded-xl p-6 shadow-sm max-w-lg">
          <h2 class="font-semibold text-gray-700 mb-4 text-red-600">⚠️ Zona peligrosa</h2>
          <button onclick="if(confirm('¿Cerrar sesión?')) cerrarSesionPanel()"
            class="w-full bg-red-500 text-white py-2 rounded-lg font-medium hover:bg-red-600 transition">
            🚪 Cerrar sesión del panel
          </button>
        </div>
      </div>`;
  }
}

// ─── Helpers globales ─────────────────────────────────────────────────────────
function mostrarToast(msg) {
  const t = document.createElement('div');
  t.className = 'fixed bottom-6 right-6 bg-gray-900 text-white px-5 py-3 rounded-xl shadow-lg z-50 text-sm font-medium animate-pulse';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

function inferirZona(lat, lng) {
  if (!lat) return '—';
  if (lat < -38.880) return 'Sur';
  if (lat > -38.878) return 'Norte';
  if (lng < -62.070) return 'Este';
  return 'Centro';
}

// ─── Exports para uso como módulo ─────────────────────────────────────────────
export { PanelMunicipal, mostrarToast, ESTADOS_LABELS, TIPO_ICONS };
