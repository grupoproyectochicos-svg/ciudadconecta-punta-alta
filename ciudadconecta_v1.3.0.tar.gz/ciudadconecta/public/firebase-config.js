// Firebase Configuration — CiudadConecta Punta Alta (Runtime Dynamic)
// Este archivo consume las variables inyectadas por el entorno de despliegue.

const firebaseConfig = {
  apiKey: window._env_?.FIREBASE_API_KEY || "DEVELOPMENT_KEY",
  authDomain: window._env_?.FIREBASE_AUTH_DOMAIN || "localhost",
  projectId: window._env_?.FIREBASE_PROJECT_ID || "ciudadconecta-dev",
  storageBucket: window._env_?.FIREBASE_STORAGE_BUCKET || "ciudadconecta-dev.appspot.com",
  messagingSenderId: window._env_?.FIREBASE_MESSAGING_SENDER_ID || "",
  appId: window._env_?.FIREBASE_APP_ID || ""
};

export default firebaseConfig;
