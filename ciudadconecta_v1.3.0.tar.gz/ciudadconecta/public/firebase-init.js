/**
 * firebase-init.js — Fuente única de Firebase para CiudadConecta
 * Todos los módulos importan desde aquí (no importar Firebase directamente).
 * Firebase SDK v10.12.2 via CDN
 */
import { initializeApp } from 'firebase/app';
import {
  getFirestore, collection, addDoc, getDocs, getDoc,
  query, where, orderBy, limit, doc, setDoc, updateDoc,
  deleteDoc, onSnapshot, serverTimestamp, increment,
  GeoPoint, Timestamp
} from 'firebase/firestore';
import {
  getAuth, signInAnonymously, onAuthStateChanged, signOut,
  signInWithEmailAndPassword
} from 'firebase/auth';
import {
  getStorage, ref, uploadBytes, getDownloadURL, deleteObject
} from 'firebase/storage';

// Importamos la configuración dinámica que consume window._env_
import firebaseConfig from './firebase-config.js';

const app     = initializeApp(firebaseConfig);
const db      = getFirestore(app);
const auth    = getAuth(app);
const storage = getStorage(app);

export {
  app, db, auth, storage,
  collection, addDoc, getDocs, getDoc,
  query, where, orderBy, limit,
  doc, setDoc, updateDoc, deleteDoc,
  onSnapshot, serverTimestamp, increment,
  GeoPoint, Timestamp,
  signInAnonymously, onAuthStateChanged, signOut,
  signInWithEmailAndPassword,
  ref, uploadBytes, getDownloadURL, deleteObject,
  firebaseConfig as FIREBASE_CONFIG
};
