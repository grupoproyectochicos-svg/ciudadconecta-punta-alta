# 🏙️ Manual de Usuario — CiudadConecta Punta Alta
**App Urbana Inteligente para Vecinos y Comercio**

---

## 1. Instalación (PWA)
CiudadConecta es una **PWA (Progressive Web App)**. No necesitás descargarla de la App Store o Play Store.

1.  Escaneá el código QR del proyecto o ingresá a la URL.
2.  **Android:** Tocá los tres puntos (⋮) y seleccioná "Instalar aplicación" o "Agregar a la pantalla de inicio".
3.  **iPhone (iOS):** Tocá el botón "Compartir" y seleccioná "Agregar al inicio".
4.  ¡Listo! Ya tenés el ícono de CiudadConecta junto a tus otras apps.

---

## 2. Cómo realizar un Reporte (Paso a paso)
Tu participación ayuda a que el municipio priorice los arreglos.

1.  **Botón Central:** En el mapa, tocá el botón flotante **📸 REPORTAR**.
2.  **Cámara en Vivo:** La app activará tu cámara trasera. *Nota: No se pueden subir fotos de la galería para garantizar que el incidente es real y actual.*
3.  **Captura:** Apuntá al bache o desagüe y sacá la foto.
4.  **Tipo de Incidente:** Seleccioná si es un bache, problema de desagüe o punto de reciclaje.
5.  **Análisis IA:** Nuestra IA analizará la imagen para confirmar el incidente y medir su severidad.
6.  **Ubicación:** La app capturará automáticamente tu GPS.
7.  **Verificación de Duplicados:** Si un vecino ya reportó lo mismo, tu reporte se sumará al suyo para darle más fuerza.
8.  **¡Listo!:** Al terminar, sumás **10 puntos de reputación** y podés ganar cupones de descuento.

---

## 3. Cupones de Descuento 🎟️
Por colaborar con la ciudad, recibís beneficios en comercios locales de Punta Alta.

-   **Cómo obtenerlos:** Realizando reportes válidos o alcanzando niveles altos de reputación.
-   **Cómo usarlos:** Andá a la sección 🎟️ del menú inferior. Seleccioná un cupón y mostrá el **código QR** en el comercio al momento de pagar.
-   **Beneficio:** Generalmente son del **25% OFF**. ¡Ahorrás mientras ayudás!

---

## 4. Empleo Local 💼
Conectamos a los vecinos con los comerciantes de la zona.

-   **Para vecinos:** Entrá a la sección 💼 para ver ofertas de trabajo en Punta Alta. Podés filtrar por rubro o tipo de jornada.
-   **Para comerciantes:** Si necesitás personal, tocá en "Soy comerciante". Podés grabar un audio describiendo lo que buscás y nuestra IA armará el aviso profesional por vos automáticamente.

---

## 5. Transporte Público 🚌
Predicción inteligente de colectivos.

En la sección 🚌, seleccioná tu línea. CiudadConecta usa los datos de los baches reportados en el recorrido para avisarte si el colectivo viene con demora. ¡No esperes de más en la parada!

---

## 6. Asistente IA (🤖 Robotito)
¿Tenés dudas? En cualquier momento podés tocar el ícono del robotito azul en la esquina inferior izquierda.
-   Preguntale: *"¿Cómo canjeo mi cupón?"* o *"¿Mis datos son privados?"*.
-   El asistente te responderá al instante con información oficial de la app.

---

## 🔒 Privacidad y Seguridad
En CiudadConecta cuidamos tus datos:
-   **Anónimato:** No guardamos tu nombre ni DNI. Usamos un código secreto (hash) para identificarte sin saber quién sos.
-   **Ubicación:** Solo se usa mientras estás usando la app para reportar o ver el transporte.

---
*CiudadConecta Punta Alta — Desarrollado por el equipo UiiA (Álvarez, Arancibia, Puca, Fiszman).*
