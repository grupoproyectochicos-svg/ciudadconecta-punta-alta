const fs = require('fs');
const path = require('path');

/**
 * inject-env.js
 * Busca los placeholders en index.html y los reemplaza por variables de entorno reales.
 * Utilizado en el proceso de build en Vercel.
 */

const filePath = path.join(__dirname, 'public', 'index.html');

try {
  let content = fs.readFileSync(filePath, 'utf8');

  const envs = [
    'FIREBASE_API_KEY',
    'FIREBASE_AUTH_DOMAIN',
    'FIREBASE_PROJECT_ID',
    'FIREBASE_STORAGE_BUCKET',
    'FIREBASE_MESSAGING_SENDER_ID',
    'FIREBASE_APP_ID'
  ];

  envs.forEach(env => {
    const placeholder = `__${env}__`;
    const value = process.env[env] || placeholder;
    content = content.split(placeholder).join(value);
    console.log(`Injecting ${env}: ${value.startsWith('AIza') ? 'OK (Secret)' : 'Using placeholder/value'}`);
  });

  fs.writeFileSync(filePath, content, 'utf8');
  console.log('✓ index.html auditado e inyectado correctamente.');
} catch (err) {
  console.error('Error durante la inyección de variables:', err);
  process.exit(1);
}
