# CiudadConecta — Punta Alta 🏙️

![Estado](https://img.shields.io/badge/estado-en%20construcci%C3%B3n-yellow)
![Vercel](https://img.shields.io/badge/deploy-Vercel-black?logo=vercel)
![Firebase](https://img.shields.io/badge/backend-Firebase-orange?logo=firebase)
![Licencia](https://img.shields.io/badge/licencia-MIT-blue)

> **CiudadConecta** es una Progressive Web App (PWA) con inteligencia artificial para la ciudad de Punta Alta, Buenos Aires. Permite a los vecinos reportar incidentes urbanos (baches, desagües tapados, residuos) con análisis automático por IA, y a la municipalidad gestionar y resolver los reportes en tiempo real.

Proyecto desarrollado para el **Concurso UiiA** — [chicos.net](https://chicos.net) + [Google.org](https://google.org)

---

## 🚀 Stack Tecnológico

| Capa | Tecnología |
|------|-----------|
| 🌐 Frontend | Vanilla JS + HTML5 + CSS3 |
| 🎨 Estilos | Tailwind CSS (CDN) |
| 🗄️ Base de datos | Firebase Firestore v10 |
| 🔐 Autenticación | Firebase Auth (anónima con hash DNI) |
| 🗺️ Mapas | Leaflet.js |
| 📦 Deploy | Vercel (sitio estático) |
| 🤖 IA | Clasificación de imágenes (simulada) |

---

## 📁 Estructura del Proyecto

```
ciudadconecta/
├── public/
│   ├── index.html               # App ciudadana (PWA principal)
│   ├── manifest.json            # Web App Manifest
│   ├── sw.js                    # Service Worker (offline)
│   ├── firebase-init.js         # Inicialización Firebase
│   ├── panel-municipal/
│   │   ├── index.html           # Dashboard municipal
│   │   └── panel.js             # Lógica del panel
│   └── auth/
│       └── login.js             # Módulo de autenticación
├── firebase-config.js           # Configuración Firebase
├── firestore.rules              # Reglas de seguridad Firestore
├── vercel.json                  # Configuración deploy Vercel
├── .gitignore
└── README.md
```

---

## 🛠️ Deploy en Vercel

### Requisitos previos
- Cuenta en [Vercel](https://vercel.com)
- Proyecto Firebase configurado
- Node.js (solo para Vercel CLI)

### Pasos

1. **Clonar el repositorio**
```bash
git clone https://github.com/grupoproyectochicos-svg/chicos.git
cd chicos
```

2. **Instalar Vercel CLI (opcional, para deploy local)**
```bash
npm i -g vercel
```

3. **Deploy a producción**
```bash
vercel --prod
```

4. **O conectar el repo en vercel.com**
   - Ir a [vercel.com/new](https://vercel.com/new)
   - Importar repositorio `grupoproyectochicos-svg/chicos`
   - Framework Preset: **Other**
   - Root Directory: `ciudadconecta` (o la raíz si está en raíz)
   - Hacer clic en **Deploy**

### Variables de entorno

No se requieren variables de entorno en Vercel ya que la config de Firebase es pública (client-side).  
Para mayor seguridad en producción, se recomienda configurar **Firebase App Check**.

| Variable | Descripción | Requerida |
|----------|-------------|-----------|
| — | La config Firebase está en `firebase-config.js` | ✅ incluida |

---

## 🔐 Credenciales del Panel Municipal (Demo)

> ⚠️ **Solo para demostración** — cambiar en producción

| Campo | Valor |
|-------|-------|
| Usuario | `municipio@puntaalta.gov.ar` |
| Contraseña | `admin2024` |

URL del panel: `/panel-municipal/`

---

## 📸 Capturas de Pantalla

```
[ SCREENSHOT: App ciudadana — pantalla de reporte con cámara y mapa ]

[ SCREENSHOT: Panel municipal — dashboard con KPIs y tabla de reportes ]

[ SCREENSHOT: Mapa de incidentes activos en Punta Alta ]

[ SCREENSHOT: Onboarding — 3 slides explicativos ]
```

---

## 🌟 Funcionalidades Principales

### App Ciudadana (PWA)
- 📷 Reporte de incidentes con foto y geolocalización
- 🤖 Clasificación automática por IA (bache, desagüe, reciclaje)
- 🎟️ Sistema de cupones digitales por reportes verificados
- 🔒 Autenticación anónima (DNI hasheado, nunca almacenado)
- 📵 Funciona offline con Service Worker
- 💼 Bolsa de empleo municipal integrada

### Panel Municipal
- 📊 Dashboard con KPIs en tiempo real
- 🗺️ Mapa de incidentes activos
- 📋 Gestión completa de reportes con cambio de estado
- 🏪 Gestión de comercios adheridos al programa de cupones
- 📤 Exportación CSV de reportes
- ⚠️ Alertas por reportes sin actualizar (+72hs)

---

## 📋 Estados de un Reporte

```
Recibido → En agenda → En obra → Resuelto
```

---

## 👥 Equipo

| Nombre | Rol |
|--------|-----|
| Álvarez Sofía | Desarrollo & Diseño |
| Arancibia Uma | Desarrollo & UX |
| Puca Ulises | Desarrollo & Backend |
| Fiszman Morena | Desarrollo & IA |

**Tutor:** Fernández Mariano

---

## 🏆 Concurso

Este proyecto fue desarrollado para el **Concurso UiiA** (Uso Inteligente de Internet en Argentina).

- Organizado por: [chicos.net](https://chicos.net)
- Patrocinador: [Google.org](https://google.org)
- Ciudad: Punta Alta / Coronel Rosales, Buenos Aires, Argentina

---

## 📄 Licencia

MIT © 2024 — Equipo CiudadConecta Punta Alta
